package modules;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import org.openqa.selenium.WebDriver;

public class LaunchQuickQuote {
	
	public static void launchWebsite(WebDriver driver) throws Exception{

        Properties properties = new Properties();
        InputStream input = null;
        input = new FileInputStream("src/test/resources/FST.properties");

        // load properties file
        properties.load(input);

        //open URL
        driver.get(properties.getProperty("quickQuoteURL"));

    }

}
