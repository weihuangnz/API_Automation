package modules;

import org.openqa.selenium.WebDriver;

import PropertiesFilesStrategy.PropertiesFileUtil;

public class LaunchSovHub {
	
	static String baseURL;
	
	public static void launchWebsite(WebDriver driver) throws Exception{

		try
		{
			baseURL = System.getProperty("testenv");
			
			if(baseURL != null)
			{
				driver.get(baseURL);
				//PropertiesFileUtil properties = PropertiesFileUtil.getInstance("QA");
				//driver.get(properties.getProperty("sovHubURL"));
			}
			else
			{
				PropertiesFileUtil properties = PropertiesFileUtil.getInstance("QA");
				driver.get(properties.getProperty("sovHubURL"));
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
    }
}
