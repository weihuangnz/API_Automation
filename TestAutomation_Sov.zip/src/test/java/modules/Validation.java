package modules;

import java.io.File;
import java.util.HashMap;
import java.util.List;

import org.testng.Assert;

import helpers.DataHelper;

public class Validation {
	
	public void validateMessage(File file,String sheet,String fieldName,List<HashMap<String,String>> datamap,int index,String actualMessage)
	{			
		String expectedMessage=datamap.get(index).get("ExpectedValue");		
		HashMap<String,String> columnMap= DataHelper.getColumnNumbers(file.getAbsolutePath(),sheet);	
		DataHelper.writeToExcel(file,sheet, index + 1, Integer.parseInt(columnMap.get("ActualValue")),actualMessage);
		int resultColumn=Integer.parseInt(columnMap.get("RESULT"));
		
		if(expectedMessage.equals(actualMessage))
		{
			DataHelper.writeToExcel(file,sheet, index + 1,resultColumn , "PASS");
		}
		else
		{
			DataHelper.writeToExcel(file,sheet, index + 1, resultColumn, "FAIL");
		}
		Assert.assertEquals(actualMessage,expectedMessage,fieldName+" Message validation");		
	}
	
	public void validateStatus(File file,String sheet,String fieldName,List<HashMap<String,String>> datamap,int index,boolean status)
	{		
			
		HashMap<String,String> columnMap= DataHelper.getColumnNumbers(file.getAbsolutePath(),sheet);			
		int resultColumn=Integer.parseInt(columnMap.get("RESULT"));
		
		if(status)
		{
			DataHelper.writeToExcel(file,sheet, index + 1,resultColumn , "PASS");
		}
		else
		{
			DataHelper.writeToExcel(file,sheet, index + 1, resultColumn, "FAIL");
		}
		Assert.assertTrue(status,fieldName+" status validation");		
	}
	
	public double getPricingThreshold(String frequency)
	{
		double threshold=0.0;
		if(frequency.equalsIgnoreCase("Yearly"))
		{
			threshold=0.12;
		}
		else
		{
			threshold=0.01;
		}
		return threshold;
	}

}
