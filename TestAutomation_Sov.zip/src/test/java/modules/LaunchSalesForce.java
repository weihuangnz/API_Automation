package modules;

import org.openqa.selenium.WebDriver;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Created by AmstelB on 12/10/2016.
 */
public class LaunchSalesForce {

    public static void launchWebsite(WebDriver driver) throws Exception{

        Properties properties = new Properties();
        InputStream input = null;
        input = new FileInputStream("src/test/resources/FST.properties");

        // load properties file
        properties.load(input);

        //open URL
        driver.get(properties.getProperty("salesForceURL"));

    }


    public static String getSalesforceURL() throws IOException {
        Properties properties = new Properties();
        InputStream input = null;
        input = new FileInputStream("src/test/resources/FST.properties");

        // load properties file
        properties.load(input);

        return (properties.getProperty("salesForceURL"));

    }
}
