package modules;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageobjects.BaseClass;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.concurrent.TimeUnit;


/**
 * Created by AmstelB on 13/10/2016.
 */
public class DriverExtension {
   
   private static int TIMEOUT=30;

    //Example Usage:  waitforElementThenClick(driver, element);
    public static void  waitforElementThenClick(WebDriver driver, WebElement element) throws InterruptedException {
    			
		try {
			Wait<WebDriver> fluentWait = new FluentWait<WebDriver>(driver)
					.pollingEvery(1, TimeUnit.SECONDS)
					.withTimeout(TIMEOUT, TimeUnit.SECONDS)
					.ignoring(StaleElementReferenceException.class)
					.ignoring(NoSuchElementException.class);
		
			fluentWait.until(ExpectedConditions.elementToBeClickable(element));	
			if(element.isDisplayed())
			{
				element.click();
			}
		} catch (TimeoutException toe) {
			toe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}		
	
    }

    public static void skipLoadingNewAnimation(WebDriver driver){

    	WebDriverWait wait = new WebDriverWait(driver, 20);
        Boolean element = wait.until(ExpectedConditions.not(
                                             ExpectedConditions.presenceOfAllElementsLocatedBy(
                                                     By.xpath(BaseClass.LOADING_PATH))));
        if(!element)
        {
            skipLoadingAnimation(driver);
        }
    }
    
    public static void skipLoadingAnimation(WebDriver driver)
    {
    	new WebDriverWait(driver, 10).until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(BaseClass.LOADING_PATH)));
    }

    public static void waitforElement(WebDriver driver, WebElement element) throws InterruptedException {
        try {
            if(exist(element)) {
                WebDriverWait wait = new WebDriverWait(driver, 20);
                wait.until(ExpectedConditions.visibilityOf(element));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void waitforElementToBeClickable(WebDriver driver, WebElement element) throws InterruptedException {
        try {
            if(exist(element)) {
                WebDriverWait wait = new WebDriverWait(driver, 20);
                wait.until(ExpectedConditions.elementToBeClickable(element));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void waitForElementBy (WebDriver driver,By by)throws InterruptedException{
        try {
            WebDriverWait wait = new WebDriverWait(driver, 20);
            wait.until(ExpectedConditions.visibilityOfElementLocated(by));
            Thread.sleep(500);
        }catch (Exception e){
            System.out.println(e);
        }
    }

    public static void waitForElementToBeDisplayed (WebDriver driver, WebElement element)throws InterruptedException{
        try {
            WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.visibilityOf(element));
        }catch (Exception e){
            System.out.println(e);
        }
    }

    public static void wait(WebDriver driver) throws InterruptedException {

        Thread.sleep(10000);
    }

    public static void shortWait(WebDriver driver) throws InterruptedException {

        Thread.sleep(5000);
    }

    public static void wait(WebDriver driver,int seconds){
        driver.manage().timeouts().implicitlyWait(seconds, TimeUnit.SECONDS);
    }

    public static String getRandomString() {
        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 3) { // length of the random string.
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
                salt.append(SALTCHARS.charAt(index));
            }
            String saltStr = salt.toString();
            return saltStr;
    }

    public static int getRandomInteger()
    {
        int random = (int )(Math.random() * 9999 + 1);
        return random;
    }

    /**
     * Search for a element by something (id, xpaht, class) return
     *
     * */
    public static WebElement findElementSafe(WebDriver driver, By by)
    {
        try
        {
            return driver.findElement(by);
        }
        catch (NoSuchElementException e)
            {
                return null;
        }
    }


    // To check if any attribute in the webElement is present
    public static boolean isAttributePresent(WebElement element, String attribute) {
        try {
            String value = element.getAttribute(attribute);
            Thread.sleep(2000);
            return (value != null);
        } catch (Exception e) {}

        return false;
    }

    //To check if the element really exist
    public static boolean exist(WebElement element){
        return (element!=null);
    }


    public static boolean isVisible(WebElement element){
        return (exist(element)&& element.isDisplayed());
    }

    public static boolean isEnable(WebElement element) {
        return (exist(element) && element.isEnabled());
    }

    public static String getTodaysDate()
    {
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
        dateFormat.format(date);
        return dateFormat.format(date);
    }

    public void clickDropDownBoxItem(WebElement element, String option)
    {
        Select dropdown = new Select(element);
        dropdown.selectByVisibleText(option);
    }
    
    public static void hoverOverItem(WebElement element, WebDriver driver)
    {
    	 Actions builder = new Actions(driver);
    	 builder.moveToElement(element).build().perform();
    }



    /**
     * Round to certain number of decimals
     *
     * @param d
     * @param decimalPlace
     * @return
     */
    public static float round(float d, int decimalPlace) {
        BigDecimal bd = new BigDecimal(Float.toString(d));
        bd = bd.setScale(decimalPlace, BigDecimal.ROUND_HALF_UP);
        return bd.floatValue();
    }       

    public static void SkipMsg(WebDriver driver){
        WebDriverWait wait = new WebDriverWait(driver, 10);
        Boolean element = wait.until(ExpectedConditions.not(
                ExpectedConditions.presenceOfAllElementsLocatedBy(
                        By.xpath(BaseClass.MSG_PATH))));
        if(!element){
            SkipMsg(driver);
        }
        
        
    }

    public static void stepIntoIframe(WebDriver driver, WebElement element) throws InterruptedException {
        driver.switchTo().frame(element);
        Thread.sleep(2000);
    }


    /**
     * Search for a element by something (id, xpaht, class) return
     *
     * */
    public static Select findElementSafeOption(WebDriver driver, By by)
    {
        try
        {
            return new Select(driver.findElement(by));
        }
        catch (NoSuchElementException e)
        {
            return null;
        }
    }

    /**
     * To know which element has the focuss
     *
     * */
    public static WebElement getActiveElement(WebDriver driver) {

        return driver.switchTo().activeElement();
    }

    public static void scrollUp(WebDriver driver){
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,-2000)", "");
    }

    public static void scrollDown(WebDriver driver){
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,2000)", "");
    }

    public static void scrollTo(WebDriver driver, int to){
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,"+ String.format("%d",to)+")", "");
    }
    
    public static void scrollToBottom(WebDriver driver)
    {
    	((JavascriptExecutor) driver)
        .executeScript("window.scrollTo(0, document.body.scrollHeight)");
    }
    
    
    public static void scrollIntoView(WebElement element, WebDriver driver)
    {
    	//WebElement element = element
    	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
    	try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
    }
    
    public static void moveToElement(WebElement element, WebDriver driver)
    {    	
    	/*Actions actions = new Actions(driver);
    	actions.moveToElement(element);
    	actions.perform();*/
    	JavascriptExecutor js = (JavascriptExecutor) driver; 
    	js.executeScript("arguments[0].scrollIntoView(true);", element);
    }

    public static String getEnvironment()
    {
        String  env = System.getProperty("env");
        return ( env!= null)? env : "QA";
    }

    public static Boolean checkIfExist(WebDriver driver, By xpath) {
        WebElement element = DriverExtension.findElementSafe(driver, xpath);
        return DriverExtension.isVisible(element);
    }

    public static void waitForLoadPage(WebDriver driver){
        driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
    }

    public static void waitForPageLoadByScrip(WebDriver driver) {
        try {
            new WebDriverWait(driver, 30).until((ExpectedCondition<Boolean>) wd ->
                    ((JavascriptExecutor) wd).executeScript("return document.readyState").equals("complete"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static boolean existsElement(WebDriver driver,String path) {
        try {
            driver.findElement(By.xpath(path));
        } catch (NoSuchElementException e) {
            return false;
        }
        return true;
    }
    
    public static boolean waitForElementToAppear(WebDriver driver, WebElement element) {
		boolean shown = false;	
		
		try {
			Wait<WebDriver> fluentWait = new FluentWait<WebDriver>(driver)
					.pollingEvery(1, TimeUnit.SECONDS)
					.withTimeout(TIMEOUT, TimeUnit.SECONDS)
					.ignoring(StaleElementReferenceException.class)
					.ignoring(NoSuchElementException.class);
			fluentWait.until(ExpectedConditions.visibilityOf(element));
			if (element.isDisplayed()) {
				shown= true;
			}
		} catch (TimeoutException toe) {
			toe.printStackTrace();
		}catch (StaleElementReferenceException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return shown;
	}  
    
    public static void waitForElementToDisappear(WebDriver driver, By locator) {    	
    	try {
			Wait<WebDriver> fluentWait = new FluentWait<WebDriver>(driver)
					.pollingEvery(1, TimeUnit.SECONDS)
					.withTimeout(TIMEOUT, TimeUnit.SECONDS)
					.ignoring(NoSuchElementException.class);
			fluentWait.until(ExpectedConditions.invisibilityOfElementLocated(locator));			
		} catch (TimeoutException toe) {
			toe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}  
  

}
