package modules;

import org.openqa.selenium.WebDriver;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

/**
 * Created by AmstelB on 6/09/2017.
 */
public class LaunchMailinator {

    static String baseURL;

    public static void launchMailinator(WebDriver driver) throws Exception{

        try
        {
                Properties properties = new Properties();
                InputStream input = null;
                input = new FileInputStream("src/test/resources/LMI.properties");
                // load properties file
                properties.load(input);
                driver.get(properties.getProperty("mailURL"));
        }
        catch (Exception e)
        {
        }
    }
}
