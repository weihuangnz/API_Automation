package step_definitions.Sovereign.SovHub;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import modules.DriverExtension;
import pageobjects.SovHub.SH_HomePage;
import pageobjects.SovHub.SH_LogOut;
import pageobjects.SovHub.SH_Pre_Assessment;
import step_definitions.Hooks;

public class Production_MonitoringSteps {
	
	public WebDriver driver;
	private SH_HomePage sh_HomePage;
	private SH_Pre_Assessment sh_PreAssessment;
	private SH_LogOut sh_LogOut;
	
	public Production_MonitoringSteps()
	{
		driver = Hooks.driver;
		sh_HomePage = new SH_HomePage(driver);
		sh_PreAssessment = new SH_Pre_Assessment(driver);
		sh_LogOut = new SH_LogOut(driver);
	}

	@When("^on the homepage I can verify the Application Pipeline$")
	public void on_the_homepage_I_can_verify_the_Application_Pipeline() throws Throwable {

		DriverExtension.waitForLoadPage(driver);
		DriverExtension.waitForElementToAppear(driver, sh_HomePage.pipelineTable);
		
		Assert.assertEquals("Application Pipeline",sh_HomePage.checkPipelineHeaderText());
		Assert.assertTrue(DriverExtension.isVisible(sh_HomePage.pipelineTable));
		
	}

	@Then("^the correct amount of questions are being displayed and the system is online$")
	public void the_correct_amount_of_questions_are_being_displayed_and_the_system_is_online() throws Throwable {
		
		DriverExtension.waitForLoadPage(driver);
		DriverExtension.waitForElementToAppear(driver, sh_PreAssessment.smokedInLastYear);
		Assert.assertTrue(DriverExtension.isVisible(sh_PreAssessment.smokedInLastYear));
	
		//log out;
		sh_HomePage.expandProdProfileMenu();
		sh_HomePage.clickLogout();
		
		DriverExtension.waitForLoadPage(driver);
		DriverExtension.waitForElementToAppear(driver, sh_LogOut.logOutText);

	}
	
}
