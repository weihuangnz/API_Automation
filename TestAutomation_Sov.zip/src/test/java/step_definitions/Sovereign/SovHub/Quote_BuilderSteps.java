package step_definitions.Sovereign.SovHub;

import java.io.File;
import java.util.HashMap;
import java.util.List;

import org.testng.Assert;

import PropertiesFilesStrategy.PropertiesFileUtil;

import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import helpers.DataHelper;
import modules.DriverExtension;
import modules.Validation;
import pageobjects.SovHub.SH_AELA;
import pageobjects.SovHub.SH_APC;
import pageobjects.SovHub.SH_ATPD;
import pageobjects.SovHub.SH_Benefits_Selection;
import pageobjects.SovHub.SH_ChildrenMaternity;
import pageobjects.SovHub.SH_EarlyCancerUpgrade;
import pageobjects.SovHub.SH_EssentialDI;
import pageobjects.SovHub.SH_FamilyProtection;
import pageobjects.SovHub.SH_HomePage;
import pageobjects.SovHub.SH_IncomeProtection;
import pageobjects.SovHub.SH_LifeBB;
import pageobjects.SovHub.SH_LivingAssurance;
import pageobjects.SovHub.SH_LivingBB;
import pageobjects.SovHub.SH_LogOut;
import pageobjects.SovHub.SH_MortgageIncomeProtection;
import pageobjects.SovHub.SH_PrivateHealth;
import pageobjects.SovHub.SH_ProgressiveCare;
import pageobjects.SovHub.SH_Quote_BuilderPage;
import pageobjects.SovHub.SH_RC;
import pageobjects.SovHub.SH_Redundancy;
import pageobjects.SovHub.SH_Rename_QuotePage;
import pageobjects.SovHub.SH_RetirementProtection;
import pageobjects.SovHub.SH_SELA;
import pageobjects.SovHub.SH_STPD;
import pageobjects.SovHub.SH_ScenarioSettingsPage;
import pageobjects.SovHub.SH_SpecialistBenefit;
import pageobjects.SovHub.SH_TPDCondition;
import pageobjects.SovHub.SH_WaiverOfPremium;
import pageobjects.SovHub.SH_AccelLivingAssurance;
import pageobjects.SovHub.SH_AccidentalDeath;
import pageobjects.SovHub.SH_AccidentalInjuryCover;
import pageobjects.SovHub.SH_BIS;
import step_definitions.Hooks;
import pageobjects.SovHub.SH_BusinessContinuity;

public class Quote_BuilderSteps {

	public WebDriver driver;
	private SH_HomePage sh_HomePage;
	private SH_Quote_BuilderPage sh_Quote_BuilderPage;
	private SH_ScenarioSettingsPage sh_ScenarioSettingsPage;
	private SH_Benefits_Selection sh_Benefits_Selection;
	private SH_SpecialistBenefit sh_SpecialistBenefit;
	private SH_WaiverOfPremium sh_WaiverOfPremium;
	private SH_PrivateHealth sh_PrivateHealth;
	private Validation validation;
	private SH_IncomeProtection sh_IncomeProtection;
	private SH_MortgageIncomeProtection sh_MortgageIncomeProtection;
	private SH_LivingAssurance sh_LivingAssurance;
	private SH_AccelLivingAssurance sh_AccelLivingAssurance;
	private SH_STPD sh_STPD;
	private SH_ATPD sh_ATPD;
	private SH_APC sh_APC;
	private SH_AccidentalInjuryCover sh_AIC;
	private SH_AccidentalDeath sh_AccidentalDeath;
	private SH_Redundancy sh_Redundancy;
	private SH_ProgressiveCare sh_ProgressiveCare;
	private SH_RetirementProtection sh_RetirementProtection;
	private SH_EarlyCancerUpgrade sh_EarlyCancerUpgrade;
	private SH_LivingBB sh_LivingBB;
	private SH_LifeBB sh_LifeBB;
	private SH_AELA sh_AELA;
	private SH_SELA sh_SELA;
	private SH_EssentialDI sh_EssentialDI;
	private SH_TPDCondition sh_TPDCondition;
	private SH_ChildrenMaternity sh_ChildrenMaternity;
	private SH_FamilyProtection sh_FamilyProtection;
	private SH_Rename_QuotePage sh_Rename_QuotePage;
	private SH_RC sh_RC;
	private SH_BIS sh_BIS;
	private SH_LogOut sh_LogOut;
	public List<HashMap<String,String>> datamap;
	public HashMap<String,String> columnMap;
	public int index;
	public String sheetName;
	public File file = new File("src/test/resources/testData/QuoteBuilderData.xlsx");
	public float pricingThreshold;
	protected SH_BusinessContinuity sh_BC;

	public Quote_BuilderSteps()
	{
		driver = Hooks.driver;
		sh_HomePage = new SH_HomePage(driver);
		sh_Quote_BuilderPage = new SH_Quote_BuilderPage(driver);
		sh_ScenarioSettingsPage = new SH_ScenarioSettingsPage(driver);	
		sh_Benefits_Selection = new SH_Benefits_Selection(driver);
		sh_SpecialistBenefit = new SH_SpecialistBenefit(driver);
		sh_WaiverOfPremium = new SH_WaiverOfPremium(driver);
		sh_PrivateHealth = new SH_PrivateHealth(driver);
		sh_IncomeProtection = new SH_IncomeProtection(driver);
		sh_MortgageIncomeProtection = new SH_MortgageIncomeProtection(driver);
		sh_LivingAssurance = new SH_LivingAssurance(driver);
		sh_AccelLivingAssurance = new SH_AccelLivingAssurance(driver);
		sh_STPD = new SH_STPD(driver);
		sh_ATPD = new SH_ATPD(driver);
		sh_APC = new SH_APC(driver);
		sh_AccidentalDeath = new SH_AccidentalDeath(driver);
		sh_Redundancy = new SH_Redundancy(driver);
		sh_ProgressiveCare = new SH_ProgressiveCare(driver);
		sh_RetirementProtection = new SH_RetirementProtection(driver);
		sh_AIC = new SH_AccidentalInjuryCover(driver);
		sh_EarlyCancerUpgrade = new SH_EarlyCancerUpgrade(driver);
		sh_LivingBB = new SH_LivingBB(driver);
		sh_LifeBB = new SH_LifeBB(driver);
		sh_AELA = new SH_AELA(driver);
		sh_SELA = new SH_SELA(driver);
		sh_EssentialDI = new SH_EssentialDI(driver);
		sh_TPDCondition = new SH_TPDCondition(driver);
		sh_ChildrenMaternity = new SH_ChildrenMaternity(driver);
		sh_FamilyProtection = new SH_FamilyProtection(driver);
		sh_RC = new SH_RC(driver);
		sh_BIS = new SH_BIS(driver);
		validation = new Validation();
		sh_Rename_QuotePage = new SH_Rename_QuotePage(driver);
		sh_LogOut = new SH_LogOut(driver);
		sh_BC = new SH_BusinessContinuity(driver);
	}

	@When("^I click on the Quote Builder button$")
	public void i_click_on_the_Quote_Builder_button() throws Throwable {	

		sh_HomePage.clickQuoteBuilder();
	}

	@Given("^I provide the input data from \"(.*)\" Sheet$")
	public void i_provide_the_input_data_from(String sheetName) throws Throwable {

		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);		
		columnMap = DataHelper.getColumnNumbers(file.getAbsolutePath(),sheetName);		
		this.sheetName=sheetName;	
			
	}

	
	@Given("^I provide the input data in \"(.*)\" Sheet of \"(.*)\" File$")
	public void i_provide_the_input_data_in(String sheetName, String fileName) throws Throwable {
		file = new File(String.format("src/test/resources/testData/%s.xlsx",fileName));
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);		
		columnMap = DataHelper.getColumnNumbers(file.getAbsolutePath(),sheetName);		
		this.sheetName=sheetName;	
			
	}
	@When("^I enter First Name and Last Name for (.*)$")
	public void i_enter_First_Name_and_Last_Name(String row_index) throws Throwable {		
		Thread.sleep(3000);
		index = Integer.parseInt(row_index)-1;
		sh_Quote_BuilderPage.enterFirstNameLastName(datamap.get(index).get("FirstName"), datamap.get(index).get("LastName"), 0);
		String frequency = null;
		if(datamap.get(index).get("PaymentFrequency")!=null)
		{
			frequency = datamap.get(index).get("PaymentFrequency").toString();
			pricingThreshold=(float) validation.getPricingThreshold(frequency);
		}
	}

	@When("^I select a gender and Age$")
	public void i_select_a_gender_and_Age() throws Throwable {	
		if(datamap.get(index).get("Gender")!=null)
		{
		sh_Quote_BuilderPage.selectGender(datamap.get(index).get("Gender"), 0);
		}
		if(datamap.get(index).get("Age")!=null)
		{
		sh_Quote_BuilderPage.enterAge(datamap.get(index).get("Age").toString(), 0);
		}
	}
	@When("^I change age to an invalid Age$")
	public void I_enter_an_invalid_age() throws Throwable
	{
		sh_Quote_BuilderPage.enterAge(datamap.get(index).get("ChangedAge").toString(), 0);
		
	}

	@When("^I select smoker status and Occupation Class$")
	public void i_select_smoker_statusand_Occupation_Class() throws Throwable {		
		sh_Quote_BuilderPage.selectSmoker(datamap.get(index).get("Smoker"), 0);		
		if(datamap.get(index).get("OccClass")!=null)
		{
			sh_Quote_BuilderPage.selectOccupation(datamap.get(index).get("OccClass").toString(), 0);
		}
	}

	@When("^I select Self Employed status$")
	public void i_select_Self_Employed_status() throws Throwable {		
		String selfEmployed = datamap.get(index).get("SelfEmployed");
		if(datamap.get(index).get("OccClass")!=null && !datamap.get(index).get("OccClass").equalsIgnoreCase("5") && !datamap.get(index).get("OccClass").equalsIgnoreCase("U"))
		{
			sh_Quote_BuilderPage.selectSelfEmployed(selfEmployed, 0);
			if(selfEmployed.equalsIgnoreCase("Yes"))
			{
				sh_Quote_BuilderPage.selectSelfEmploymentTerm(datamap.get(index).get("SelfEmployedTerm"), 0);
			}
		}
	}
	
	@When("^I enter Salary$")
	public void i_enter_Salary() throws Throwable {
		sh_Quote_BuilderPage.enterSalary(datamap.get(index).get("RPSalary"),0);
	}

	@When("^I add Personal Cover$")
	public void i_add_Personal_Cover() throws Throwable {
		//sh_Benefits_Selection.addPersBenefits(0);
		String productCode =  datamap.get(index).get("ProductCode");
		sh_Benefits_Selection.openBenefitSelectionList(productCode);
		sh_Benefits_Selection.addLifeCover();
		//sh_Benefits_Selection.closePersonalCover();
		sh_Benefits_Selection.closeBenefitSelectionList(productCode);
	}

	@When("^I add Personal Cover under \"(.*)\"$")
	public void i_add_Personal_Cover_under(String benefitCategory) throws Throwable {
		sh_Benefits_Selection.openBenefitSelectionList(benefitCategory);
		sh_Benefits_Selection.addLifeCover();
		sh_Benefits_Selection.closeBenefitSelectionList(benefitCategory);
	}
	@When("^I remove Life Cover$")
	public void i_remove_life_Cover() throws Throwable {
		sh_Quote_BuilderPage.removeLifeBenefit();
	}

	@When("^I do not select Life Cover$")
	public void i_do_not_select_Life_Cover() throws Throwable {
		sh_Benefits_Selection.addPersBenefits(0);		
	}

	@When("^I do not select Income Protection benefit$")
	public void i_do_not_select_Income_Protection() throws Throwable {
		sh_Benefits_Selection.addPersBenefits(0);		
	}
	
	@When("^I do not select Mortgage Income Protection benefit$")
	public void i_do_not_select_Mortgage_Income_Protection() throws Throwable {
		sh_Benefits_Selection.addPersBenefits(0);		
	}

	@When("^I add Total care Max - Personal$")
	public void i_add_total_care_max() throws Throwable {
		sh_Benefits_Selection.addPersBenefits(0);		
	}

	@When("^I select Personal Cover$")
	public void i_select_Personal_Cover() throws Throwable {
		sh_Benefits_Selection.addPersBenefits(0);
		sh_Benefits_Selection.addLifeCover();		
	}

	@When("^I enter Sum Assured$")
	public void i_enter_Sum_Assured_and_Wait_Period() throws Throwable {
		if(datamap.get(index).get("SumAssured")!=null)
		{
		sh_Quote_BuilderPage.enterSumAssured(datamap.get(index).get("SumAssured").toString(), 0);
		}
	}

	@When("^I select Indexation$")
	public void i_select_Indexation() throws Throwable {
		if(datamap.get(index).get("Indexation")!=null)
		{
		sh_Quote_BuilderPage.selectIndexation(datamap.get(index).get("Indexation"), 0);
		}
	}

	@When("^I enter Loading, Loading Term and Per Mille$")
	public void i_enter_Loading_Loading_Term_and_Per_Mille() throws Throwable {
		sh_Quote_BuilderPage.enterLoading(datamap.get(index).get("Loading"), 0);
		sh_Quote_BuilderPage.enterLoadingTerm(datamap.get(index).get("LoadingTerm"), 0);		
		sh_Quote_BuilderPage.enterPerMille(datamap.get(index).get("PerMille"), 0);		
	}
	

	@When("^I update Scenario Settings$")
	public void i_update_Scenario_Settings() throws Throwable {
		String productCode =  datamap.get(index).get("ProductCode");
		sh_Quote_BuilderPage.selectScenarioSettings(0);
		Thread.sleep(3000); //Please do not comment this out, as the tests fail in Jenkins (BrowserStack), Fluentwait does not help)
		sh_ScenarioSettingsPage.selectPaymentfrequency(datamap.get(index).get("PaymentFrequency"), 0);
		sh_ScenarioSettingsPage.selectPolicyFeesOption(datamap.get(index).get("PolicyFeesOption"));
		sh_ScenarioSettingsPage.expandOtherAdjustments();
		sh_ScenarioSettingsPage.enterCommision(datamap.get(index).get("Commision"));
		if(productCode.equals("WP"))//TCMB doesn't support FI
		{
			sh_ScenarioSettingsPage.selectGroupDiscount("Yes");
		}
		else
		{
			sh_ScenarioSettingsPage.selectGroupDiscount("No");
		}
		sh_ScenarioSettingsPage.clickSave();		
	}

	@When("^I select Premium Option and Future Insurability$")
	public void i_select_Premium_Option_Rate_For_Age_and_Future_Insurability() throws Throwable {

		sh_Quote_BuilderPage.selectPremiumOption(datamap.get(index).get("PremiumOption"), 0);
		String productCode =  datamap.get(index).get("ProductCode");
		if(productCode.equals("TCMP"))//TCMB doesn't support FI
		{
			if(datamap.get(index).get("FiOption")!=null)
			{
			sh_Quote_BuilderPage.selectfiOption(datamap.get(index).get("FiOption"), 0);
			}
		}
	}
	
	@When("^I select Premium Option for Life Benefit$")
	public void i_select_Premium_Option_for_Life_Benefit() throws Throwable {

		sh_Quote_BuilderPage.selectPremiumOption(datamap.get(index).get("PremiumOption"), 0);
		
	}

	@When("^I select Specialist and Diagnostic Testing benefit$")
	public void i_select_Specialist_and_Diagnostic_Testing_benefit() throws Throwable {
		if(datamap.get(index).get("S&T").equals("Yes"))
		{
			sh_Benefits_Selection.addPersBenefits(0);
			sh_Benefits_Selection.addSpecialistAndDiagnosticTesting();
			sh_Benefits_Selection.closePersonalCover();
		}
	}
	
	@When("^I remove Specialist and Diagnostic Testing benefit$")
	public void i_remove_Specialist_and_Diagnostic_Testing_benefit() throws Throwable {		
			sh_Benefits_Selection.addPersBenefits(0);
			sh_Benefits_Selection.addSpecialistAndDiagnosticTesting();
			sh_Benefits_Selection.closePersonalCover();		
	}

	@When("^I select TCMP Waiver Of Premium benefit$")
	public void i_select_TCMP_Waiver_Of_Premium_benefit() throws Throwable {
		sh_Benefits_Selection.addPersBenefits(0);
		sh_Benefits_Selection.addWaiverOfPremium();
		sh_Benefits_Selection.closePersonalCover();
	}
	@When("^I select Waiver Of Premium benefit$")
	public void i_select_Waiver_Of_Premium_benefit() throws Throwable {
		String productCode =  datamap.get(index).get("ProductCode");
		sh_Benefits_Selection.openBenefitSelectionList(productCode);
		sh_Benefits_Selection.addWaiverOfPremium();
		sh_Benefits_Selection.closeBenefitSelectionList(productCode);
	}

	@When("^I select Private health cover benefit$")
	public void i_select_Private_health_Cover_benefit() throws Throwable {
		sh_Benefits_Selection.addHealthCover();
	}

	@When("^I select health waiver of premium$")
	public void i_select_health_waiver_benefit() throws Throwable{
		sh_Benefits_Selection.addHealthWaiverOfPremium();
		
	}	
	
	@When("^I select health Waiver Of Premium waiting period$")
	public void i_select_health_waiver_of_premium_waiting_period() throws Throwable{	
		sh_PrivateHealth.selectHealthWaiverWaitingPeriod(datamap.get(index).get("WoPWaitingPeriod"),0);
	}
	
	@When("^I select Income Protection benefit$")
	public void i_select_Income_Protection_benefit() throws Throwable {
		sh_Benefits_Selection.addIncomeProtection();
	}
	
	@When("^I select Mortgage Income Protection benefit$")
	public void i_select_Mortgage_Income_Protection_benefit() throws Throwable {
		sh_Benefits_Selection.addMortgageIncomeProtection();
	}
	
	@When("^I select Redundancy benefit$")
	public void i_select_Redundancy_benefit() throws Throwable {
		sh_Benefits_Selection.addRedundancy();
	}
	
	@When("^I select Family Protection benefit$")
	public void i_select_Family_Protection_benefit() throws Throwable {
		sh_Benefits_Selection.addFP();
	}
	
	@When("^I remove Family Protection benefit$")
	public void i_remove_Family_Protection_benefit() throws Throwable {
		sh_Benefits_Selection.addFP();
	}
	
	@When("^I select Accidental Death benefit$")
	public void i_select_Accidental_death_benefit() throws Throwable {
		sh_Benefits_Selection.addAD();
	}
	
	@When("^I remove Accidental Death benefit$")
	public void i_remove_Accidental_death_benefit() throws Throwable {
		sh_Benefits_Selection.removeAD();
	}
	
	@When("^I select Retirement Protection benefit$")
	public void i_select_Retirement_Protection_benefit() throws Throwable
	{
		sh_Benefits_Selection.addRP();		
	}
	@When("^I select Accidental Injury Cover benefit$")
	public void i_select_Accidental_injury_cover() throws Throwable {
		String productCode =  datamap.get(index).get("ProductCode");
		sh_Benefits_Selection.openBenefitSelectionList(productCode);
		sh_Benefits_Selection.addAIC();
		sh_Benefits_Selection.closeBenefitSelectionList(productCode);
	}
	
	@And("^I select Accidental Injury Cover benefit under \"(.*)\"$")
	public void iSelectAccidentalInjuryCoverBenefitUnder(String arg1) throws Throwable {
		sh_Benefits_Selection.addAIC(arg1);
	}
	
	@When("^I select Early Cancer Upgrade benefit$")
	public void i_select_ECU_benefit() throws Throwable {
		String productCode =  datamap.get(index).get("ProductCode");
		sh_Benefits_Selection.openBenefitSelectionList(productCode);
		sh_Benefits_Selection.addECU();
		sh_Benefits_Selection.closeBenefitSelectionList(productCode);
	}
	
	
	@When("^I select Early Cancer Upgrade benefit under \"(.*)\"$")
	public void iSelectEarlyCancerUpgradeBenefitUnder(String arg1) throws Throwable {
		sh_Benefits_Selection.addECU(arg1);
	}
	
	@When("^I select Children's and Maternity benefit$")
	public void i_select_Children_Maternity_benefit() throws Throwable {
		sh_Benefits_Selection.addCM();
	}
	
	@When("^I select Progressive Care benefit$")
	public void i_select_SPC_benefit() throws Throwable {
		String productCode =  datamap.get(index).get("ProductCode");
		sh_Benefits_Selection.openBenefitSelectionList(productCode);
		sh_Benefits_Selection.addSPC();
		sh_Benefits_Selection.closeBenefitSelectionList(productCode);
	}
	
	@When("^I select Progressive Care benefit under \"(.*)\"$")
	public void i_select_SPC_benefit(String benefitCategory) throws Throwable {
		sh_Benefits_Selection.addSPC(benefitCategory);
	}
	
	@When("^I remove Progressive Care benefit$")
	public void i_remove_SPC_benefit() throws Throwable {
		sh_Benefits_Selection.addSPC();
	}
	

	@When("^I choose Income Protection benefit$")
	public void i_choose_Income_Protection_benefit() throws Throwable {
		sh_Benefits_Selection.selectIncomeProtection();
	}
	
	@When("^I choose Mortgage Income Protection benefit$")
	public void i_choose_Mortgage_Income_Protection_benefit() throws Throwable {
		sh_Benefits_Selection.selectMIP();
	}
	
	@When("^I select Total Permanent Disablement benefit$")
	public void i_select_Total_Permanent_Disablement_benefit() throws Throwable {
		String productCode =  datamap.get(index).get("ProductCode");
		sh_Benefits_Selection.openBenefitSelectionList(productCode);
		sh_Benefits_Selection.addTPD();
		sh_Benefits_Selection.closeBenefitSelectionList(productCode);
	}

	@When("^I select Total Permanent Disablement benefit under \"(.*)\"$")
	public void i_select_Total_Permanent_Disablement_benefit(String benefitCategory) throws Throwable {
		sh_Benefits_Selection.addTPD(benefitCategory);
	}
	
	@When("^I remove Income Protection benefit$")
	public void i_remove_Income_Protection_benefit() throws Throwable {
		sh_Benefits_Selection.selectIncomeProtection();
	}
	
	@When("^I remove Mortgage Income Protection benefit$")
	public void i_remove_Mortgage_Income_Protection_benefit() throws Throwable {
		sh_Benefits_Selection.selectMIP();
	}
	
	@When("^I remove Total Permanent Disablement benefit$")
	public void i_remove_Total_Permanent_Disablement_benefit() throws Throwable {
		sh_Benefits_Selection.selectTPD();
	}
	
	@When("^I select Accelerated Total Permanent Disablement benefit$")
	public void i_select_Accelerated_Total_Permanent_Disablement_benefit() throws Throwable {
		sh_Quote_BuilderPage.addATPD(0);
	}
	
	@When("^I select Accelerated Progressive Care benefit$")
	public void i_select_Accelerated_Progressive_Care_benefit() throws Throwable {
		sh_Quote_BuilderPage.addAPC(0);
	}
	
	@When("^I select Essential Disability Income benefit$")
	public void i_select_EDI_benefit() throws Throwable {
		sh_Benefits_Selection.addEDI();
	}
	

	@When("^I select health plus benefit$")
	public void i_select_health_plus_benefit() throws Throwable {
		if(datamap.get(index).get("HPRequired").equals("Yes"))
		{
			sh_Benefits_Selection.addHealthPlus();
		}
	}

	@When("^I select Excess value$")
	public void i_select_Excess_value() throws Throwable {
		if(datamap.get(index).get("S&T").equals("Yes"))
		{
			sh_SpecialistBenefit.selectExcess(datamap.get(index).get("Excess"), 0);		
		}
	}

	@When("^I select health cover excess value$")
	public void i_select_health_cover_excess_value() throws Throwable {		
		sh_PrivateHealth.selectHealthCoverExcess(datamap.get(index).get("HCExcess"), 0);		
	}

	@When("^I select health plus excess value$")
	public void i_select_health_plus_excess_value() throws Throwable {		
		if(datamap.get(index).get("HPRequired").equals("Yes"))
		{
			sh_PrivateHealth.selectHealthPlusExcess(datamap.get(index).get("HPExcess"), 0);	
		}
	}

	@When("^I select Child cover$")
	public void i_select_Child_cover() throws Throwable {		
		if(datamap.get(index).get("S&T").equals("Yes"))
		{
			sh_SpecialistBenefit.selectChildCover(datamap.get(index).get("ChildCover"), 0);	
		}
	}

	@When("^I enter Specialist Loading$")
	public void i_enter_Specialist_Loading() throws Throwable {	
		if(datamap.get(index).get("S&T").equals("Yes"))
		{
			sh_SpecialistBenefit.enterSpecialistLoadingPercentage(datamap.get(index).get("SpecialistLoading"), 0);
		}
	}

	@When("^I enter health cover Loading$")
	public void i_enter_health_cover_Loading() throws Throwable {			
		sh_PrivateHealth.enterHCLoadingPercentage(datamap.get(index).get("HCLoading"), 0);		
	}

	@When("^I enter health plus Loading$")
	public void i_enter_health_plus_Loading() throws Throwable {	
		if(datamap.get(index).get("HPRequired").equals("Yes"))
		{
			sh_PrivateHealth.enterHPLoadingPercentage(datamap.get(index).get("HPLoading"), 0);
		}
	}

	@When("^I select Waiver Of Premium waiting period$")
	public void i_select_Waiver_Of_Premium_waiting_period() throws Throwable {		
		sh_WaiverOfPremium.selectWaitingPeriod(datamap.get(index).get("WoPWaitingPeriod"), 0);
	}

	@When("^I enter Waiver Of Premium Loading$")
	public void i_enter_Waiver_Of_Premium_Loading() throws Throwable {		
		sh_WaiverOfPremium.enterWOPLoadingPercentage(datamap.get(index).get("WoPLoading"), 0);
	}

	@When("^I select frequency and Sum Assured$")
	public void i_select_frequency_and_sum_assured() throws Throwable {			
		sh_IncomeProtection.selectSumAssuredFrequency(datamap.get(index).get("SumAssuredFrequency_IP"), 0);
		sh_IncomeProtection.enterSumAssured(datamap.get(index).get("SumAssured_IP"), 0);
	}	
	
	@When("^I select MIP mortgage type$")
	public void i_select_MIP_mortgage_type() throws Throwable {			
		sh_MortgageIncomeProtection.selectMortgageType(datamap.get(index).get("MortgageType"), 0);		
	}
	
	@When("^I select MIP frequency and Sum Assured$")
	public void i_select_MIP_frequency_and_sum_assured() throws Throwable {			
		sh_MortgageIncomeProtection.selectSumAssuredFrequency(datamap.get(index).get("SumAssuredFrequency_MIP"), 0);
		sh_MortgageIncomeProtection.enterSumAssured(datamap.get(index).get("SumAssured_MIP"), 0);
	}
	
	@When("^I select Redundancy frequency and Sum Assured$")
	public void i_select_redundancy_frequency_and_sum_assured() throws Throwable {			
		sh_Redundancy.selectSumAssuredFrequency(datamap.get(index).get("Redundancy_SAFrequency"), 0);
		sh_Redundancy.enterSumAssured(datamap.get(index).get("Redundancy_SumAssured"), 0);
	}
	
	@When("^I enter Sum Assured for TPD Standalone$")
	public void i_enter_sum_assured_for_TPD_Standalone() throws Throwable {			
		sh_STPD.enterSumAssured(datamap.get(index).get("SumAssured_STPD"), 0);
	}
	
	@When("^I enter Sum Assured for Accidental Death$")
	public void i_enter_sum_assured_for_AD() throws Throwable {			
		sh_AccidentalDeath.enterSumAssured(datamap.get(index).get("SumAssured_AD"), 0);
	}
	
	@When("^I select frequency and Sum Assured for AIC$")
	public void i_select_frequency_and_sum_assured_for_AIC() throws Throwable {			
		if(datamap.get(index).get("SAFrequency_AIC")!=null)
		{
			sh_AIC.selectSumAssuredFrequency(datamap.get(index).get("SAFrequency_AIC"), 0);
		}
		if(datamap.get(index).get("SumAssured_AIC")!=null)
		{
			sh_AIC.enterSumAssured(datamap.get(index).get("SumAssured_AIC"), 0);
		}
	}	
	
	@When("^I enter Sum Assured for TPD Accelerated$")
	public void i_enter_sum_assured_for_TPD_Accelerated() throws Throwable {			
		sh_ATPD.enterSumAssured(datamap.get(index).get("SumAssured_ATPD"), 0);
	}
	
	@When("^I select Business Safeguard for TPD Accelerated$")
	public void i_select_BS_for_TPD_Accelerated() throws Throwable {
		if(datamap.get(index).get("BSATPD").equalsIgnoreCase("YES"))
		{
			sh_ATPD.addBSATPD();
		}
	}
	
	@When("^I select Business Safeguard for Accelerated Living Assurance$")
	public void i_select_BS_for_ACLA() throws Throwable {
		if(datamap.get(index).get("BSACLA").equalsIgnoreCase("YES"))
		{
			sh_AccelLivingAssurance.addBSACLA();
		}
	}
	
	@When("^I select Business Safeguard for Life$")
	public void i_select_BS_for_Life() throws Throwable {
		if(datamap.get(index).get("BSLife").equalsIgnoreCase("YES"))
		{
			sh_Quote_BuilderPage.addBSLife();
		}
	}
	
	@When("^I enter Sum Assured for Accelerated Progressive Care$")
	public void i_enter_sum_assured_for_TPD_Progressive_Care() throws Throwable {			
		sh_APC.enterSumAssured(datamap.get(index).get("SumAssured_APC"), 0);
	}


	@When("^I enter Sum Assured for Living Assurance$")
	public void i_select_living_assurance_sum_assured() throws Throwable {			

		sh_LivingAssurance.enterSumAssured(datamap.get(index).get("SumAssured_SCLA"), 0);		
	}
	
	@When("^I enter Sum Assured for Essential Living Assurance$")
	public void i_select_essential_living_assurance_sum_assured() throws Throwable {			

		sh_SELA.enterSumAssured(datamap.get(index).get("SumAssured_SELA"), 0);		
	}
	
	@When("^I enter Sum Assured for Essential DI$")
	public void i_enter_sum_assured_for_EDI() throws Throwable {			
		sh_EssentialDI.enterSumAssured(datamap.get(index).get("SumAssured_EDI"), 0);
	}
	
	@When("^I enter Sum Assured for FPB$")
	public void i_enter_sum_assured_for_FPB() throws Throwable {			
		sh_FamilyProtection.enterSumAssured(datamap.get(index).get("SumAssured_FPB"), 0);
	}

	@When("^I select Indexation and premium option$")
	public void i_select_Indexation_and_premium_option() throws Throwable {			
		sh_IncomeProtection.selectIndexation(datamap.get(index).get("Indexation_IP"), 0);
		sh_IncomeProtection.selectPremiumOption(datamap.get(index).get("PremiumOption_IP"), 0);
	}
	
	@When("^I select Indexation and premium option for AD$")
	public void i_select_Indexation_and_premium_option_for_AD() throws Throwable {			
		sh_AccidentalDeath.selectIndexation(datamap.get(index).get("Indexation_AD"), 0);
		sh_AccidentalDeath.selectPremiumOption(datamap.get(index).get("PremiumOption_AD"), 0);
	}
	
	@When("^I select Indexation for AIC$")
	public void i_select_Indexation_for_AIC() throws Throwable {			
		sh_AIC.selectIndexation(datamap.get(index).get("Indexation_AIC"), 0);		
	}
	
	@When("^I select Indexation and Premium Option for TPD Standalone$")
	public void i_select_Indexation_Premium_Option_for_TPD_Standalone() throws Throwable {			
		sh_STPD.selectIndexation(datamap.get(index).get("Indexation_STPD"), 0);
		sh_STPD.selectPremiumOption(datamap.get(index).get("PremiumOption_STPD"), 0);
	}
	
	@When("^I select Premium Option for TPD Accelerated$")
	public void i_select_Indexation_Premium_Option_for_TPD_Accelerated() throws Throwable {		
		
		sh_ATPD.selectPremiumOption(datamap.get(index).get("PremiumOption_ATPD"), 0);
	}
	
	@When("^I select Premium Option for Accelerated Progressive Care$")
	public void i_select_Premium_Option_for_APC() throws Throwable {		
		sh_APC.selectPremiumOption(datamap.get(index).get("PremiumOption_APC"), 0);
	}
	
	@When("^I select Indexation and premium option for EDI$")
	public void i_select_Indexation_and_premium_option_for_EDI() throws Throwable {			
		sh_EssentialDI.selectIndexation(datamap.get(index).get("Indexation_EDI"), 0);
		sh_EssentialDI.selectPremiumOption(datamap.get(index).get("PremiumOption_EDI"), 0);
	}
	
	@When("^I select Benefit type and Term for TPD Standalone$")
	public void i_select_Benefit_type_and_term() throws Throwable {			
		sh_STPD.selectBenefitType(datamap.get(index).get("BenefitType_STPD"), 0);
		sh_STPD.selectBenefitTerm(datamap.get(index).get("BenefitTerm_STPD"), 0);
	}
	
	@When("^I select Benefit type and Term for TPD Accelerated$")
	public void i_select_Benefit_type_and_term_for_ATPD() throws Throwable {			
		sh_ATPD.selectBenefitType(datamap.get(index).get("BenefitType_ATPD"), 0);
		sh_ATPD.selectBenefitTerm(datamap.get(index).get("BenefitTerm_ATPD"), 0);
	}
	
	@When("^I enter loading values for TPD$")
	public void i_enter_Loading_values_for_TPD() throws Throwable {
		sh_STPD.enterLoading(datamap.get(index).get("Loading_STPD"), 0);
		sh_STPD.enterLoadingTerm(datamap.get(index).get("LoadingTerm_STPD"), 0);		
		sh_STPD.enterPerMille(datamap.get(index).get("PerMille_STPD"), 0);		
	}
	
	@When("^I enter loading values for Accelerated TPD$")
	public void i_enter_Loading_values_for_TPD_Accelerated() throws Throwable {
		sh_ATPD.enterLoading(datamap.get(index).get("Loading_ATPD"), 0);
		sh_ATPD.enterLoadingTerm(datamap.get(index).get("LoadingTerm_ATPD"), 0);		
		sh_ATPD.enterPerMille(datamap.get(index).get("PerMille_ATPD"), 0);		
	}
	
	@When("^I enter loading values for Accelerated Progressive Care$")
	public void i_enter_Loading_values_for_APC() throws Throwable {
		sh_APC.enterLoading(datamap.get(index).get("Loading_APC"), 0);
		sh_APC.enterLoadingTerm(datamap.get(index).get("LoadingTerm_APC"), 0);		
		sh_APC.enterPerMille(datamap.get(index).get("PerMille_APC"), 0);		
	}
	
	@When("^I select MIP Indexation and premium option$")
	public void i_select_MIP_Indexation_and_premium_option() throws Throwable {			
		sh_MortgageIncomeProtection.selectIndexation(datamap.get(index).get("Indexation_MIP"), 0);
		sh_MortgageIncomeProtection.selectPremiumOption(datamap.get(index).get("PremiumOption_MIP"), 0);
	}

	@When("^I select Indexation and premium option for Living Assurance$")
	public void i_select_living_assurance_Indexation_and_premium_option() throws Throwable {	
		if(datamap.get(index).get("Indexation_SCLA")!=null)
		{
		sh_LivingAssurance.selectIndexation(datamap.get(index).get("Indexation_SCLA"), 0);
		}
		sh_LivingAssurance.selectPremiumOption(datamap.get(index).get("PremiumOption_SCLA"), 0);
	}
	
	@When("^I select Indexation and premium option for Essential Living Assurance$")
	public void i_select_essential_living_assurance_Indexation_and_premium_option() throws Throwable {			
		sh_SELA.selectIndexation(datamap.get(index).get("Indexation_SELA"), 0);
		sh_SELA.selectPremiumOption(datamap.get(index).get("PremiumOption_SELA"), 0);
	}
	
	@When("^I select Indexation and premium option for FPB")
	public void i_select_FPB_Indexation_and_premium_option() throws Throwable {			
		sh_FamilyProtection.selectIndexation(datamap.get(index).get("Indexation_FPB"), 0);
		sh_FamilyProtection.selectPremiumOption(datamap.get(index).get("PremiumOption_FPB"), 0);
	}

	@When("^I select Benefit type and payment period$")
	public void i_select_Benefit_type_and_payment_period() throws Throwable {			
		sh_IncomeProtection.selectBenefitType(datamap.get(index).get("BenefitType_IP"), 0);
		sh_IncomeProtection.selectPaymentPeriod(datamap.get(index).get("PaymentPeriod_IP"), 0);
	}
	
	@When("^I select MIP payment period$")
	public void i_select_MIP_payment_period() throws Throwable {		
		sh_MortgageIncomeProtection.selectPaymentPeriod(datamap.get(index).get("PaymentPeriod_MIP"), 0);
	}
	
	@When("^I select EDI payment period$")
	public void i_select_EDI_payment_period() throws Throwable {		
		sh_EssentialDI.selectPaymentPeriod(datamap.get(index).get("PaymentPeriod_EDI"), 0);
	}
	
	@When("^I select FPB payment option and term$")
	public void i_select_FPB_payment_period() throws Throwable {		
		sh_FamilyProtection.selectPaymentOption(datamap.get(index).get("PaymentOption_FPB"), 0);
		sh_FamilyProtection.enterPaymentTerm(datamap.get(index).get("PaymentOption_FPB"),datamap.get(index).get("PaymentTerm_FPB"), 0);
	}
	

	@When("^I select Waiting period and mental health$")
	public void i_select_Waiting_period_mental_health() throws Throwable {			
		sh_IncomeProtection.selectWaitingPeriod(datamap.get(index).get("WaitingPeriod_IP"), 0);
		if(datamap.get(index).get("MentalHealth_IP")!=null)
		{
		sh_IncomeProtection.selectMentalHealthOption(datamap.get(index).get("MentalHealth_IP"), 0);		
		}
	}
	
	@When("^I select mental health exclusion$")
	public void i_select_mental_health_exclusion() throws Throwable {		
		
		if(datamap.get(index).get("MHE_IP")!=null)
		{
			sh_IncomeProtection.selectMentalHealthExclusion(datamap.get(index).get("MHE_IP"), 0);		
		}
	}
	
	@When("^I select MIP Waiting period and mental health$")
	public void i_select_MIP_Waiting_period_mental_health() throws Throwable {			
		sh_MortgageIncomeProtection.selectWaitingPeriod(datamap.get(index).get("WaitingPeriod_MIP"), 0);
		if(datamap.get(index).get("MentalHealth_MIP")!=null)
		{
		sh_MortgageIncomeProtection.selectMentalHealthOption(datamap.get(index).get("MentalHealth_MIP"), 0);		
		}
	}
	
	@When("^I select MIP mental health exclusion$")
	public void i_select_MIP_mental_health_exclusion() throws Throwable {		
		
		if(datamap.get(index).get("MHE_MIP")!=null)
		{
			sh_MortgageIncomeProtection.selectMentalHealthExclusion(datamap.get(index).get("MHE_MIP"), 0);		
		}
	}
	
	@When("^I enter MIP Monthly Mortgage Amount$")
	public void i_enter_MIP_Monthly_Mortgage_amount() throws Throwable {	
		if(datamap.get(index).get("MortgageType").equalsIgnoreCase("Mortgage"))
		{
		sh_MortgageIncomeProtection.enterMonthlyMortgageAmount(datamap.get(index).get("MortgageAmount"), 0);	
		}
	}

	@When("^I select premier option and loading percentage$")
	public void i_select_premier_option_and_loading_percentage() throws Throwable {				
		sh_IncomeProtection.selectPremierOption(datamap.get(index).get("PremierOption_IP"), 0);
		sh_IncomeProtection.enterIPLoadingPercentage(datamap.get(index).get("Loading_IP"), 0);
	}
	
	@When("^I enter MIP loading percentage$")
	public void i_select_MIP_loading_percentage() throws Throwable {		
		sh_MortgageIncomeProtection.enterMIPLoadingPercentage(datamap.get(index).get("Loading_MIP"), 0);
	}

	@When("^I enter loading values for Living Assurance$")
	public void i_enter_LA_loading_values() throws Throwable {			
		sh_LivingAssurance.enterLoadingPercentage(datamap.get(index).get("Loading_SCLA"), 0);
		sh_LivingAssurance.enterLoadingTerm(datamap.get(index).get("LoadingTerm_SCLA"), 0);		
		sh_LivingAssurance.enterPerMille(datamap.get(index).get("PerMille_SCLA"), 0);			
	}
	
	@When("^I enter loading values for Essential Living Assurance$")
	public void i_enter_essential_living_assurance_loading_values() throws Throwable {			

		sh_SELA.enterLoadingPercentage(datamap.get(index).get("Loading_SELA"), 0);
		sh_SELA.enterLoadingTerm(datamap.get(index).get("LoadingTerm_SELA"), 0);		
		sh_SELA.enterPerMille(datamap.get(index).get("PerMille_SELA"), 0);	
	}
	
	@When("^I enter loading values for FPB$")
	public void i_enter_living_assurance_loading_values() throws Throwable {				
		sh_FamilyProtection.enterLoadingPercentage(datamap.get(index).get("Loading_FPB"), 0);
		sh_FamilyProtection.enterLoadingTerm(datamap.get(index).get("LoadingTerm_FPB"), 0);		
		sh_FamilyProtection.enterPerMille(datamap.get(index).get("PerMille_FPB"), 0);
	}
	
	@When("^I enter EDI loading percentage$")
	public void i_select_EDI_loading_percentage() throws Throwable {		
		sh_EssentialDI.enterLoadingPercentage(datamap.get(index).get("Loading_EDI"), 0);
	}

	@When("^I select Living Assurance benefit$")
	public void i_select_Living_Assurance_benefit() throws Throwable {
		String productCode =  datamap.get(index).get("ProductCode");
		sh_Benefits_Selection.openBenefitSelectionList(productCode);
		sh_Benefits_Selection.addLivingAssurance();
		sh_Benefits_Selection.closeBenefitSelectionList(productCode);
	}
	
	@When("^I select Living Assurance benefit under \"(.*)\"$")
	public void i_select_Living_Assurance_benefit(String benefitCategory) throws Throwable {
		sh_Benefits_Selection.addLivingAssurance(benefitCategory);
	}
	@When("^I select Essential Living Assurance benefit$")
	public void i_select_Essential_Living_Assurance_benefit() throws Throwable {
		sh_Benefits_Selection.addSELA();
	}
	
	@When("^I remove Essential Living Assurance benefit$")
	public void i_remove_Essential_Living_Assurance_benefit() throws Throwable {
		sh_Benefits_Selection.selectSELA();
	}
	
	@When("^I add Living Assurance benefit$")
	public void i_add_Living_Assurance_benefit() throws Throwable {
		sh_Benefits_Selection.selectLivingAssurance();
	}
	
	
	@When("^I remove Living Assurance benefit$")
	public void i_remove_Living_Assurance_benefit() throws Throwable {
		sh_Benefits_Selection.selectLivingAssurance();
		sh_Benefits_Selection.closePersonalCover();
	}
	
	@When("^I select TPD Condition for Accelerated Progressive Care$")
	public void i_select_TPD_Condition_for_Accelerated_Progressive_Care() throws Throwable {
		if(datamap.get(index).get("TPDC_APC").equals("Y"))
		{
			sh_APC.addTPDCondition(0);
		}
	}

	@When("^I enter TPD Condition loading for Accelerated Progressive Care$")
	public void i_enter_TPD_Condition_loading_for_Accelerated_Progressive_Care() throws Throwable {
		if(datamap.get(index).get("TPDC_APC").equals("Y"))
		{
			sh_TPDCondition.enterTPDCAPCLoading(datamap.get(index).get("Loading_TPDCAPC"), 0);
		}
	}
	
	@When("^I select TPD Condition for Progressive Care$")
	public void i_select_TPD_Condition_for_Progressive_Care() throws Throwable {
		if(datamap.get(index).get("TPDC_SPC").equals("Y"))
		{
			sh_ProgressiveCare.addTPDCondition(0);
		}
	}

	@When("^I enter TPD Condition loading for Progressive Care$")
	public void i_enter_TPD_Condition_loading_for_Progressive_Care() throws Throwable {
		if(datamap.get(index).get("TPDC_SPC").equals("Y"))
		{
			sh_TPDCondition.enterTPDCSPCLoading(datamap.get(index).get("Loading_TPDCSPC"), 0);
		}
	}
	
	@When("^I select TPD Condition for Accelerated Living Assurance$")
	public void i_select_TPD_Condition_for_Accelerated_Living_Assurance() throws Throwable {
		if(datamap.get(index).get("TPDC_ACLA").equals("Y"))
		{
			sh_AccelLivingAssurance.addTPDCondition(0);
		}
	}

	@When("^I enter TPD Condition loading for Accelerated Living Assurance$")
	public void i_enter_TPD_Condition_loading_for_Accelerated_Living_Assurance() throws Throwable {
		if(datamap.get(index).get("TPDC_ACLA").equals("Y"))
		{
			sh_TPDCondition.enterTPDCACLALoading(datamap.get(index).get("Loading_TPDCACLA"), 0);
		}
	}
	
	@When("^I select TPD Condition for Living Assurance$")
	public void i_select_TPD_Condition_for_Living_Assurance() throws Throwable {
		if(datamap.get(index).get("TPDC_SCLA").equals("Y"))
		{
			sh_LivingAssurance.addTPDCondition(0);
		}
	}

	@When("^I enter TPD Condition loading for Living Assurance$")
	public void i_enter_TPD_Condition_loading_for_Living_Assurance() throws Throwable {
		if(datamap.get(index).get("TPDC_SCLA").equals("Y"))
		{
			sh_TPDCondition.enterTPDCSCLALoading(datamap.get(index).get("Loading_TPDCSCLA"), 0);
		}
	}
	
	@When("^I click on Calculate button$")
	public void i_click_on_Calculate() throws Throwable {
		DriverExtension.skipLoadingAnimation(driver);
		sh_Quote_BuilderPage.clickCalculate();		
		DriverExtension.scrollToBottom(driver);
		//Thread.sleep(4000);
		DriverExtension.skipLoadingAnimation(driver);
	}	

	@When("^I select Accelerated Living Assurance benefit$")
	public void i_select_Accelerated_Living_Assurance_benefit() throws Throwable{			
		sh_Quote_BuilderPage.addAccelLivingAssurance(0);		
	}
	
	@When("I remove Accelerated Living Assurance benefit")
	public void i_remove_Accelerated_Living_Assurance_benefit() throws Throwable{
		sh_AccelLivingAssurance.removeACLA(0);
	}
	@When("^I enter Sum Assured for Accelerated Living Assurance$")
	public void i_enter_Sum_Assured_for_Accelerated_Living_Assurance() throws Throwable{
		sh_AccelLivingAssurance.enterSumAssured(datamap.get(index).get("SumAssured_ACLA"), 0);
	}
	
	@When("^I select premium option for Accelerated Living Assurance$")
	public void i_select_premium_option_for_Accelerated_Living_Assurance() throws Throwable{
		
		sh_AccelLivingAssurance.selectPremiumOption(datamap.get(index).get("PremiumOption_ACLA"), 0);
	}
	
	@When("^I select Living Buy Back Discount option for Accelerated Living Assurance$")
	public void i_select_Living_Buy_Back_discount_option_for_Accelerated_Living_Assurance() throws Throwable{
		
		sh_AccelLivingAssurance.selectLivingBuyBackDiscount(datamap.get(index).get("LivingBuyBackDiscount_ACLA"), 0);
	}
	
	@When("^I select Living Buy Back option for Living Assurance$")
	public void i_select_Living_Buy_Back_option_for_Living_Assurance() throws Throwable{		
		sh_LivingAssurance.selectLivingBuyBack(datamap.get(index).get("LivingBuyBack_SCLA"), 0);
	}
	
	@When("^I select Living Buy Back Discount option for Living Assurance$")
	public void i_select_Living_Buy_Back_Discount_option_for_Living_Assurance() throws Throwable{		
		sh_LivingAssurance.selectLivingBuyBackDiscount(datamap.get(index).get("LivingBBDiscount_SCLA"), 0);
	}
	
	@When("^I enter loading values for Accelerated Living Assurance$")
	public void i_enter_loading_values_for_Accelerated_Living_Assurance() throws Throwable{
		sh_AccelLivingAssurance.enterLoadingPercentage(datamap.get(index).get("Loading_ACLA"), 0);
		sh_AccelLivingAssurance.enterLoadingTerm(datamap.get(index).get("LoadingTerm_ACLA"), 0);
		sh_AccelLivingAssurance.enterPerMille(datamap.get(index).get("PerMille_ACLA"), 0);
	}	
	
	@When("^I select Living Buy Back option for Accelerated Living Assurance$")
	public void i_select_Living_Buy_Back_option_for_Accelerated_Living_Assurance() throws Throwable{
		sh_AccelLivingAssurance.selectLivingBuyBack(datamap.get(index).get("LivingBuyBack_ACLA"), 0);
	}	
	
	@When("I select Life Buy Back option for Accelerated Living Assurance")
	public void i_select_Life_Buy_Back_option_for_Accelerated_Living_Assurance() throws Throwable{
		sh_AccelLivingAssurance.selectLifeBuyBack(datamap.get(index).get("LifeBuyBack_ACLA"), 0);
	}
	
	@When("^I enter Sum Assured for Progressive Care$")
	public void i_enter_Sum_Assured_for_Progressive_Care() throws Throwable{		
		sh_ProgressiveCare.enterSumAssured(datamap.get(index).get("SumAssured_SPC"), 0);
	}
	
	@When("^I select Indexation for Progressive Care$")
	public void i_select_Indexation_for_Progressive_Care() throws Throwable{
		sh_ProgressiveCare.selectIndexation(datamap.get(index).get("Indexation_SPC"), 0);
		
	}
	
	@When("^I select Premium Option for Progressive Care$")
	public void i_select_Premium_Option_for_Progressive_Care() throws Throwable{
		sh_ProgressiveCare.selectPremiumOption(datamap.get(index).get("PremiumOption_SPC"), 0);
	}
	
	@When("^I enter Loading, Loading Term and Per Mille for Progressive Care$")
	public void i_enter_Loading_Loading_Term_and_Per_Mille_for_Progressive_Care() throws Throwable{
		sh_ProgressiveCare.enterLoadingPercentage(datamap.get(index).get("Loading_SPC"), 0);
		sh_ProgressiveCare.enterLoadingTerm(datamap.get(index).get("LoadingTerm_SPC"), 0);
		sh_ProgressiveCare.enterPerMille(datamap.get(index).get("PerMille_SPC"), 0);
	}
	
	@When("^I select Retirement Protection Percentage$")
	public void i_select_Retirement_Protection_Percentage() throws Throwable{
		sh_RetirementProtection.selectPercentage(datamap.get(index).get("RPPercentage"), 0);
	}
	
	@When("^I add person$")
	public void i_add_person() throws Throwable{
		sh_Benefits_Selection.addPerson();		
	}
	
	@When("^I enter (.*) First Name and Last Name$") 
	public void i_enter_person_First_Name_and_Last_Name(int person) throws Throwable
	{
		String firstNameSheetField = String.format("Person%d-FirstName", person);
		String lastNameSheetField = String.format("Person%d-LastName", person);
		sh_Quote_BuilderPage.enterFirstNameLastName(datamap.get(index).get(firstNameSheetField), 
													datamap.get(index).get(lastNameSheetField), 
													person);
	}
	
	@When("I select (.*) Gender and Age")
	public void i_select_person_Gender_and_Age(int person) throws Throwable
	{
		String genderSheetField = String.format("Person%d-Gender", person);
		String ageSheetField = String.format("Person%d-Age", person);
		if(datamap.get(index).get(genderSheetField)!=null)
		{
		sh_Quote_BuilderPage.selectGender(datamap.get(index).get(genderSheetField), person);
		}
		if(datamap.get(index).get(ageSheetField)!=null)
		{
		sh_Quote_BuilderPage.enterAge(datamap.get(index).get(ageSheetField).toString(), person);
		}
	}
	
	@When("I select (.*) smoker status")
	public void i_select_person_smoker_status(int person) throws Throwable{
		String smokeSheetField = String.format("Person%d-Smoker", person);
		sh_Quote_BuilderPage.selectSmoker(datamap.get(index).get(smokeSheetField), person);
		
	}
	
	@When("^I enter the child details$") 
	public void i_enter_child_details() throws Throwable
	{
		int person=Integer.parseInt(datamap.get(index).get("NumberOfChildren"));
		
		for (int i=1;i<=person;i++)
		{
			int j=i-1;
			int age = Integer.parseInt(datamap.get(index).get("ChildAge"))+j;	
			sh_Benefits_Selection.addPerson();	
			sh_Quote_BuilderPage.enterFirstNameLastName(datamap.get(index).get("ChildFirstName"), 
					datamap.get(index).get("ChildLastName"), i);
			sh_Quote_BuilderPage.selectGender(datamap.get(index).get("ChildGender"), i);
			sh_Quote_BuilderPage.enterAge(Integer.toString(age), i);
			sh_Quote_BuilderPage.selectSmoker(datamap.get(index).get("ChildSmoker"), i);
			
		}
		
	}
	
	@When("I select Accelerated Essential Living Assurance benefit")
	public void i_select_Accelerated_Essential_Living_Assurance_benefit() throws Throwable{		
		sh_Quote_BuilderPage.addAELA(0);		
	}
	
	@When("I remove Accelerated Essential Living Assurance benefit")
	public void i_remove_Accelerated_Essential_Living_Assurance_benefit() throws Throwable{		
		sh_AELA.removeAELA(0);		
	}
	@When("I enter Sum Assured for Accelerated Essential Living Assurance")
	public void i_select_Sum_Assured_for_Accelerated_Essential_Living_Assurance() throws Throwable{		
		sh_AELA.enterSumAssured(datamap.get(index).get("SumAssured_AELA"), 0);		
	}
	
	@When("I select premium option for Accelerated Essential Living Assurance")
	public void i_select_premium_option_for_Accelerated_Essential_Living_Assurance() throws Throwable{		
		sh_AELA.selectPremiumOption(datamap.get(index).get("PremiumOption_AELA"), 0);
	}

	@When("^I enter Loading, Loading Term and Per Mille for ECU$")
	public void i_enter_Loading_Loading_Term_and_Per_Mille_ECU() throws Throwable {
		sh_EarlyCancerUpgrade.enterLoading(datamap.get(index).get("Loading_ECU"), 0);
		sh_EarlyCancerUpgrade.enterLoadingTerm(datamap.get(index).get("LoadingTerm_ECU"), 0);		
		sh_EarlyCancerUpgrade.enterPerMille(datamap.get(index).get("PerMille_ECU"), 0);		
	}
	
	@When("I enter loading values for Accelerated Essential Living Assurance")
	public void i_enter_loading_values_for_Accelerated_Essential_Living_Assurance() throws Throwable{		
		sh_AELA.enterLoadingPercentage(datamap.get(index).get("Loading_AELA"), 0);
		sh_AELA.enterPerMille(datamap.get(index).get("PerMille_AELA"), 0);
		sh_AELA.enterLoadingTerm(datamap.get(index).get("LoadingTerm_AELA"), 0);
	}
	
	@When("I select Life Buy Back option for Accelerated Essential Living Assurance")
	public void i_select_life_buy_back_option_for_Accelerated_Essential_Living_Assurance() throws Throwable{		
		sh_AELA.selectLifeBuyBack(datamap.get(index).get("LifeBuyBack_AELA"), 0);		
	}
	
	@When("^I select Children's and Maternity$")
	public void i_select_Childrens_and_Maternity() throws Throwable{		
		sh_Benefits_Selection.addCM();		
	}
	
	@When("^I remove Waiver Of Premium$")
	public void i_remove_Waiver_of_Premium() throws Throwable{		
		sh_Benefits_Selection.removeWOP();		
	}
	
	@When("^I enter Sum Assured for all Benefits$")
	public void i_enter_sum_assured_for_all_benefits() throws Throwable{
		String productCode = datamap.get(index).get("ProductCode");
		String sumAssured = datamap.get(index).get("SumAssured");
		String sumAssuredAcc = datamap.get(index).get("SumAssured_Accel");
		String sumAssuredFP = datamap.get(index).get("SumAssured_FP");
		//common benefit
		sh_Quote_BuilderPage.enterSumAssured(sumAssured, 0);	//Life SA
		sh_LivingAssurance.enterSumAssured(sumAssured, 0); //SCLA SA
		sh_AccelLivingAssurance.enterSumAssured(sumAssuredAcc, 0); //ACLA SA
		sh_APC.enterSumAssured(sumAssuredAcc, 0);
		sh_ProgressiveCare.enterSumAssured(sumAssuredAcc, 0);	
		sh_ATPD.enterSumAssured(sumAssuredAcc, 0);
		sh_STPD.enterSumAssured(sumAssuredAcc, 0);
		sh_AIC.enterSumAssured(sumAssuredAcc, 0);				
		switch(productCode)
		{
		case "TCMP":											
			sh_IncomeProtection.enterSumAssured(sumAssured, 0);
			sh_MortgageIncomeProtection.enterSumAssured(sumAssuredAcc, 0);									
			sh_AccidentalDeath.enterSumAssured(sumAssuredAcc, 0);
			sh_Redundancy.enterSumAssured(sumAssuredAcc, 0);							
			sh_AELA.enterSumAssured(sumAssuredAcc, 0);
			sh_SELA.enterSumAssured(sumAssuredAcc, 0);						
			sh_FamilyProtection.enterSumAssured(sumAssuredFP, 0);			
			break;
		case "TCMB":
			//BS
			sh_RC.enterSumAssured(sumAssuredAcc, 0);
			sh_BIS.enterSumAssured(sumAssuredAcc, 0);
			//BC			
			break;
		case "LSPP":
			//to do
			break;
		case "LSPB":
			//to do
			break;
		}
		
	}
	
	@When("^I select Indexation for all Benefits$")
	public void i_select_Indexation_for_all_benefits() throws Throwable{
		String productCode = datamap.get(index).get("ProductCode");
		String indexation = datamap.get(index).get("Indexation");
		
		//common benefit
		sh_Quote_BuilderPage.selectIndexation(indexation, 0);
		sh_LivingAssurance.selectIndexation(indexation, 0);	
		sh_ProgressiveCare.selectIndexation(indexation, 0);		
		sh_STPD.selectIndexation(indexation, 0);
		sh_AIC.selectIndexation(indexation, 0);	
		switch(productCode)
		{
		case "TCMP":											
			sh_IncomeProtection.selectIndexation(indexation, 0);
			sh_MortgageIncomeProtection.selectIndexation(indexation, 0);									
			sh_AccidentalDeath.selectIndexation(indexation, 0);						
			sh_SELA.selectIndexation(indexation, 0);					
			sh_FamilyProtection.selectIndexation(indexation, 0);			
			break;
		case "TCMB":
			//BS
			//RC+BIS
			//BC			
			break;
		case "LSPP":
			//to do
			break;
		case "LSPB":
			//to do
			break;
		}
	}
	
	@When("^I select Premium Option for all Benefits$")
	public void i_select_premium_option_for_all_benefits() throws Throwable{
		String productCode = datamap.get(index).get("ProductCode");
		String premiumOption = datamap.get(index).get("PremiumOption");
		
		//common benefit
		sh_Quote_BuilderPage.selectPremiumOption(premiumOption, 0);
		sh_LivingAssurance.selectPremiumOption(premiumOption, 0);	
		sh_ProgressiveCare.selectPremiumOption(premiumOption, 0);		
		sh_STPD.selectPremiumOption(premiumOption, 0);
		sh_AccelLivingAssurance.selectPremiumOption(premiumOption, 0);
		sh_APC.selectPremiumOption(premiumOption, 0);	
		sh_ATPD.selectPremiumOption(premiumOption, 0);
		
		switch(productCode)
		{
		case "TCMP":											
			sh_IncomeProtection.selectPremiumOption(premiumOption, 0);
			sh_MortgageIncomeProtection.selectPremiumOption(premiumOption, 0);									
			sh_AccidentalDeath.selectPremiumOption(premiumOption, 0);	
			sh_AELA.selectPremiumOption(premiumOption, 0);
			sh_SELA.selectPremiumOption(premiumOption, 0);						
			sh_FamilyProtection.selectPremiumOption(premiumOption, 0);			
			break;
		case "TCMB":
			//BS
			//RC+BIS
			//BC			
			break;
		case "LSPP":
			//to do
			break;
		case "LSPB":
			//to do
			break;
		}
	}
	
	 @When("^I select Rural Continuity benefit$")
	 public void I_select_Rural_Continuity_benefit() throws Throwable{
		 	String prodcutCode = datamap.get(index).get("ProductCode");
		 	sh_Benefits_Selection.openBenefitSelectionList(prodcutCode);
		 	sh_Benefits_Selection.addRuralContinuity();
			sh_Benefits_Selection.closeBenefitSelectionList(prodcutCode);
	 }
	 @When("^I enter Sum Assured for RC benefit$")
	 public void I_enter_Sum_Assured_for_RC_benefit() throws Throwable{		 
		 	sh_RC.enterSumAssured(datamap.get(index).get("SumAssured_RC"), 0);			
	 }
	 @When("^I select Payment Period for RC benefit$")
	 public void I_select_Payment_Period_for_RC_benefit() throws Throwable{		 	
		 	sh_RC.selectPaymentPeriod(datamap.get(index).get("PaymentPeriod_RC"),0);			
	 }
	 @When("^I select waiting Period for RC Benefit$")
	 public void I_select_waiting_Period_for_RC_benefit() throws Throwable{		 	
		 	sh_RC.selectWaitingPeriod(datamap.get(index).get("WaitingPeriod_RC"),0);			
	 }
	 @When("^I select Partial Disablement for RC Benefit$")
	 public void I_select_Partial_Disablement_for_RC_benefit() throws Throwable{		 	
		 	sh_RC.selectPartialDisablement(datamap.get(index).get("PartialDisablement_RC"),0);			
	 }
	 @When("^I select ACC Offsets for RC Benefit$")
	 public void I_select_ACC_Offsets_for_RC_benefit() throws Throwable{		 	
		 	sh_RC.selectACCOffsets(datamap.get(index).get("ACCOffsets_RC"),0);			
	 }
	 @When("^I select Peak Season for RC Benefit$")
	 public void I_select_Peak_Season_for_RC_benefit() throws Throwable{		 	
		 	sh_RC.selectPeakSeason(datamap.get(index).get("PeakSeason_RC"),0);			
	 }
	 @When("^I enter Loading for RC benefit$")
	 public void I_enter_Loading_for_RC_benefit() throws Throwable{		
			sh_RC.enterLoadingPercentage(datamap.get(index).get("Loading_RC"),0);		
	 }
	 @When("^I select Business Income Support benefit$")
	 public void I_select_Business_Income_Support_benefit() throws Throwable{
		 	String prodcutCode = datamap.get(index).get("ProductCode");
		 	sh_Benefits_Selection.openBenefitSelectionList(prodcutCode);
		 	sh_Benefits_Selection.addBIS();
			sh_Benefits_Selection.closeBenefitSelectionList(prodcutCode);
	 }
	 @When("^I enter Sum Assured for BIS benefit$")
	 public void I_enter_Sum_Assured_for_BIS_benefit() throws Throwable{		 
		 	sh_BIS.enterSumAssured(datamap.get(index).get("SumAssured_BIS"), 0);			
	 }
	
	 @When("^I select waiting Period for BIS Benefit$")
	 public void I_select_waiting_Period_for_BIS_benefit() throws Throwable{		 	
		 	sh_BIS.selectWaitingPeriod(datamap.get(index).get("WaitingPeriod_BIS"),0);			
	 }
	 
	 @When("^I select all need for RC and BIS benefit$")
	 public void I_select_all_need_for_RC_BIS_benefit() throws Throwable{	
		 sh_RC.selectPaymentPeriod("1 year",0);
		 sh_RC.selectWaitingPeriod("13",0);
		 sh_RC.selectPartialDisablement("Yes",0);		 
		 sh_RC.selectACCOffsets("No",0);
		 sh_RC.selectPeakSeason("No",0);
		 sh_BIS.selectWaitingPeriod("52",0);			
	 }
	 @When("^I enter Loading for BIS benefit$")
	 public void I_enter_Loading_for_BIS_benefit() throws Throwable{		
			sh_BIS.enterLoadingPercentage(datamap.get(index).get("Loading_BIS"),0);		
	 }
	@Then("^I remove APC$")
	public void I_remove_APC() throws Throwable {	
		sh_APC.removeAPC(0);
	}

	@Then("^I remove SPC$")
	public void I_remove_SPC() throws Throwable {	
		sh_Benefits_Selection.addSPC();	
	}
	@Then("^the system gives premium amount and policy fees$")	
	public void the_system_gives_premium_amount_and_policy_fees() throws Throwable {

		String actualPremium=sh_Quote_BuilderPage.getTotalPremium().replaceAll(",", "");
		String actualFees=sh_Quote_BuilderPage.getPolicyFees().replaceAll(",", "");	
		String actualLife=sh_Quote_BuilderPage.getLifeCover().replaceAll(",", "");	

		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualPremium")), actualPremium);	
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualFees")), actualFees);
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualLifeCover")), actualLife);

		String expectedPremium = datamap.get(index).get("ExpectedPremium").toString();	
		String expectedFees = datamap.get(index).get("ExpectedFees").toString();	
		String expectedLife = datamap.get(index).get("ExpectedLifeCover").toString();
		boolean match=false;
		float premiumDifference=(float) (Double.parseDouble(expectedPremium)-Double.parseDouble(actualPremium));
		float lifeDifference=(float) (Double.parseDouble(expectedLife)-Double.parseDouble(actualLife));
		float feeDifference=(float) (Double.parseDouble(expectedFees)-Double.parseDouble(actualFees));
		int resultColumn=Integer.parseInt(columnMap.get("RESULT"));
		if(feeDifference == 0 && Math.abs(lifeDifference)<=pricingThreshold)
		{	
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}
		Assert.assertTrue(match,"Premium, Life Cover & Policy fees verification");		
	}		
	
	@Then("^I rename and save the quote$")
	public void I_rename_and_save_the_quote() throws Throwable {	
		
		
		PropertiesFileUtil properties = PropertiesFileUtil.getInstance("PDF");
		String pdfFlag = properties.getProperty("PDFSave");
		
		System.out.println(pdfFlag);
		
		if(pdfFlag.equals("Yes"))
		{
			sh_Quote_BuilderPage.clickRenameQuote();
			
			String quoteName = datamap.get(index).get("ScenarioName").toString();
			sh_Rename_QuotePage.renameQuote(quoteName);
			
			sh_Quote_BuilderPage.clickSaveQuote();
		}
	}

	@Then("^the systems gives FI Option value$")
	public void the_system_gives_FI_option_value() throws Throwable {	

		String actualFI="0.00";
		if(datamap.get(index).get("FiOption").equalsIgnoreCase("Yes"))
		{
			actualFI=sh_Quote_BuilderPage.getFIOptionValue().replaceAll(",", "");	
		}
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualFI")), actualFI);			
		String expectedFI = datamap.get(index).get("ExpectedFI").toString();	

		boolean match=false;
		float difference=(float) (Double.parseDouble(expectedFI)-Double.parseDouble(actualFI));

		int resultColumn=Integer.parseInt(columnMap.get("FIResult"));
		if(Math.abs(difference)<=pricingThreshold)
		{	
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}		
		Assert.assertTrue(match,"Future Insurability verification");		
	}	

	@Then("^the systems gives Specialist and Diagnostic testing value$")
	public void the_system_gives_Specialist_and_Diagnostic_testing_value() throws Throwable {		

		String actualST="0.00";
		if(datamap.get(index).get("S&T").equalsIgnoreCase("Yes"))
		{
			actualST=sh_SpecialistBenefit.getSpecialistValue(0).replaceAll(",", "");	
		}
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualST")), actualST);			
		String expectedST = datamap.get(index).get("ExpectedST").toString();

		boolean match=false;
		float difference=(float) (Double.parseDouble(expectedST)-Double.parseDouble(actualST));

		int resultColumn=Integer.parseInt(columnMap.get("STResult"));
		if(Math.abs(difference)<=pricingThreshold)
		{	
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}
		Assert.assertTrue(match,"Specialist & Diagnostic Testing verification");			
	}	
	
	@Then("^the systems gives Specialist and Diagnostic testing Child value$")
	public void the_system_gives_Specialist_and_Diagnostic_testing_Child_value() throws Throwable {		
		String actualSTChild="0.00";
		if(datamap.get(index).get("S&T").equalsIgnoreCase("Yes"))
		{
			//actualSTChild=sh_SpecialistBenefit.getSpecialistChildrenValue(0).replaceAll(",", "");	
			actualSTChild=sh_SpecialistBenefit.getSpecialistChildrenValue(1).replaceAll(",", "");
		}
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualSTChild")), actualSTChild);			
		String expectedSTChild = datamap.get(index).get("ExpectedSTChild").toString();

		boolean match=false;
		float difference=(float) (Double.parseDouble(expectedSTChild)-Double.parseDouble(actualSTChild));

		int resultColumn=Integer.parseInt(columnMap.get("STChildResult"));
		if(Math.abs(difference)<=pricingThreshold)
		{	
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}
		Assert.assertTrue(match,"Specialist & Diagnostic Testing Child verification");		
	}
	
	@Then("^the systems gives Specialist and Diagnostic testing Child value for the older child$")
	public void the_system_gives_Specialist_and_Diagnostic_testing_Child_value_for_the_older_child() throws Throwable {		
		String actualSTChild="0.00";
		if(datamap.get(index).get("S&T").equalsIgnoreCase("Yes"))
		{
			String child1Age = datamap.get(index).get("Person1-Age");
			String child2Age = datamap.get(index).get("Person2-Age");
			int premiumDisplayIndex = 1;
			if(Integer.parseInt(child1Age) < Integer.parseInt(child2Age))				
			{
				premiumDisplayIndex =2;				
			}
			//actualSTChild=sh_SpecialistBenefit.getSpecialistChildrenValue(0).replaceAll(",", "");	
			actualSTChild=sh_SpecialistBenefit.getSpecialistChildrenValue(premiumDisplayIndex).replaceAll(",", "");
		}
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualSTChild")), actualSTChild);			
		String expectedSTChild = datamap.get(index).get("ExpectedSTChild").toString();

		boolean match=false;
		float difference=(float) (Double.parseDouble(expectedSTChild)-Double.parseDouble(actualSTChild));

		int resultColumn=Integer.parseInt(columnMap.get("STChildResult"));
		if(Math.abs(difference)<=pricingThreshold)
		{	
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}
		Assert.assertTrue(match,"Specialist & Diagnostic Testing Child verification");		
	}
	
	@Then("^the systems gives Waiver Of Premium value$")
	public void the_system_gives_Waiver_Of_Premium_value() throws Throwable {		

		String actualWoP=sh_WaiverOfPremium.getWOPValue(0).replaceAll(",", "");		
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualWoP")), actualWoP);			
		String expectedWoP = datamap.get(index).get("ExpectedWoP").toString();		

		boolean match=false;
		float difference=(float) (Double.parseDouble(expectedWoP)-Double.parseDouble(actualWoP));

		int resultColumn=Integer.parseInt(columnMap.get("WoPResult"));
		if(Math.abs(difference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}
		Assert.assertTrue(match,"Waiver Of Premium pricing verification");			
	}	

	@Then("^the systems gives Income Protection and policy fees values$")
	public void the_system_gives_Income_Protection_Policy_Fees() throws Throwable {		

		String actualPremium=sh_Quote_BuilderPage.getTotalPremium().replaceAll(",", "");
		String actualIP=sh_IncomeProtection.getIPValue(0).replaceAll(",", "");	
		String actualFees=sh_Quote_BuilderPage.getPolicyFees().replaceAll(",", "");	
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualPremium")), actualPremium);
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualIP")), actualIP);	
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualFees")), actualFees);	

		String expectedIP = datamap.get(index).get("ExpectedIP").toString();		
		String expectedFees = datamap.get(index).get("ExpectedFees").toString();	
		String expectedPremium = datamap.get(index).get("ExpectedPremium").toString();	

		boolean match=false;
		float premiumDifference=(float) (Double.parseDouble(expectedPremium)-Double.parseDouble(actualPremium));
		float difference=(float) (Double.parseDouble(expectedIP)-Double.parseDouble(actualIP));

		int resultColumn=Integer.parseInt(columnMap.get("RESULT"));
		if(Math.abs(difference)<=pricingThreshold && Math.abs(premiumDifference)<=pricingThreshold && expectedFees.equals(actualFees) )
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}
		Assert.assertTrue(match,"Income Protection pricing & policy Fees verification");		
	}	
	
	@Then("^the systems gives MIP premium values$")
	public void the_system_gives_Mortgage_Income_Protection_premium() throws Throwable {		

		String actualMIP=sh_IncomeProtection.getIPValue(0).replaceAll(",", "");	
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualMIP")), actualMIP);	
		
		String expectedMIP = datamap.get(index).get("ExpectedMIP").toString();		

		boolean match=false;
		float difference=(float) (Double.parseDouble(expectedMIP)-Double.parseDouble(actualMIP));

		int resultColumn=Integer.parseInt(columnMap.get("RESULT"));
		if(Math.abs(difference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}
		Assert.assertTrue(match,"Mortgage and Income Protection pricing verification");			
	}	

	@Then("^the system gives Health Cover and policy fees values$")
	public void the_system_gives_health_cover_value() throws Throwable {		

		String actualHC=sh_PrivateHealth.getHealthCoverValue(0).replaceAll(",", "");
		String actualFees=sh_Quote_BuilderPage.getPolicyFees().replaceAll(",", "");	
		String actualPremium=sh_Quote_BuilderPage.getTotalPremium().replaceAll(",", "");

		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualHC")), actualHC);	
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualFees")), actualFees);
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualPremium")), actualPremium);

		String expectedHC = datamap.get(index).get("ExpectedHC").toString();
		String expectedFees = datamap.get(index).get("ExpectedFees").toString();	
		String expectedPremium = datamap.get(index).get("ExpectedPremium").toString();	

		boolean match=false;
		float premiumDifference=(float) (Double.parseDouble(expectedPremium)-Double.parseDouble(actualPremium));
		float hcDifference=(float) (Double.parseDouble(expectedHC)-Double.parseDouble(actualHC));

		int resultColumn=Integer.parseInt(columnMap.get("HCResult"));
		if(Math.abs(premiumDifference)<=pricingThreshold && expectedFees.equals(actualFees) && hcDifference<=pricingThreshold)
		{	
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}
		Assert.assertTrue(match,"Private Health Cover & Policy fees verification");			
	}

	@Then("^the system gives Health Plus value$")
	public void the_system_gives_health_plus_value() throws Throwable {		
		if(datamap.get(index).get("HPRequired").equals("Yes"))
		{
			String actualHP=sh_PrivateHealth.getHealthPlusValue(0).replaceAll(",", "");				
	
			DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualHP")), actualHP);		
	
			String expectedHP = datamap.get(index).get("ExpectedHP").toString();		
	
			boolean match=false;		
			float hpDifference=(float) (Double.parseDouble(expectedHP)-Double.parseDouble(actualHP));
	
			int resultColumn=Integer.parseInt(columnMap.get("HPResult"));
			if(hpDifference<=pricingThreshold)
			{	
				match=true;
				DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
			}
			else
			{
				DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
			}
			Assert.assertTrue(match,"Health plus pricing verification");				
		}
	}
	@Then("^the system gives Health Waiver value$")
	public void the_system_gives_health_waiver_value() throws Throwable{
		
		String actualHW=sh_PrivateHealth.getHealthWaiverValue(0).replaceAll(",", "");				

		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualHW")), actualHW);		

		String expectedHW = datamap.get(index).get("ExpectedHW").toString();		

		boolean match=false;		
		float hpDifference=(float) (Double.parseDouble(expectedHW)-Double.parseDouble(actualHW));

		int resultColumn=Integer.parseInt(columnMap.get("HWResult"));
		if(hpDifference<=pricingThreshold)
		{	
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}
		Assert.assertTrue(match,"Health Waiver pricing verification");			
	}
	
	@Then("^the systems gives Living Assurance premium value$")
	public void the_system_gives_Living_Assurance_value() throws Throwable {	

		String actualLA=sh_LivingAssurance.getLAValue(0).replaceAll(",", "");			

		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualLA")), actualLA);			

		String expectedLA = datamap.get(index).get("ExpectedLA").toString();		

		boolean match=false;		
		float difference=(float) (Double.parseDouble(expectedLA)-Double.parseDouble(actualLA));

		int resultColumn=Integer.parseInt(columnMap.get("LAStatus"));
		if(Math.abs(difference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}

		Assert.assertTrue(match,"SCLA pricing verification");		
	}	
	
	@Then("^the systems gives SELA premium value$")
	public void the_system_gives_sela_value() throws Throwable {	

		String actualSELA=sh_SELA.getSELAValue(0).replaceAll(",", "");			

		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualSELA")), actualSELA);			

		String expectedSELA = datamap.get(index).get("ExpectedSELA").toString();		

		boolean match=false;		
		float difference=(float) (Double.parseDouble(expectedSELA)-Double.parseDouble(actualSELA));

		int resultColumn=Integer.parseInt(columnMap.get("SELAStatus"));
		if(Math.abs(difference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}

		Assert.assertTrue(match,"SELA pricing verification");		
	}	
	@Then("^the systems gives Accelerated Living Assurance premium value$")
	public void the_systems_gives_Accelerated_Living_Assurance_premium_value() throws Throwable{
		
		String actualACLA=sh_AccelLivingAssurance.getACLAValue(0).replaceAll(",", "");			

		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualACLA")), actualACLA);			

		String expectedACLA = datamap.get(index).get("ExpectedACLA").toString();		

		boolean match=false;		
		float difference=(float) (Double.parseDouble(expectedACLA)-Double.parseDouble(actualACLA));

		int resultColumn=Integer.parseInt(columnMap.get("ACLAStatus"));
		if(Math.abs(difference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}

		Assert.assertTrue(match,"ACLA pricing verification");		
	}
	@Then("^the systems gives MIP premium value$")
	public void the_system_gives_MIP_value() throws Throwable {	

		String actualMIP=sh_MortgageIncomeProtection.getMIPValue(0).replaceAll(",", "");			

		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualMIP")), actualMIP);			

		String expectedMIP = datamap.get(index).get("ExpectedMIP").toString();		

		boolean match=false;		
		float difference=(float) (Double.parseDouble(expectedMIP)-Double.parseDouble(actualMIP));

		int resultColumn=Integer.parseInt(columnMap.get("MIPStatus"));
		if(Math.abs(difference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}

		Assert.assertTrue(match,"MIP pricing verification");			
	}	
	@Then("^the systems gives the life cover value$")
	public void the_systems_gives_the_life_cover_value() throws Throwable{
		String actualLifeCover=sh_Quote_BuilderPage.getLifeCover().replaceAll(",", "");			
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualLifeCover")), actualLifeCover);						
		String expectedLifeCover = datamap.get(index).get("ExpectedLifeCover").toString();	

		float lifeCoverDifference=(float) (Double.parseDouble(expectedLifeCover)-Double.parseDouble(actualLifeCover));	

		boolean match=false;
		int lifeCoverColumn=Integer.parseInt(columnMap.get("LifeCoverStatus"));
		if(Math.abs(lifeCoverDifference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, lifeCoverColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, lifeCoverColumn, "FAIL");
		}

		Assert.assertTrue(match,"Life Cover verification");	
	}
	
	@Then("^the systems gives the total premium value$")
	public void the_system_gives_total_premium() throws Throwable {		

		String actualPremium=sh_Quote_BuilderPage.getTotalPremium().replaceAll(",", "");			
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualPremium")), actualPremium);						
		String expectedPremium = datamap.get(index).get("ExpectedPremium").toString();	

		float premiumDifference=(float) (Double.parseDouble(expectedPremium)-Double.parseDouble(actualPremium));	

		boolean match=false;		
		int premiumColumn=Integer.parseInt(columnMap.get("PremiumStatus"));
		if(Math.abs(premiumDifference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, premiumColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, premiumColumn, "FAIL");
		}

		Assert.assertTrue(match,"Total premium verification");		
		
	}	
	@Then("^the systems gives non-zero total premium value$")   
	public void the_system_gives_non_zero_total_premium() throws Throwable {		

		String actualPremium=sh_Quote_BuilderPage.getTotalPremium().replaceAll(",", "");			
		Double actualPremiumValue = Double.parseDouble(actualPremium);			
		
		Assert.assertTrue(actualPremiumValue > 0.00);		
	}	
	
	@Then("^the systems gives STPD premium value$")
	public void the_system_gives_STPD_Premium() throws Throwable {		

		String actualPremium=sh_Quote_BuilderPage.getTotalPremium().replaceAll(",", "");
		String actualSTPD=sh_STPD.getTPDValue(0).replaceAll(",", "");		
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualPremium")), actualPremium);
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualSTPD")), actualSTPD);				

		String expectedSTPD = datamap.get(index).get("ExpectedSTPD").toString();		
		

		boolean match=false;
		
		float difference=(float) (Double.parseDouble(expectedSTPD)-Double.parseDouble(actualSTPD));

		int resultColumn=Integer.parseInt(columnMap.get("STPDStatus"));
		if(Math.abs(difference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}
		Assert.assertTrue(match,"Total Permanent Disablement - Standalone Premium verification");		
	}
	
	@Then("^the systems gives Accelarated TPD premium value$")
	public void the_system_gives_ATPD_Premium() throws Throwable {	

		
		String actualATPD=sh_ATPD.getATPDValue(0).replaceAll(",", "");			
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualATPD")), actualATPD);			

		String expectedATPD = datamap.get(index).get("ExpectedATPD").toString();		
		

		boolean match=false;
		
		float difference=(float) (Double.parseDouble(expectedATPD)-Double.parseDouble(actualATPD));

		int resultColumn=Integer.parseInt(columnMap.get("ATPDStatus"));
		if(Math.abs(difference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}
		Assert.assertTrue(match,"Total Permanent Disablement - Accelerated Premium verification");		
	}
	
	@Then("^the systems gives Accidental Death premium value$")
	public void the_system_gives_AD_Premium() throws Throwable {		

		String actualPremium=sh_Quote_BuilderPage.getTotalPremium().replaceAll(",", "");
		String actualAD=sh_AccidentalDeath.getADValue(0).replaceAll(",", "");		
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualPremium")), actualPremium);
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualAD")), actualAD);				

		String expectedAD = datamap.get(index).get("ExpectedAD").toString();		
		

		boolean match=false;
		
		float difference=(float) (Double.parseDouble(expectedAD)-Double.parseDouble(actualAD));

		int resultColumn=Integer.parseInt(columnMap.get("ADStatus"));
		if(Math.abs(difference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}
		Assert.assertTrue(match,"Accidental Death Premium verification");		
	}
	
	@Then("^the systems gives Accidental Injury Cover premium value$")
	public void the_system_gives_AIC_Premium() throws Throwable {		

		String actualPremium=sh_Quote_BuilderPage.getTotalPremium().replaceAll(",", "");
		String actualAIC=sh_AIC.getAICValue(0).replaceAll(",", "");		
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualPremium")), actualPremium);
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualAIC")), actualAIC);				

		String expectedAIC = datamap.get(index).get("ExpectedAIC").toString();		
		

		boolean match=false;
		
		float difference=(float) (Double.parseDouble(expectedAIC)-Double.parseDouble(actualAIC));

		int resultColumn=Integer.parseInt(columnMap.get("AICStatus"));
		if(Math.abs(difference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}
		Assert.assertTrue(match,"Accidental Death Premium verification");		
	}
	
	@Then("^the systems gives Accelerated Progressive Care premium value$")
	public void the_system_gives_APC_value() throws Throwable {	

		String actualAPC=sh_APC.getAPCValue(0).replaceAll(",", "");			

		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualAPC")), actualAPC);			

		String expectedAPC = datamap.get(index).get("ExpectedAPC").toString();		

		boolean match=false;		
		float difference=(float) (Double.parseDouble(expectedAPC)-Double.parseDouble(actualAPC));

		int resultColumn=Integer.parseInt(columnMap.get("APCStatus"));
		if(Math.abs(difference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}

		Assert.assertTrue(match,"Accelerated Progressive Care pricing verification");			
	}	
	
	@Then("^the systems gives Redundancy premium value$")
	public void the_system_gives_Redundancy_value() throws Throwable {	

		String actualRedundancy=sh_Redundancy.getRedundancyValue(0).replaceAll(",", "");			

		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualRedundancy")), actualRedundancy);			

		String expectedRedundancy = datamap.get(index).get("ExpectedRedundancy").toString();		

		boolean match=false;		
		float difference=(float) (Double.parseDouble(expectedRedundancy)-Double.parseDouble(actualRedundancy));

		int resultColumn=Integer.parseInt(columnMap.get("RedundancyStatus"));
		if(Math.abs(difference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}

		Assert.assertTrue(match,"Redundancy pricing verification");			
	}	

	
	@Then("^the systems gives Progressive Care premium value$")
	public void the_system_gives_Progressive_Care_premium_value() throws Throwable{

		String actualSPC=sh_ProgressiveCare.getSPCValue(0).replaceAll(",", "");			

		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualSPC")), actualSPC);			

		String expectedSPC = datamap.get(index).get("ExpectedSPC").toString();		

		boolean match=false;		
		float difference=(float) (Double.parseDouble(expectedSPC)-Double.parseDouble(actualSPC));

		int resultColumn=Integer.parseInt(columnMap.get("SPCStatus"));
		if(Math.abs(difference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}

		Assert.assertTrue(match,"Progressive Care pricing verification");		
		
	}
	
	@Then("^the systems does not return premium value for Redundancy and WoP on validation error$")
	public void the_systems_gives_Redundancy_premium_value_on_validation_error() throws Throwable {	

		String isIP = datamap.get(index).get("IP").toString();	
		String isMIP = datamap.get(index).get("MIP").toString();	
		String actualRedundancy=sh_Redundancy.getRedundancyValue(0).replaceAll(",", "");	
		
		String actualWoP=sh_WaiverOfPremium.getWOPValue(0).replaceAll(",", "");			
		String expectedValue = "";			
		Assert.assertEquals(actualRedundancy,expectedValue,"Redundancy premium verification on error");	
		if(isIP=="Yes")
		{
			String actualIP=sh_IncomeProtection.getIPValue(0).replaceAll(",", "");	
			Assert.assertNotEquals(actualIP,expectedValue,"IP premium verification on redundancy error");	
		}
		if(isMIP=="Yes")
		{
			String actualMIP=sh_MortgageIncomeProtection.getMIPValue(0).replaceAll(",", "");	
			Assert.assertNotEquals(actualMIP,expectedValue,"MIP premium verification on redundancy error");	
		}
		Assert.assertEquals(actualWoP,expectedValue,"WoP premium verification on redundancy error");
	}
	
	@Then("^the systems does not return premium value for Redundancy and all associated benefits$")
	public void the_systems_gives_zero_premium_value_for_redundancy_and_all() throws Throwable {	

		String isIP = datamap.get(index).get("IP").toString();	
		String isMIP = datamap.get(index).get("MIP").toString();	
		String actualRedundancy=sh_Redundancy.getRedundancyValue(0).replaceAll(",", "");	
			
		String actualWoP=sh_WaiverOfPremium.getWOPValue(0).replaceAll(",", "");			
		String expectedValue = "";			
		Assert.assertEquals(actualRedundancy,expectedValue,"Redundancy premium verification on error");	
		if(isIP=="Yes")
		{
			String actualIP=sh_IncomeProtection.getIPValue(0).replaceAll(",", "");	
			Assert.assertEquals(actualIP,expectedValue,"IP premium verification on IP validation error");	
		}
		if(isMIP=="Yes")
		{
			String actualMIP=sh_MortgageIncomeProtection.getMIPValue(0).replaceAll(",", "");	
			Assert.assertEquals(actualMIP,expectedValue,"MIP premium verification on MIP validation error");	
		}
		Assert.assertEquals(actualWoP,expectedValue,"WoP premium verification on error");
	}
	
	@Then("^the systems does not return premium value for Redundancy, WoP and IP$")
	public void the_systems_does_not_return_premium_value_for_redundancy_and_IP() throws Throwable {	
			
		String actualRedundancy=sh_Redundancy.getRedundancyValue(0).replaceAll(",", "");	
		String actualIP=sh_IncomeProtection.getIPValue(0).replaceAll(",", "");	
		String actualMIP=sh_MortgageIncomeProtection.getMIPValue(0).replaceAll(",", "");
		String actualWoP=sh_WaiverOfPremium.getWOPValue(0).replaceAll(",", "");			
		String expectedValue = "";			
		Assert.assertNotEquals(actualRedundancy,expectedValue,"Redundancy premium verification on error");	
		Assert.assertEquals(actualIP,expectedValue,"IP premium verification on IP validation error");	
		Assert.assertNotEquals(actualMIP,expectedValue,"MIP premium verification on MIP validation error");			
		Assert.assertEquals(actualWoP,expectedValue,"WoP premium verification on error");
	}
	
	@Then("^the systems does not return premium value for Life, ATPD and S&T$")
	public void the_systems_does_not_return_premium_value_for_Life_ATPD_and_ST() throws Throwable {	
			
		String actualATPD=sh_ATPD.getATPDValue(0).replaceAll(",", "");	
		String actualLife=sh_Quote_BuilderPage.getLifeCover().replaceAll(",", "");	
		String actualST=sh_SpecialistBenefit.getSpecialistValue(0).replaceAll(",", "");	
				
		String expectedValue = "";			
		Assert.assertEquals(actualATPD,expectedValue,"ATPD premium verification on error");	
		Assert.assertEquals(actualLife,expectedValue,"Life premium verification on validation error");	
		Assert.assertEquals(actualST,expectedValue,"S&T premium verification on life validation error");	
	}
	
	@Then("^the systems does not return premium value for ATPD$")
	public void the_systems_does_not_return_premium_value_for_ATPD() throws Throwable {	
			
		String actualATPD=sh_ATPD.getATPDValue(0).replaceAll(",", "");	
		String actualLife=sh_Quote_BuilderPage.getLifeCover().replaceAll(",", "");			
				
		String expectedValue = "";			
		Assert.assertEquals(actualATPD,expectedValue,"ATPD premium verification on error");	
		Assert.assertNotEquals(actualLife,expectedValue,"Life premium verification on validation error");	
		
	}
	
	@When("^the systems does not return premium values for AD and all associated benefits$")
	public void the_systems_does_not_return_premium_value_for_AD_and_AIC_ST_WoP() throws Throwable {	
			
		String actualAD=sh_AccidentalDeath.getADValue(0).replaceAll(",", "");	
		String actualAIC=sh_AIC.getAICValue(0).replaceAll(",", "");	
		String actualST=sh_SpecialistBenefit.getSpecialistValue(0).replaceAll(",", "");	
		String actualWoP=sh_WaiverOfPremium.getWOPValue(0).replaceAll(",", "");			
		String expectedValue = "";			
		Assert.assertEquals(actualAD,expectedValue,"AD premium verification on error");	
		Assert.assertEquals(actualAIC,expectedValue,"AIC premium verification on IP validation error");	
		Assert.assertEquals(actualST,expectedValue,"ST premium verification on MIP validation error");			
		Assert.assertEquals(actualWoP,expectedValue,"WoP premium verification on error");
	}
	
	@Then("^the systems returns premium values for AD and all associated benefits$")
	public void the_systems_return_premium_value_for_AD_and_AIC_ST_WoP() throws Throwable {	
			
		String actualAD=sh_AccidentalDeath.getADValue(0).replaceAll(",", "");	
		String actualAIC=sh_AIC.getAICValue(0).replaceAll(",", "");	
		String actualST=sh_SpecialistBenefit.getSpecialistValue(0).replaceAll(",", "");	
		String actualWoP=sh_WaiverOfPremium.getWOPValue(0).replaceAll(",", "");			
		String expectedValue = "";			
		Assert.assertNotEquals(actualAD,expectedValue,"AD premium verification");	
		Assert.assertNotEquals(actualAIC,expectedValue,"AIC premium verification");	
		Assert.assertNotEquals(actualST,expectedValue,"ST premium verification");			
		Assert.assertNotEquals(actualWoP,expectedValue,"WoP premium verification");
	}
	
	@Then("^the systems return premium values for AD only$")
	public void the_systems_return_premium_value_for_AD() throws Throwable {	
			
		String actualAD=sh_AccidentalDeath.getADValue(0).replaceAll(",", "");		
		String actualST=sh_SpecialistBenefit.getSpecialistValue(0).replaceAll(",", "");				
		String expectedValue = "";			
		Assert.assertNotEquals(actualAD,expectedValue,"AD premium verification");			
		Assert.assertEquals(actualST,expectedValue,"ST premium verification");			
	}
	
	@Then("^the systems gives RP premium value$")
	public void the_systems_gives_RP_premium_value() throws Throwable 
	{
		String actualRP=sh_RetirementProtection.getRPValue(0).replaceAll(",", "");			

		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualRP")), actualRP);			

		String expectedRP = datamap.get(index).get("ExpectedRP").toString();		

		boolean match=false;		
		float difference=(float) (Double.parseDouble(expectedRP)-Double.parseDouble(actualRP));

		int resultColumn=Integer.parseInt(columnMap.get("RPStatus"));
		if(Math.abs(difference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}

		Assert.assertTrue(match,"RP pricing verification");			
	}
	
	@Then("^the systems gives IP premium value$")
	public void the_systems_gives_IP_premium_value() throws Throwable 
	{
		String actualIP=sh_IncomeProtection.getIPValue(0).replaceAll(",", "");				

		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualIP")), actualIP);			

		String expectedIP = datamap.get(index).get("ExpectedIP").toString();		

		boolean match=false;		
		float difference=(float) (Double.parseDouble(expectedIP)-Double.parseDouble(actualIP));

		int resultColumn=Integer.parseInt(columnMap.get("IPStatus"));
		if(Math.abs(difference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}

		Assert.assertTrue(match,"IP pricing verification");			
	}
	
	@Then("^the systems gives ECU Sum Assured and premium value for associated benefits$")
	public void the_systems_gives_ECU_premium_value() throws Throwable 
	{		
		int resultColumn=Integer.parseInt(columnMap.get("RESULT"));
		if(!datamap.get(index).get("SumAssured").equals("0"))
		{
			String actualLife=sh_Quote_BuilderPage.getLifeCover().replaceAll(",", "");	
			
			DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualLifeCover")), actualLife);	
			
			String expectedLife = datamap.get(index).get("ExpectedLifeCover").toString();
			boolean match=false;
			
			float lifeDifference=(float) (Double.parseDouble(expectedLife)-Double.parseDouble(actualLife));
	
			
			if(Math.abs(lifeDifference)<=pricingThreshold)
			{	
				match=true;
				DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
			}
			else
			{
				DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
			}
			Assert.assertTrue(match,"Life Cover verification");	
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualLifeCover")), "0.00");	
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");	
		}
		
		if(datamap.get(index).get("SumAssured_ACLA").equals("0"))
		{
			DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualACLA")), "0.00");
			int resultColumnACLA=Integer.parseInt(columnMap.get("ACLAStatus"));
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumnACLA, "PASS");
		}
		
		String actualECU=sh_EarlyCancerUpgrade.getECUValue(0).replaceAll(",", "");
		String actualECUSA=sh_EarlyCancerUpgrade.getSumAssured(0).replaceAll(",", "");
		String actualPremium=sh_Quote_BuilderPage.getTotalPremium().replaceAll(",", "");
		String actualFees=sh_Quote_BuilderPage.getPolicyFees().replaceAll(",", "");				

		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualPremium")), actualPremium);	
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualFees")), actualFees);	
			
		String expectedFees = datamap.get(index).get("ExpectedFees").toString();			

		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualECU")), actualECU);		
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualECUSA")), actualECU);		

		String expectedECU = datamap.get(index).get("ExpectedECU").toString();
		String expectedECUSA = datamap.get(index).get("ExpectedECUSA").toString();
		String expectedSAStatus=sh_EarlyCancerUpgrade.isSumAssuredDisabled(0);

		boolean match=false;		
		float difference=(float) (Double.parseDouble(expectedECU)-Double.parseDouble(actualECU));

		int resultColumnECU=Integer.parseInt(columnMap.get("ECUStatus"));
		if(expectedFees.equals(actualFees) && Math.abs(difference)<=pricingThreshold && actualECUSA.equals(expectedECUSA) && expectedSAStatus.contains("disabled"))
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumnECU, "PASS");
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");	
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumnECU, "FAIL");
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}

		Assert.assertTrue(match,"Early Cancer Upgrade pricing verification");			
	}
	
	@When("^the systems gives the Living Buy Back value$")
	public void the_system_gives_the_Living_Buy_Back_value() throws Throwable{
		String actualLABB=sh_LivingBB.getLivingBBValue(0).replaceAll(",", "");				

		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualLABB")), actualLABB);			

		String expectedLABB = datamap.get(index).get("ExpectedLABB").toString();		

		boolean match=false;		
		float difference=(float) (Double.parseDouble(expectedLABB)-Double.parseDouble(actualLABB));

		int resultColumn=Integer.parseInt(columnMap.get("LABBStatus"));
		if(Math.abs(difference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}

		Assert.assertTrue(match,"LABB pricing verification");		
	}
	
	@Then("^the system gives Accelerated Essential Living Assurance premium value$")
	public void the_system_gives_the_Accelerated_Essential_Living_Assurance_premium_value() throws Throwable{
		String actualAELA=sh_AELA.getAELAValue(0).replaceAll(",", "");				

		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualAELA")), actualAELA);			

		String expectedAELA = datamap.get(index).get("ExpectedAELA").toString();		

		boolean match=false;		
		float difference=(float) (Double.parseDouble(expectedAELA)-Double.parseDouble(actualAELA));

		int resultColumn=Integer.parseInt(columnMap.get("AELAStatus"));
		if(Math.abs(difference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}

		Assert.assertTrue(match,"AELA pricing verification");		
	}
	
	@Then("^the systems gives the ACLA Life Buy Back value$")
	public void the_system_gives_the_ACLA_Life_Buy_Back_value() throws Throwable{
		String actualLifBB=sh_LifeBB.getACLALifeBBValue(0).replaceAll(",", "");				

		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualLifeBB")), actualLifBB);			

		String expectedLifBB = datamap.get(index).get("ExpectedLifeBB").toString();		

		boolean match=false;		
		float difference=(float) (Double.parseDouble(expectedLifBB)-Double.parseDouble(actualLifBB));

		int resultColumn=Integer.parseInt(columnMap.get("LifeBBStatus"));
		if(Math.abs(difference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}

		Assert.assertTrue(match,"ACLA LifeBB pricing verification");		
	}
	
	@Then("^the systems gives the AELA Life Buy Back value$")
	public void the_system_gives_the_AELA_Life_Buy_Back_value() throws Throwable{
		String actualLifBB=sh_LifeBB.getAELALifeBBValue(0).replaceAll(",", "");				

		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualLifeBBE")), actualLifBB);			

		String expectedLifBB = datamap.get(index).get("ExpectedLifeBBE").toString();		

		boolean match=false;		
		float difference=(float) (Double.parseDouble(expectedLifBB)-Double.parseDouble(actualLifBB));

		int resultColumn=Integer.parseInt(columnMap.get("LifeBBEStatus"));
		if(Math.abs(difference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}

		Assert.assertTrue(match,"AELA LifeBB pricing verification");		
	}
	
	@Then("^the systems does not return premium value for ECU on validation error$")
	public void the_systems_does_not_give_ECU_premium_value_on_validation_error() throws Throwable {	

		String isACLA = datamap.get(index).get("ACLA").toString();	
		String isSCLA = datamap.get(index).get("SCLA").toString();	
		String actualECU=sh_EarlyCancerUpgrade.getECUValue(0).replaceAll(",", "");		
				
		String expectedValue = "";			
		Assert.assertEquals(actualECU,expectedValue,"ECU premium verification on error");	
		if(isACLA=="Yes")
		{
			String actualACLA=sh_AccelLivingAssurance.getACLAValue(0).replaceAll(",", "");	
			Assert.assertNotEquals(actualACLA,expectedValue,"ACLA premium verification on ECU error");	
		}
		if(isSCLA=="Yes")
		{
			String actualSCLA=sh_LivingAssurance.getLAValue(0).replaceAll(",", "");	
			Assert.assertNotEquals(actualSCLA,expectedValue,"SCLA premium verification on ECU error");	
		}		
	}
	
	@Then("^the systems does not return premium value for ECU and Parent benefits on validation error$")
	public void the_systems_does_not_give_ECU_ACLA_SCLA_premium_value_on_validation_error() throws Throwable {	

		String isACLA = datamap.get(index).get("ACLA").toString();	
		String isSCLA = datamap.get(index).get("SCLA").toString();	
		String actualECU=sh_EarlyCancerUpgrade.getECUValue(0).replaceAll(",", "");		
				
		String expectedValue = "";			
		Assert.assertEquals(actualECU,expectedValue,"ECU premium verification on error");	
		if(isACLA=="Yes")
		{
			String actualACLA=sh_AccelLivingAssurance.getACLAValue(0).replaceAll(",", "");	
			Assert.assertEquals(actualACLA,expectedValue,"ACLA premium verification on ECU error");	
		}
		if(isSCLA=="Yes")
		{
			String actualSCLA=sh_LivingAssurance.getLAValue(0).replaceAll(",", "");	
			Assert.assertEquals(actualSCLA,expectedValue,"SCLA premium verification on ECU error");	
		}		
	}
	
	@Then("^the systems does not return premium value for ACLA only on validation error$")
	public void the_systems_does_not_give_ACLA_premium_value_on_validation_error() throws Throwable {
		
		String actualECU=sh_EarlyCancerUpgrade.getECUValue(0).replaceAll(",", "");	
		String actualACLA=sh_AccelLivingAssurance.getACLAValue(0).replaceAll(",", "");	
		String actualSCLA=sh_LivingAssurance.getLAValue(0).replaceAll(",", "");			
				
		String expectedValue = "";			
		Assert.assertNotEquals(actualECU,expectedValue,"ECU premium verification on error");	
		Assert.assertEquals(actualACLA,expectedValue,"ACLA premium verification on ECU error");	
		Assert.assertNotEquals(actualSCLA,expectedValue,"SCLA premium verification on ECU error");			
	}
	
	@Then("^the systems does not return premium value for SCLA only on validation error$")
	public void the_systems_does_not_give_SCLA_premium_value_on_validation_error() throws Throwable {	

		
		String actualECU=sh_EarlyCancerUpgrade.getECUValue(0).replaceAll(",", "");	
		String actualACLA=sh_AccelLivingAssurance.getACLAValue(0).replaceAll(",", "");	
		String actualSCLA=sh_LivingAssurance.getLAValue(0).replaceAll(",", "");	
		
				
		String expectedValue = "";			
		Assert.assertNotEquals(actualECU,expectedValue,"ECU premium verification on error");	
		Assert.assertNotEquals(actualACLA,expectedValue,"ACLA premium verification on ECU error");	
		Assert.assertEquals(actualSCLA,expectedValue,"SCLA premium verification on ECU error");
			
	}
	
	@Then("^the systems gives Essential Income Protection and policy fees values$")
	public void the_system_gives_Essential_Income_Protection_Policy_Fees() throws Throwable {		

		String actualPremium=sh_Quote_BuilderPage.getTotalPremium().replaceAll(",", "");
		String actualEDI=sh_EssentialDI.getEDIValue(0).replaceAll(",", "");	
		String actualFees=sh_Quote_BuilderPage.getPolicyFees().replaceAll(",", "");	
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualPremium")), actualPremium);
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualEDI")), actualEDI);	
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualFees")), actualFees);	

		String expectedEDI = datamap.get(index).get("ExpectedEDI").toString();		
		String expectedFees = datamap.get(index).get("ExpectedFees").toString();	
		String expectedPremium = datamap.get(index).get("ExpectedPremium").toString();	

		boolean match=false;
		float premiumDifference=(float) (Double.parseDouble(expectedPremium)-Double.parseDouble(actualPremium));
		float difference=(float) (Double.parseDouble(expectedEDI)-Double.parseDouble(actualEDI));

		int resultColumn=Integer.parseInt(columnMap.get("RESULT"));
		if(Math.abs(difference)<=pricingThreshold && Math.abs(premiumDifference)<=pricingThreshold && expectedFees.equals(actualFees) )
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}
		Assert.assertTrue(match,"Essential Income Protection pricing & policy Fees verification");		
	}	
	

	@Then("the system gives TPD Condition with APC premium value")
	public void the_system_gives_TPD_Condition_with_APC_premium_value() throws Throwable {
		if(datamap.get(index).get("TPDC_APC").equals("Y"))
		{
			String actualTPDCAPC=sh_TPDCondition.getTPDCAPCValue(0).replaceAll(",", "");			
		

			DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualTPDCAPC")), actualTPDCAPC);			
	
			String expectedTPDCAPC = datamap.get(index).get("ExpectedTPDCAPC").toString();		
	
			boolean match=false;		
			float difference=(float) (Double.parseDouble(actualTPDCAPC)-Double.parseDouble(expectedTPDCAPC));
	
			int resultColumn=Integer.parseInt(columnMap.get("TPDCAPCStatus"));
			if(Math.abs(difference)<=pricingThreshold)
			{				
				match=true;
				DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
			}
			else
			{
				DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
			}
	
			Assert.assertTrue(match,"TPD Condtion with Accelerated Progressive Care pricing verification");			
		}
	}	
	
	@Then("the system gives TPD Condition with SPC premium value")
	public void the_system_gives_TPD_Condition_with_SPC_premium_value() throws Throwable {	
		if(datamap.get(index).get("TPDC_SPC").equals("Y"))
		{
			String actualTPDCSPC=sh_TPDCondition.getTPDCSPCValue(0).replaceAll(",", "");	
			DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualTPDCSPC")), actualTPDCSPC);			
	
			String expectedTPDCSPC = datamap.get(index).get("ExpectedTPDCSPC").toString();		
	
			boolean match=false;		
			float difference=(float) (Double.parseDouble(actualTPDCSPC)-Double.parseDouble(expectedTPDCSPC));
	
			int resultColumn=Integer.parseInt(columnMap.get("TPDCSPCStatus"));
			if(Math.abs(difference)<=pricingThreshold)
			{				
				match=true;
				DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
			}
			else
			{
				DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
			}
	
			Assert.assertTrue(match,"TPD Condtion with Progressive Care pricing verification");		
		}
	}	
	
	@Then("the system gives TPD Condition with ACLA premium value")
	public void the_system_gives_TPD_Condition_with_ACLA_premium_value() throws Throwable 
	{	
		if(datamap.get(index).get("TPDC_ACLA").equals("Y"))
		{
			String actualTPDCACLA=sh_TPDCondition.getTPDCACLAValue(0).replaceAll(",", "");			

			DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualTPDCACLA")), actualTPDCACLA);			

			String expectedTPDCACLA = datamap.get(index).get("ExpectedTPDCACLA").toString();		
	
			boolean match=false;		
			float difference=(float) (Double.parseDouble(actualTPDCACLA)-Double.parseDouble(expectedTPDCACLA));
	
			int resultColumn=Integer.parseInt(columnMap.get("TPDCACLAStatus"));
	
			if(Math.abs(difference)<=pricingThreshold)
			{				
				match=true;
				DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
			}
			else
			{
				DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
			}
	
			Assert.assertTrue(match,"TPD Condtion with Accelerated Lving Assurance pricing verification");
		}
	}	
	
	@Then("the system gives TPD Condition with SCLA premium value")
	public void the_system_gives_TPD_Condition_with_SCLA_premium_value() throws Throwable {		
		if(datamap.get(index).get("TPDC_SCLA").equals("Y"))
		{
			String actualTPDCSCLA=sh_TPDCondition.getTPDCSCLAValue(0).replaceAll(",", "");			

			DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualTPDCSCLA")), actualTPDCSCLA);			
	
			String expectedTPDCSCLA = datamap.get(index).get("ExpectedTPDCSCLA").toString();		
	
			boolean match=false;		
			float difference=(float) (Double.parseDouble(actualTPDCSCLA)-Double.parseDouble(expectedTPDCSCLA));
	
			int resultColumn=Integer.parseInt(columnMap.get("TPDCSCLAStatus"));
			if(Math.abs(difference)<=pricingThreshold)
			{				
				match=true;
				DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
			}
			else
			{
				DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
			}
	
			Assert.assertTrue(match,"TPD Condtion with Lving Assurance pricing verification");		
		}
	}
	
	@Then("the system gives Children's and Maternity premium value")
	public void the_system_gives_Childrens_and_Maternity_premium_value() throws Throwable {			
		String actualCM=sh_ChildrenMaternity.getCMValue(0).replaceAll(",", "");			

		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualCM")), actualCM);			

		String expectedCM = datamap.get(index).get("ExpectedCM").toString();		

		boolean match=false;		
		float difference=(float) (Double.parseDouble(actualCM)-Double.parseDouble(expectedCM));

		int resultColumn=Integer.parseInt(columnMap.get("CMStatus"));
		if(Math.abs(difference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}

		Assert.assertTrue(match,"Children's and Maternity pricing verification");			
	}
	
	@Then("^the systems gives FPB premium value$")
	public void the_system_gives_fpb_value() throws Throwable {	

		String actualFPB=sh_FamilyProtection.getFPBValue(0).replaceAll(",", "");			

		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualFPB")), actualFPB);			

		String expectedFPB = datamap.get(index).get("ExpectedFPB").toString();		

		boolean match=false;		
		float difference=(float) (Double.parseDouble(expectedFPB)-Double.parseDouble(actualFPB));

		int resultColumn=Integer.parseInt(columnMap.get("FPBStatus"));
		if(Math.abs(difference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}

		Assert.assertTrue(match,"Family Protection pricing verification");		
	}
	
	@Then("^the systems does not return premium value for SELA on validation error$")
	public void the_systems_does_not_give_SELA_premium_value_on_validation_error() throws Throwable {

		
		String actualSELA=sh_SELA.getSELAValue(0).replaceAll(",", "");
				
		String expectedValue = "";			
		Assert.assertEquals(actualSELA,expectedValue,"SELA premium verification on error");				
	}
	
	@Then("^the systems does not return premium value for S&T on validation error$")
	public void the_systems_does_not_give_SDT_premium_value_on_validation_error() throws Throwable {

		
		String actualST=sh_SpecialistBenefit.getSpecialistValue(0).replaceAll(",", "");
				
		String expectedValue = "";			
		Assert.assertEquals(actualST,expectedValue,"S&T premium verification on error");				
	}
	
	@Then("^the systems does not return premium value for WoP on validation error$")
	public void the_systems_does_not_give_WoP_premium_value_on_validation_error() throws Throwable {
		
		String actualWoP=sh_WaiverOfPremium.getWOPValue(0).replaceAll(",", "");		
		String actualLife=sh_Quote_BuilderPage.getLifeCover().replaceAll(",", "");
				
		String expectedValue = "";			
		Assert.assertEquals(actualWoP,expectedValue,"WoP premium verification on error");
		Assert.assertNotEquals(actualLife,expectedValue,"Life premium verification on WoP error");
	}
	
	@Then("^the systems does not return premium value for Life and WoP on validation error$")
	public void the_systems_does_not_give_Life_WoP_premium_value_on_validation_error() throws Throwable {
		
		String actualWoP=sh_WaiverOfPremium.getWOPValue(0).replaceAll(",", "");		
		String actualLife=sh_Quote_BuilderPage.getLifeCover().replaceAll(",", "");
				
		String expectedValue = "";			
		Assert.assertEquals(actualWoP,expectedValue,"WoP premium verification on error");
		Assert.assertEquals(actualLife,expectedValue,"Life premium verification on WoP error");
	}	
	
	@Then("^the systems does not return Total premium value for any validation error$")
	public void the_systems_does_not_give_total_premium_value_on_validation_error() throws Throwable {
		
		String actualPremium=sh_Quote_BuilderPage.getTotalPremium().replaceAll(",", "");
				
		String expectedValue = "0.00";			
		Assert.assertEquals(actualPremium,expectedValue,"Total premium verification on any validation error");		
	}
	
	@Then("^the systems does not return premium value for FPB on validation error$")
	public void the_systems_does_not_give_FPB_premium_value_on_validation_error() throws Throwable {
		
		String actualFPB=sh_FamilyProtection.getFPBValue(0).replaceAll(",", "");	
				
		String expectedValue = "";			
		Assert.assertEquals(actualFPB,expectedValue,"FPB premium verification on error");			
	}
	
	@Then("^the systems does not return premium value for Life and S&T Adult and Child on validation error$")
	public void the_systems_does_not_give_Life_SDT_on_validation_error() throws Throwable {
		
			
		String actualLife=sh_Quote_BuilderPage.getLifeCover().replaceAll(",", "");
		String actualST=sh_SpecialistBenefit.getSpecialistValue(0).replaceAll(",", "");
		String actualSTChild=sh_SpecialistBenefit.getSpecialistChildrenValue(0).replaceAll(",", "");
				
		String expectedValue = "";			
		
		Assert.assertEquals(actualLife,expectedValue,"Life premium verification on error");
		Assert.assertEquals(actualST,expectedValue,"S&T premium verification on error");	
		Assert.assertEquals(actualSTChild,expectedValue,"S&T Child premium verification on error");	
	}
	
	@Then("^the systems does not return premium value for S&T Adult and Child on validation error$")
	public void the_systems_does_not_give_SDT_on_validation_error() throws Throwable {		
			
		String actualLife=sh_Quote_BuilderPage.getLifeCover().replaceAll(",", "");
		String actualST=sh_SpecialistBenefit.getSpecialistValue(0).replaceAll(",", "");
		String actualSTChild=sh_SpecialistBenefit.getSpecialistChildrenValue(0).replaceAll(",", "");
				
		String expectedValue = "";			
		
		Assert.assertNotEquals(actualLife,expectedValue,"Life premium verification on error");
		Assert.assertEquals(actualST,expectedValue,"S&T premium verification on error");	
		Assert.assertEquals(actualSTChild,expectedValue,"S&T Child premium verification on error");	
	}
	
	@Then("^the systems does not return premium values for MIP and WoP$")
	public void the_systems_gives_zero_premium_value_for_MIP_and_WoP() throws Throwable {	

			
		String actualMIP=sh_MortgageIncomeProtection.getMIPValue(0).replaceAll(",", "");			
		String actualWoP=sh_WaiverOfPremium.getWOPValue(0).replaceAll(",", "");			
		String expectedValue = "";
			
		Assert.assertEquals(actualMIP,expectedValue,"MIP premium verification on MIP validation error");	
		
		Assert.assertEquals(actualWoP,expectedValue,"WoP premium verification on error");
	}
	
	@Then("^the systems does not return premium values for IP and WoP$")
	public void the_systems_gives_zero_premium_value_for_IP_and_WoP() throws Throwable {	

			
		String actualIP=sh_IncomeProtection.getIPValue(0).replaceAll(",", "");	
					
		String actualWoP=sh_WaiverOfPremium.getWOPValue(0).replaceAll(",", "");			
		String expectedValue = "";
			
		Assert.assertEquals(actualIP,expectedValue,"IP premium verification on IP validation error");		
		Assert.assertEquals(actualWoP,expectedValue,"WoP premium verification on error");
	}
	
	@Then("^the systems gives the policy fees value$")
	public void the_system_gives_the_Policy_Fees() throws Throwable {	

		String actualFees=sh_Quote_BuilderPage.getPolicyFees().replaceAll(",", "");				
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualFees")), actualFees);

		String expectedFees = datamap.get(index).get("ExpectedFees").toString();					
		
			int resultColumn=Integer.parseInt(columnMap.get("FeesStatus"));
			if(expectedFees.equals(actualFees) )
			{		
	
				DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
			}
			else
			{
				DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
			}		

		Assert.assertEquals(actualFees, expectedFees,"Policy Fees verification");				
	}		
	@Then("^the systems gives the Rural Continuity value$")
	public void the_system_gives_the_rural_continuicy_value() throws Throwable {	
		String actualPremium=sh_RC.getRCValue(0).replaceAll(",", "");				
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualRC")), actualPremium);

		String expectedPremium = datamap.get(index).get("ExpectedRC").toString();					
		
		

		boolean match=false;		
		float difference=(float) (Double.parseDouble(expectedPremium)-Double.parseDouble(actualPremium));

		int resultColumn=Integer.parseInt(columnMap.get("RCStatus"));
		if(Math.abs(difference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}

		Assert.assertTrue(match,"RC pricing verification");	
	}
	
	@Then("^the systems gives the Business Income Support value$")
	public void the_system_gives_the_BIS_value() throws Throwable {	
		String actualPremium=sh_BIS.getBISValue(0).replaceAll(",", "");				
		DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualBIS")), actualPremium);

		String expectedPremium = datamap.get(index).get("ExpectedBIS").toString();			

		boolean match=false;		
		float difference=(float) (Double.parseDouble(expectedPremium)-Double.parseDouble(actualPremium));

		int resultColumn=Integer.parseInt(columnMap.get("BISStatus"));
		if(Math.abs(difference)<=pricingThreshold)
		{				
			match=true;
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
		}
		else
		{
			DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
		}

		Assert.assertTrue(match,"BIS pricing verification");	
	}
	@Then("^I logout from SovHub$")
	public void i_logout_from_SovHub() throws Throwable {
		
		String env = DriverExtension.getEnvironment();
		
		if(env == "PROD")
		{
			sh_HomePage.expandMenu();
			sh_HomePage.clickLogout();
		}
		else
		{
			sh_HomePage.expandMenu();
			sh_HomePage.clickLogout();		
			DriverExtension.waitForLoadPage(driver);
			DriverExtension.waitForElementToAppear(driver, sh_LogOut.logOutText);
		}
	}


		
	@And("^I select TCMP Waiver Of Premium benefit under \"(.*)\"$")
	public void iSelectTCMPWaiverOfPremiumBenefitUnder(String arg1) throws Throwable {
		sh_Benefits_Selection.openBenefitSelectionList(arg1);
		sh_Benefits_Selection.addWaiverOfPremium();
		sh_Benefits_Selection.closePersonalCover();
	}
	
	@Then("^the systems gives Business Safeguard values$")
	public void the_systems_gives_BS_values() throws Throwable{
		
		if(datamap.get(index).get("BSACLA").equalsIgnoreCase("YES"))
		{
			boolean matchBSACLA=false;
			String actualBSACLA=sh_AccelLivingAssurance.getBSACLAValue(0).replaceAll(",", "");	
			DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualBSACLA")), actualBSACLA);			
			String expectedBSACLA = datamap.get(index).get("ExpectedBSACLA").toString();		
			float bsATPDDiff=(float) (Double.parseDouble(expectedBSACLA)-Double.parseDouble(actualBSACLA));
			int resultBSACLA=Integer.parseInt(columnMap.get("BSACLAStatus"));
			if(Math.abs(bsATPDDiff)<=pricingThreshold)
			{				
				matchBSACLA=true;
				DataHelper.writeToExcel(file,sheetName, index + 1, resultBSACLA, "PASS");			
			}
			Assert.assertTrue(matchBSACLA,"ACLA - Business Safeguard pricing verification");			
	
		}
		
		if(datamap.get(index).get("BSATPD").equalsIgnoreCase("YES"))
		{
			boolean matchBSATPD=false;
			String actualBSATPD=sh_ATPD.getBSATPDValue(0).replaceAll(",", "");	
			DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualBSATPD")), actualBSATPD);			
			String expectedBSATPD = datamap.get(index).get("ExpectedBSATPD").toString();		
			float bsATPDDiff=(float) (Double.parseDouble(expectedBSATPD)-Double.parseDouble(actualBSATPD));
			int resultBSATPD=Integer.parseInt(columnMap.get("BSATPDStatus"));
			if(Math.abs(bsATPDDiff)<=pricingThreshold)
			{				
				matchBSATPD=true;
				DataHelper.writeToExcel(file,sheetName, index + 1, resultBSATPD, "PASS");			
			}
			Assert.assertTrue(matchBSATPD,"ATPD - Business Safeguard pricing verification");			
		}
		
		if(datamap.get(index).get("BSLife").equalsIgnoreCase("YES"))
		{
			boolean matchBSLife=false;
			String actualBSLife=sh_Quote_BuilderPage.getBSLifeValue(0).replaceAll(",", "");	
			DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("ActualBSLife")), actualBSLife);			
			String expectedBSLife = datamap.get(index).get("ExpectedBSLife").toString();		
			float bsLifeDiff=(float) (Double.parseDouble(expectedBSLife)-Double.parseDouble(actualBSLife));
			int resultBSLife=Integer.parseInt(columnMap.get("BSLifeStatus"));
			if(Math.abs(bsLifeDiff)<=pricingThreshold)
			{				
				matchBSLife=true;
				DataHelper.writeToExcel(file,sheetName, index + 1, resultBSLife, "PASS");			
			}
			Assert.assertTrue(matchBSLife,"Life - Business Safeguard pricing verification");
		}
				
	}
	
	//--------------------------------------------Business Continuity--------------------------------------------------------//
	//
	@When("^I select Business Continuity benefit$")
	public void i_select_Business_Continuity_benefit() throws Throwable {
		sh_Benefits_Selection.addBusinessContinuity();
	}

	//Business Continuity form
	@When("^I fill out Business Continuity form$")
	public void i_fill_out_Business_Continuity_form() throws Throwable {			
		sh_BC.selectSumAssuredFrequency("Monthly");
		sh_BC.enterSumAssured(datamap.get(index).get("SumAssured"), 0);
		sh_BC.selectIndexation(datamap.get(index).get("BCV_Indexed"), 0);
		sh_BC.selectBenefitType(datamap.get(index).get("BenefitType"), 0);
		sh_BC.selectPaymentPeriod(datamap.get(index).get("BenefitPaymentPeriod"), 0);
		sh_BC.selectWaitingPeriod(datamap.get(index).get("WaitingPeriod"), 0);
		sh_BC.selectPartialDisablement(datamap.get(index).get("PartialDisablement"), 0);
		sh_BC.enterBCLoadingPercentage(datamap.get(index).get("BCV_Loading"), 0);
	}
	//WoP form
	@When("^I fill out WoP form$")
	public void i_fill_out_WoP_form() throws Throwable {
		sh_BC.selectWoFWaitingPeriod(datamap.get(index).get("WA_Wait"), 0);
		sh_BC.enterWoPLoadingPercentage(datamap.get(index).get("WA_Loading"), 0);
	}
	
	//Business Continuity
    @Then("^the systems gives Business Continuity WoP and policy fees values$")
    public void the_system_gives_Business_Continuity_and_Policy_Fees() throws Throwable {		

        String UI_Total=sh_Quote_BuilderPage.getTotalPremium().replaceAll(",", "");
        String UI_BCV=sh_BC.getPremium(0).replaceAll(",", "");
        String UI_Waiver=sh_BC.getPremium(1).replaceAll(",", "");	
        String UI_PolFee=sh_Quote_BuilderPage.getPolicyFees().replaceAll(",", "");	
        DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("UI_Total")), UI_Total);
        DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("UI_BCV")), UI_BCV);
        DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("UI_Waiver")), UI_Waiver);
        DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("UI_PolFee")), UI_PolFee);	

        String Total = datamap.get(index).get("Total").toString();		
        String BCV = datamap.get(index).get("BCV").toString();
        String Waiver = datamap.get(index).get("Waiver").toString();
        String PolFee = datamap.get(index).get("PolFee").toString();	

        boolean match=false;
        float Diff_Total=(float) Math.abs((Double.parseDouble(UI_Total)-Double.parseDouble(Total)));
        float Diff_BCV=(float) Math.abs((Double.parseDouble(UI_BCV)-Double.parseDouble(BCV)));
        float Diff_Waiver=(float) Math.abs((Double.parseDouble(UI_Waiver)-Double.parseDouble(Waiver)));
        float Diff_PolFee=(float) Math.abs((Double.parseDouble(UI_PolFee)-Double.parseDouble(PolFee)));

        int resultColumn=Integer.parseInt(columnMap.get("RESULT"));
        if(Diff_Total<=pricingThreshold && Diff_BCV<=pricingThreshold && Diff_Waiver<=pricingThreshold && Diff_PolFee<=0 )
        {				
            match=true;
            DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "PASS");			
        }
        else
        {
            DataHelper.writeToExcel(file,sheetName, index + 1, resultColumn, "FAIL");
        }
        Assert.assertTrue(match,"Business Continuity pricing WoP & policy Fees verification");		
    }
    
  //Business Continuity Validation
    @Then("^I check out the error messages$")
    public void i_check_out_the_error_messages() throws Throwable {
    	String uiTotal=sh_Quote_BuilderPage.getTotalPremium().replaceAll(",", "");
    	DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("UI_Total")), uiTotal);
    	String total = datamap.get(index).get("Total").toString();
    	float Diff_Total=(float) Math.abs((Double.parseDouble(uiTotal)-Double.parseDouble(total)));
    	String uiMessages=sh_Quote_BuilderPage.getValidationMessageText();
    	DataHelper.writeToExcel(file,sheetName, index + 1,Integer.parseInt(columnMap.get("UI_Message")), uiMessages);
    	
    	boolean testPassed = false;
    	if(Diff_Total==0.0) testPassed = true;
    	Assert.assertTrue(testPassed,"Business Continuity Validation - Total Premium");
    }


}
