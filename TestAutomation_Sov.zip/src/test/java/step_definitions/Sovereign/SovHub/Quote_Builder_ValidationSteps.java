package step_definitions.Sovereign.SovHub;

import java.io.File;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import helpers.DataHelper;

import modules.DriverExtension;
import modules.Validation;
import pageobjects.SovHub.SH_AELA;
import pageobjects.SovHub.SH_APC;
import pageobjects.SovHub.SH_ATPD;
import pageobjects.SovHub.SH_AccelLivingAssurance;
import pageobjects.SovHub.SH_Benefits_Selection;
import pageobjects.SovHub.SH_EssentialDI;
import pageobjects.SovHub.SH_IncomeProtection;
import pageobjects.SovHub.SH_LifeBB;
import pageobjects.SovHub.SH_LivingAssurance;
import pageobjects.SovHub.SH_MortgageIncomeProtection;
import pageobjects.SovHub.SH_PrivateHealth;
import pageobjects.SovHub.SH_Quote_BuilderPage;
import pageobjects.SovHub.SH_SpecialistBenefit;
import pageobjects.SovHub.SH_TPDCondition;
import pageobjects.SovHub.SH_WaiverOfPremium;
import step_definitions.Hooks;

public class Quote_Builder_ValidationSteps {

	public WebDriver driver;	
	private SH_Quote_BuilderPage sh_Quote_BuilderPage;	
	private Validation validation;
	private SH_SpecialistBenefit sh_SpecialistBenefit;
	private SH_Benefits_Selection sh_Benefits_Selection;
	private SH_IncomeProtection sh_IncomeProtection;
	private SH_MortgageIncomeProtection sh_MortgageIncomeProtection;
	private SH_WaiverOfPremium sh_WaiverOfPremium;
	private SH_PrivateHealth sh_PrivateHealth;
	private SH_LivingAssurance sh_LivingAssurance;
	private SH_ATPD sh_ATPD;
	private SH_APC sh_APC;
	private SH_AccelLivingAssurance sh_ACLA;
	private SH_AELA sh_AELA;
	private SH_LifeBB sh_LifeBB;
	private SH_EssentialDI sh_EssentialDI;
	private SH_TPDCondition sh_TPDCondition;
	public List<HashMap<String,String>> datamap;	
	public int index;
	public String sheetName;
	public File file = new File("src/test/resources/testData/QuoteBuilderData.xlsx");

	public Quote_Builder_ValidationSteps()
	{
		driver = Hooks.driver;		
		sh_Quote_BuilderPage = new SH_Quote_BuilderPage(driver);		
		validation = new Validation();
		sh_SpecialistBenefit = new SH_SpecialistBenefit(driver);
		sh_Benefits_Selection = new SH_Benefits_Selection(driver);
		sh_IncomeProtection = new SH_IncomeProtection(driver);	
		sh_MortgageIncomeProtection = new SH_MortgageIncomeProtection(driver);
		sh_WaiverOfPremium = new SH_WaiverOfPremium(driver);
		sh_PrivateHealth = new SH_PrivateHealth(driver);
		sh_LivingAssurance = new SH_LivingAssurance(driver);
		sh_ATPD = new SH_ATPD(driver);
		sh_APC = new SH_APC(driver);
		sh_ACLA = new SH_AccelLivingAssurance(driver);
		sh_AELA = new SH_AELA(driver);
		sh_LifeBB = new SH_LifeBB(driver);
		sh_EssentialDI = new SH_EssentialDI(driver);
		sh_TPDCondition = new SH_TPDCondition(driver);
	}	
	
	@Then("^the system validates the age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_age_rule_correctly(String row_index,String sheetName) throws Throwable {				
		index = Integer.parseInt(row_index)-1;
		boolean status=sh_Benefits_Selection.getLifeCoverAvailability();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateStatus(file,sheetName,"Age Limit",datamap,index,status);			
	}	

	@Then("^the system validates the sum insured rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_sum_insured_rule_correctly(String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Sum Insured",datamap,index,actualMessage);		
	}

	@Then("^the system validates the premium option rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_premium_option_rule_correctly(String row_index,String sheetName) throws Throwable {		
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Premium Option",datamap,index,actualMessage);		
	}

	@Then("^the system validates the FI premium option rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_FI_premium_option_rule_correctly(String row_index,String sheetName) throws Throwable {		
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getFIValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"FI premium Option",datamap,index,actualMessage);		
	}

	@Then("^the system validates the Loading term rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_Loading_term_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Loading term",datamap,index,actualMessage);		
	}

	@Then("^the system validates the Loading percentage rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_Loading_percentage_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Loading percentage",datamap,index,actualMessage);		
	}

	@Then("^the system validates the Loading Per Mille rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_Loading_Per_Mille_rule_correctly(String row_index,String sheetName) throws Throwable {		
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Loading Per Mille",datamap,index,actualMessage);		
	}

	@Then("^the system validates the FI Age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_FI_Age_rule_correctly(String row_index,String sheetName) throws Throwable {		
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getFIValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Future Insurability Age",datamap,index,actualMessage);		
	}

	@Then("^the system validates the FI Sum Assured rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_FI_Sum_Assured_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getFIValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Future Insurability Sum Assured",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the SDT Age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_SDT_Age_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText()+","+sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Specialist & Diagnostic Testing Age",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the SDT with Life error rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_SDT_Life_error_selection_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText()+","+sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Specialist & Diagnostic Testing with Life loading error",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the SDT Loading percentage rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_SDT_Loading_percentage_rule_correctly(String row_index,String sheetName) throws Throwable {		
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Specialist & Diagnostic Testing Loading percentage",datamap,index,actualMessage);	
			
	}
	
	@Then("^the system validates the SDT Eligibility Sum Assured rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_SDT_eligibility_sum_assured_rule_correctly(String row_index,String sheetName) throws Throwable {		
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Specialist & Diagnostic Testing Eligibility Sum Assured rule",datamap,index,actualMessage);	
		
	}
	
	@Then("^the system validates the age mandatory rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_age_mandatory_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getAgeValidationMessage();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Age Mandatory",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the smoking status mandatory rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_smoking_status_mandatory_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getPleaseSelectMessage();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Smoking Status Mandatory",datamap,index,actualMessage);
			
	}
	
	@Then("^the system validates the indexation mandatory rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_indexation_mandatory_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Indexation Mandatory",datamap,index,actualMessage);
			
	}
	
	@Then("^the system validates the gender mandatory rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_gender_mandatory_rule_correctly(String row_index,String sheetName) throws Throwable {		
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getPleaseSelectMessage();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Gender Mandatory",datamap,index,actualMessage);
		
	}
	
	@Then("^the system validates the WoP Waiting Period for Occupation rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_WoP_waiting_Period_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"WoP Waiting Period for Occupation rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the WoP Occupation class rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_WoP_occupation_class_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"WoP Occupation class U rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the blank WoP Occupation class rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_blank_WoP_occupation_class_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"WoP blank Occupation class rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the WoP age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_WoP_age_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		boolean status=sh_Benefits_Selection.isWoPDisabled();
		validation.validateStatus(file,sheetName,"WoP Age Limit",datamap,index,status);			
	}	
	
	@Then("^the system validates the WoP Occupation class Age rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_WoP_occupation_class_Age_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"WoP Occupation class Age rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the WoP Premium Option rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_WoP_premium_option_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"WoP Premium Option rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the WoP Loading percentage rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_WoP_Loading_percentage_rule_correctly(String row_index,String sheetName) throws Throwable {		
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"WoP loading percentage rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the WoP Premium Option rule To Age 80 for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_WoP_premium_option_Age80_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"WoP Premium Option To Age 80 rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the WoP selection rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_WoP_selection_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isWoPDisabled())
		{
			status=true;
		}		
		validation.validateStatus(file,sheetName,"WoP Selection rule",datamap,index,status);			
	}
	
	@Then("^the system validates the SDT selection rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_SDT_selection_rule(String row_index,String sheetName) throws Throwable {			
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isSDTDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"SDT selection rule",datamap,index,status);		
	}
	
	@Then("^the system selects WoP automatically for (.*) from \"(.*)\" Sheet$")
	public void the_system_selects_WoP_automatically(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		boolean status=sh_Benefits_Selection.checkWoPAutomaticSelection();
		validation.validateStatus(file,sheetName,"Income Protection - WoP automatic Selection",datamap,index,status);			
	}
	
	@Then("^the system removes WoP and SDT automatically for (.*) from \"(.*)\" Sheet$")
	public void the_system_removes_WoP_and_SDT_automatically(String row_index,String sheetName) throws Throwable {			
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isWoPDisabled() && sh_Benefits_Selection.isSDTDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"WoP & SDT removal after IP deselection",datamap,index,status);		
	}
	
	@Then("^the system removes WoP and Redundancy automatically for (.*) from \"(.*)\" Sheet$")
	public void the_system_removes_WoP_and_Redundancy_automatically(String row_index,String sheetName) throws Throwable {			
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isWoPDisabled() && sh_Benefits_Selection.isRedundancyDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"WoP & Redundancy removal after IP/MIP deselection",datamap,index,status);		
	}
	
	@Then("^the system validates redundancy selection rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_Redundancy_selection(String row_index,String sheetName) throws Throwable {			
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isRedundancyDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"Redundancy Disabled without IP/MIP selection",datamap,index,status);		
	}	
	
	@Then("^the system validates the IP age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_IP_age_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isIPDisabled() && sh_Benefits_Selection.isWoPDisabled() && sh_Benefits_Selection.isSDTDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"Income Protection Age limit",datamap,index,status);			
	}
	
	@Then("^the system validates the redundancy age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_redundancy_age_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isIPDisabled() && sh_Benefits_Selection.isMIPDisabled() && sh_Benefits_Selection.isRedundancyDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"Redundancy Age limit",datamap,index,status);			
	}
	
	@Then("^the system validates the ATPD age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_ATPD_age_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Quote_BuilderPage.isATPDDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"Accelerated Total Permanent Disablement Age limit",datamap,index,status);			
	}
	
	@Then("^the system validates the ATPD occupation class rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_ATPD_occupation_class_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Quote_BuilderPage.isATPDDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"Accelerated Total Permanent Disablement Occupation Class",datamap,index,status);			
	}
	
	@Then("^the system validates the redundancy occupation class rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_redundancy_occupation_class_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isIPDisabled() && sh_Benefits_Selection.isMIPDisabled() && sh_Benefits_Selection.isRedundancyDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"Redundancy occupation Class 5 & U rule",datamap,index,status);			
	}
	
	@Then("^the system validates the redundancy self employed rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_redundancy_self_employed_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isRedundancyDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"Redundancy Self-employed",datamap,index,status);			
	}
	
	@Then("^the system validates the MIP age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_MIP_age_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isMIPDisabled() && sh_Benefits_Selection.isWoPDisabled() && sh_Benefits_Selection.isSDTDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"Mortgage Income Protection Age limit",datamap,index,status);			
	}	
	
	@Then("^the system validates the TPD age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_TPD_age_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isTPDDisabled() && sh_Benefits_Selection.isWoPDisabled() && sh_Benefits_Selection.isSDTDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"Total Permanent Disablement Age limit",datamap,index,status);			
	}
	
	@Then("^the system validates the TPD Occupation class rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_TPD_Occupation_class_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isTPDDisabled() && sh_Benefits_Selection.isWoPDisabled() && sh_Benefits_Selection.isSDTDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"Total Permanent Disablement Age limit",datamap,index,status);			
	}
	
	@Then("^the system validates the TPD and Sub benefits age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_TPD_Sub_Benefit_age_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText()+"\n"+sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Total Permanent Disablement and Sub benefits Age limit",datamap,index,actualMessage);				
	}
	
	@Then("^the system validates the TPD and WoP age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_TPD_WoP_age_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Total Permanent Disablement and WoP Age limit",datamap,index,actualMessage);				
	}
	
	@Then("^the system validates the redundancy ineligible age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_redundancy_ineligible_age_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText()+"\n"+sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"IP/MIP and Redundancy Age limit",datamap,index,actualMessage);				
	}
	
	@Then("^the system validates the ATPD ineligible age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_ATPD_ineligible_age_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"ATPD Ineligible Age limit",datamap,index,actualMessage);				
	}
	
	@Then("^the system validates the MIP occupation class 9 rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_MIP_occupation_class9_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isMIPDisabled() && sh_Benefits_Selection.isWoPDisabled() && sh_Benefits_Selection.isSDTDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"Mortgage Income Protection Occupation Class U rule",datamap,index,status);			
	}
	
	@Then("^the system validates the IP Sum Assured rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_IP_sum_assured_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Income Protection Sum Assured rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the Redundancy Sum Assured rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_Redundancy_sum_assured_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Redundancy Sum Assured rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the Redundancy employment status rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_Redundancy_employment_status_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Redundancy employment status rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the Redundancy blank occupation class rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_Redundancy_blank_occupation_rule (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText()+"\n"+sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Redundancy blank occupation class rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the Redundancy occupation class rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_Redundancy_occupation_rule (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText()+"\n"+sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Redundancy occupation class 5 & U rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the MIP Sum Assured rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_MIP_sum_assured_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Mortgage and Income Protection Sum Assured rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the TPD Sum Assured rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_TPD_sum_assured_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Total Permanent Disablement Sum Assured rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the TPD Premium Option rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_TPD_premium_option_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Total Permanent Disablement Premium Option for Ages [56-60] and Benefit Term for To Age 65 rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the TPD Benefit Term or Type rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_TPD_benefit_term_type_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Total Permanent Disablement Benefit Term and Type rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the IP Occupation class rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_IP_occupation_class_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Income Protection Occupation class rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the IP Occupation class U rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_IP_occupation_class_U_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Income Protection Occupation class U rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the MIP Occupation class U rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_MIP_occupation_class_U_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Mortgage Income Protection Occupation class U rule",datamap,index,actualMessage);
		
	}
	
	@Then("^the system validates the MIP Ineligible Age rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_MIP_Ineligible_Age_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Mortgage Income Protection Ineligible Age  rule",datamap,index,actualMessage);
		
	}
	
	@Then("^the system validates the TPD Occupation class U rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_TPD_occupation_class_U_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Total permanent Disablement Occupation class U rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the TPD Occupation class for Age rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_TPD_occupation_class_for_Age_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Total permanent Disablement Occupation class[3-5] for Ages[56-60] rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the IP Occupation class for Age rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_IP_occupation_class_for_Age_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Income Protection Occupation class for Age rule",datamap,index,actualMessage);
		
	}
	
	@Then("^the system validates the MIP Occupation class for Age rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_MIP_occupation_class_for_Age_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Mortgage Income Protection Occupation class for Age rule",datamap,index,actualMessage);
	
	}
	
	@Then("^the system validates the IP payment period for Occupation class5 rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_IP_payment_period_for_occupation_class5_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Income Protection payment period for Occupation class5 rule",datamap,index,actualMessage);
		
	}
	
	@Then("^the system validates the IP premium option to Age 65 rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_IP_premium_option_to_Age65_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Income Protection premium option to Age 65 rule",datamap,index,actualMessage);
		
	}
	

	@Then("^the system validates the MIP premium option to Age 65 rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_MIP_premium_option_to_Age65_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Mortgage Income Protection premium option to Age 65 rule",datamap,index,actualMessage);
		
	}
	
	@Then("^the system validates the MIP payment period rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_MIP_payment_period_to_Age65_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"MIP - Occupation Class 5 - Waiting period, Payment Period 'To Age 70' and PP 70 - Premium Option '10 Year, To Age 65' rule",datamap,index,actualMessage);
		
	}
	
	@Then("^the system validates the IP waiting period rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_IP_waiting_period_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Income Protection Waiting period for Occupation class 3 & 4 rule",datamap,index,actualMessage);
		
	}
	
	@Then("^the system validates the IP Occupation class 5 rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_IP_occupation_class5_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText()+","+sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Income Protection Occupation class 5 rule",datamap,index,actualMessage);		
		
	}
	
	@Then("^the system validates the IP payment period rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_IP_payment_period_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Income Protection payment period rule",datamap,index,actualMessage);
		
	}
	
	@Then("^the system validates the IP waiting period104 rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_IP_waiting_period_104_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Income Protection waiting period rule",datamap,index,actualMessage);
		
	}
	
	@Then("^the system validates the MIP waiting period104 rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_MIP_waiting_period_104_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Mortgage Income Protection waiting period rule",datamap,index,actualMessage);
		
	}
	
	@Then("^the system validates the MIP Mortgage Repayment amount rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_MIP_mortgage_repayment_amount_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Mortgage Income Protection waiting period rule",datamap,index,actualMessage);
		
	}
	
	@Then("^the system validates the IP Premier Option rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_IP_Premier_Option_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Income Protection Premier Option rule",datamap,index,actualMessage);		
		
	}
	
	@Then("^the system validates the IP Premier Option for Occupation class rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_IP_premier_option_for_occupation_class_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Income Protection Premier Option for Occupation class rule",datamap,index,actualMessage);
		
	}
	
	@Then("^the system validates the IP Payment Period for Occupation class5 rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_IP_payment_period_for_occupation_class5_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Income Protection Payment Period for Occupation class5 rule",datamap,index,actualMessage);
		
	}
	
	@Then("^the system validates the IP Loading Percentage rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_IP_loading_percentage_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Income Protection loading percentage rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the MIP Loading Percentage rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_MIP_loading_percentage_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText()+","+sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Mortgage Income Protection loading percentage and S&T rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the TPD Loading Percentage rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_TPD_loading_percentage_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText()+","+sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Total Permanent Disablement loading percentage and S&T rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the ATPD Loading Percentage rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_ATPD_loading_percentage_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Accelerated Total Permanent Disablement loading percentage",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the Life and ATPD Loading Percentage rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_Life_ATPD_loading_percentage_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText()+","+sh_Quote_BuilderPage.getAdditionalValidationMessageText()+","+sh_Quote_BuilderPage.getThirdValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Life and Accelerated Total Permanent Disablement loading percentage with S&T",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the TPD Loading values rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_TPD_loading_values_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Total Permanent Disablement loading per mille and loading term rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the TPD Blank Occupation class rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_TPD_Blank_Occupation_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Total Permanent Disablement Blank Occupation Class rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the IP and WoP waiting Period rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_IP_and_WoP_Waiting_period_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Income Protection and WoP waiting Period rule",datamap,index,actualMessage);
		
	}
	
	@Then("^the system validates the MIP and WoP waiting Period rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_MIP_and_WoP_Waiting_period_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Mortgage Income Protection and WoP waiting Period rule",datamap,index,actualMessage);
		
	}
	
	@Then("^the system validates the MIP and SDT Sum Assured eligibility rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_MIP_and_SDT_Sum_Assured_eligibility (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Mortgage Income Protection and SDT Sum Assured eligibility rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the IP WoP Loading Percentage rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_IPWoP_loading_percentage_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Income Protection WoP loading percentage rule",datamap,index,actualMessage);
		
	}
	
	@Then("^the system validates the IP and SDT Sum assured eligibility rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_IP_SDT_Sum_assured_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"IP and SDT Sum assured eligibility rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the MIP WoP Loading Percentage rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_MIPWoP_loading_percentage_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Mortgage Income Protection WoP loading percentage rule",datamap,index,actualMessage);
		
	}
	
		@Then("^Health Plus and Health Waiver on the selection page are not available for (.*) from \"(.*)\" Sheet$")
	public void the_Private_Health_benefit_cannot_be_selecteed(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		boolean status =sh_Benefits_Selection.isHealthPlusDisabled() && sh_Benefits_Selection.isHealthWaiverDisabled();
		
		validation.validateStatus(file,sheetName,"Health Cover - Age Validation",datamap,index,status);		
	}
	
	@Then("^the systems shows Health Cover loading error messgage for (.*) from \"(.*)\" Sheet$")
	public void the_system_shows_health_cover_loading_error_message(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		String actualMessage = sh_Quote_BuilderPage.getValidationMessageText();
		validation.validateMessage(file,sheetName,"Health Cover Loading Validation",datamap,index,actualMessage);
			
	}
	
	@Then("^the systems shows Health Plus loading error messgage for (.*) from \"(.*)\" Sheet$")
	public void the_system_shows_health_plus_loading_error_message(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		
		//Verify Health Cover with no error message
	//	String actualMessage = sh_Quote_BuilderPage.getValidationMessageText();
	//	Assert.assertEquals(actualMessage, "", "Health Cover - no error message");	
		
		//Verify Health Plus error message
	//	String actualHPMessage = sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		String actualHPMessage = sh_Quote_BuilderPage.getValidationMessageText();
		validation.validateMessage(file,sheetName,"Health Plus Loading Validation",datamap,index,actualHPMessage);
		
			
	}
	@Then("^the systems shows Health Cover ineligible error messgage for (.*) from \"(.*)\" Sheet$")
	public void the_system_shows_health_cover_ineligible_error_message(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		//String actualMessage = sh_Quote_BuilderPage.getHCIneligibleErrorMessage();
		String actualMessage = sh_Quote_BuilderPage.getValidationMessageText();
		validation.validateMessage(file,sheetName,"Health Cover ineligible Validation",datamap,index,actualMessage);
				
	}
	
	@Then("^the systems shows Health Plus ineligible error messgage for (.*) from \"(.*)\" Sheet$")
	public void the_system_shows_health_plus_ineligible_error_message(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		//String actualHPMessage = sh_Quote_BuilderPage.getHPIneligibleErrorMessage();
		String actualHPMessage = sh_Quote_BuilderPage.getValidationMessageText();
		validation.validateMessage(file,sheetName,"Health Plus ineligible Validation",datamap,index,actualHPMessage);
				
	}
	
	@Then("^the system validates the SCLA age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_SCLA_age_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isLADisabled() && sh_Benefits_Selection.isWoPDisabled() && sh_Benefits_Selection.isSDTDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"SCLA Age limit",datamap,index,status);			
	}
	
	@Then("^the system validates the SCLA premium option rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_SCLA_premium_option_rule(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		String actualMessage = sh_Quote_BuilderPage.getValidationMessageText();
		validation.validateMessage(file,sheetName,"SCLA premium option Validation",datamap,index,actualMessage); 
		
		
	}
	
	@Then("^the system validates the SCLA premium option and sum assured rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_SCLA_premium_option_and_sum_assured_rule(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		validation.validateMessage(file,sheetName,"SCLA premium option and sum Assured Validation",datamap,index,actualMessage); 
	
	}
	
	@Then("^the system validates the SCLA sum assured rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_SCLA_sum_assured_rule(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		String actualMessage = sh_Quote_BuilderPage.getValidationMessageText();
		validation.validateMessage(file,sheetName,"SCLA Sum Assured Validation",datamap,index,actualMessage); 
			
	}
	
	@Then("^the system validates the SCLA loading percentage and per mille rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_SCLA_loading_percentage_and_per_mille_rule(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		validation.validateMessage(file,sheetName,"SCLA loading percentage and per mille Validation",datamap,index,actualMessage); 
			
	}
	@Then("^the systems shows Health Benefit loading invalid format error messgage for (.*) from \"(.*)\" Sheet$")
	public void the_system_shows_health_cover_loading_invalid_format_error_message(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		String actualMessage = sh_Quote_BuilderPage.getInputErrorMessage();
		validation.validateMessage(file,sheetName,"Health Benefit Loading Validation",datamap,index,actualMessage);
	}
	
	@Then("^the system validates the SCLA loading term rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_SCLA_loading_term_rule(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		String actualMessage = sh_Quote_BuilderPage.getValidationMessageText();
		validation.validateMessage(file,sheetName,"SCLA Loading term Validation",datamap,index,actualMessage); 
			
	}
	
	@Then("^the system validates the SCLA and SDT validation rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_SCLA_SDT_validation_rule(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		validation.validateMessage(file,sheetName,"SCLA and SDT validation",datamap,index,actualMessage); 
		
	}
	
	@Then("^the system validates the SCLA and SDT sum assured eligibility correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_SCLA_SDT_sum_assured_eligibility_rule(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		validation.validateMessage(file,sheetName,"SCLA and SDT validation",datamap,index,actualMessage); 			
	}
	
	@Then("^the system validates the TPD and SDT sum assured eligibility correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_TPD_SDT_sum_assured_eligibility_rule(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		validation.validateMessage(file,sheetName,"TPD Standalone and SDT validation",datamap,index,actualMessage); 			
	}
	
	@Then("^the system shows Health WoP on the selection page is not available for (.*) from \"(.*)\" Sheet$")
	public void the_system_shows_Health_Waiver_on_the_selection_page_is_not_available(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		//Check Health Waiver of Premium benefit icon should be disabled
		boolean isDisplayed = sh_Benefits_Selection.isHealthWaiverDisabled();
		String actualMessage = "";
		if(isDisplayed)
		{
			actualMessage = "Health Waiver of premium is not available";
		}
		else
		{
			actualMessage = "cannot find the disabled icon for Health Waiver of Premium";			
		}
		validation.validateMessage(file,sheetName,"Health Waiver of Premium Age Validation",datamap,index,actualMessage);
		/*Check Health Cover status
		Assert.assertTrue(sh_PrivateHealth.isHCStatusSuccessful(),"Health Waiver of Premium - Age Validation");
		//Check Health Plus status
		if(datamap.get(index).get("HPRequired").equals("Yes"))
		{
			Assert.assertTrue(sh_PrivateHealth.isHPStatusSuccessful(),"Health Waiver of Premium - Age Validation");
		}*/
		//Check Health Waiver of Premium status which should be warning
		Assert.assertTrue(isDisplayed,"Health Waiver of Premium - Age Validation");
		
	}
	@Then("^the system shows Health WoP invalid error messgage for (.*) from \"(.*)\" Sheet$")
	public void the_system_shows_Health_Wavier_invalid_error_message(String row_index, String sheetName) throws Throwable
	{		
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		//Verify Health Cover with no error message
		//String actualMessage = sh_Quote_BuilderPage.getValidationMessageText();
		//Assert.assertEquals(actualMessage, "", "Health Cover - no error message");	
		
		//Verify Health Waiver error message
		//String actualHWMessage = sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		String actualHWMessage = sh_Quote_BuilderPage.getValidationMessageText();
		validation.validateMessage(file,sheetName,"Health Waiver Validation",datamap,index,actualHWMessage);		
					
	}
	
	@Then("^the system shows Health WoP ineligible error messgage for (.*) from \"(.*)\" Sheet$")
	public void the_system_shows_Health_WoP_ineligible_error_message(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		//String actualHPMessage = sh_Quote_BuilderPage.getHWIneligibleErrorMessage();
		String actualHPMessage = sh_Quote_BuilderPage.getValidationMessageText();
		validation.validateMessage(file,sheetName,"Health WoP ineligible Validation",datamap,index,actualHPMessage);		
	}
	
	@Then("^the system validates the ACLA age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_ACLA_age_rule_correctly(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Quote_BuilderPage.isAccelLivingAssuranceDisabled(0))
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"ACLA Age limit",datamap,index,status);	
	}	

	@Then("^the system validates the ACLA Premium Option rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_ACLA_premium_option_rule_correctly(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		//Verify ACLA with error message
		String actualMessage = sh_Quote_BuilderPage.getValidationMessageText();
		validation.validateMessage(file,sheetName,"ACLA Validation",datamap,index,actualMessage);	
		
	}
	
	
	@Then("^the system validates the ACLA rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_ACLA_rule_correctly(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		//Verify ACLA with error message
		String actualMessage = sh_Quote_BuilderPage.getValidationMessageText();
		
		validation.validateMessage(file,sheetName,"ACLA Validation",datamap,index,actualMessage);
		
	}
	
	@Then("^the system validates the ACLA and SCLA sum assured for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_ACLA_and_SCLA_sum_assured(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		//Verify ACLA and SCLA with error message
		String actualMessage = sh_Quote_BuilderPage.getValidationMessageText();
		
		validation.validateMessage(file,sheetName,"ACLA Validation",datamap,index,actualMessage.trim());
		
	}
	
	@Then("^the system validates the ACLA ineligibility rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_ACLA_ineligibility_rule_correctly(String row_index, String sheetName) throws Throwable
	{
		
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		//Verify ACLA with error message
		//String actualMessage = sh_Quote_BuilderPage.getIneligibleBenefitText() + " " + sh_Quote_BuilderPage.getIneligibleAdditionalBenefitText();
		String actualMessage = sh_Quote_BuilderPage.getValidationMessageText() + " " + sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		validation.validateMessage(file,sheetName,"ACLA Ineligibility Validation",datamap,index,actualMessage);
	}
	
	@Then("^the system removes the ACLA automatically for (.*) from \"(.*)\" Sheet$")
	public void the_system_removes_the_ACLA_automatically(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Quote_BuilderPage.isLifeSectionDisplayed() && sh_ACLA.isACLASectionDisplayed())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"ACLA removal after Life Cover deselection",datamap,index,status);	
		
	}
	
	@Then("^the system validates the APC age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_APC_age_rule_correctly(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Quote_BuilderPage.isAPCDisabled(0))
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"APC Age limit",datamap,index,status);	
		
	}
	
	@Then("^the system validates the APC Premium Option rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_APC_Premium_Option_rule_correctly(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		//Verify APC with error message
		String actualMessage = sh_Quote_BuilderPage.getValidationMessageText();		
		validation.validateMessage(file,sheetName,"APC Validation",datamap,index,actualMessage);
	}
	
	@Then("^the system validates the APC rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_APC_rule_correctly(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		//Verify APC with error message
		String actualMessage = sh_Quote_BuilderPage.getValidationMessageText();
		validation.validateMessage(file,sheetName,"APC Validation",datamap,index,actualMessage);
	}
	
	@Then("^the system validates the APC and SPC sum assured for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_APC_and_SPC_sum_assured(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		//Verify APC with error message
		String actualMessage = sh_Quote_BuilderPage.getValidationMessageText();
		validation.validateMessage(file,sheetName,"APC and SPC Sum assured Validation",datamap,index,actualMessage.trim());
	}
	
	
	@Then("^the system validates the APC ineligibility rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_APC_ineligibility_rule_correctly(String row_index, String sheetName) throws Throwable
	{		
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		//Verify APC with error message
		//String actualMessage = sh_Quote_BuilderPage.getIneligibleBenefitText() + " " + sh_Quote_BuilderPage.getIneligibleAdditionalBenefitText();
		String actualMessage = sh_Quote_BuilderPage.getValidationMessageText() + " " + sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		validation.validateMessage(file,sheetName,"APC Ineligibility Validation",datamap,index,actualMessage);
	}
	
	@Then("^the system removes the APC automatically for (.*) from \"(.*)\" Sheet$")
	public void the_system_removes_the_APC_automatically(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Quote_BuilderPage.isLifeSectionDisplayed() && sh_APC.isAPCSectionDisplayed())
		{
			status=true;
		}
		
		validation.validateStatus(file,sheetName,"APC removal after Life Cover deselection",datamap,index,status);	
		
	}
	
	@Then("^the system validates the SPC age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_syste_validates_the_SPC_age_rule_correctly(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isSPCDisabled() && sh_Benefits_Selection.isWoPDisabled() && sh_Benefits_Selection.isSDTDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"SPC Age limit",datamap,index,status);	
		
	}
	
	@Then("^the system validates the SPC rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_SPC_rule_correctly(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		//Verify APC with error message
		String actualMessage = sh_Quote_BuilderPage.getValidationMessageText();
		validation.validateMessage(file,sheetName,"SPC Validation",datamap,index,actualMessage);
		
	}
	
	@Then("^the system validates the SPC and SDT validation rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_SPC_SDT_validation_rule(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		validation.validateMessage(file,sheetName,"SPC and SDT validation",datamap,index,actualMessage); 
		
	}
	
	@Then("^the system validates the SPC and SDT sum assured eligibility correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_SPC_SDT_sum_assured_eligibility_rule(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();// + "\n"+ sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		validation.validateMessage(file,sheetName,"SPC and SDT validation",datamap,index,actualMessage); 			
	}
	
	@Then("^the system removes ATPD automatically for (.*) from \"(.*)\" Sheet$")
	public void the_system_removes_ATPD_Redundancy_automatically(String row_index,String sheetName) throws Throwable {			
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Quote_BuilderPage.isLifeSectionDisplayed() && sh_ATPD.isATPDSectionDisplayed())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"ATPD removal after Life cover deselection",datamap,index,status);		
	}
	
	@Then("the system shows Retirement Protection unavailably for (.*) from \"(.*)\" Sheet$")
	public void the_system_shows_Retirement_Protection_unavailably(String row_index,String sheetName) throws Throwable 
	{
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isRPDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"RP unavailably before selecting IP/MIP",datamap,index,status);		
	}
	
	@Then("^the system removes WoP and Retirement Protection automatically for (.*) from \"(.*)\" Sheet$")
	public void the_system_removes_Wop_and_Retirement_Protection_automatically(String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isWoPDisabled() && sh_Benefits_Selection.isRPDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"WoP & RP removal after IP/MIP deselection",datamap,index,status);		
	}

	
	/*@Then("^the system validates the RP age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_RP_age_rule_correctly(String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isIPDisabled() && sh_Benefits_Selection.isMIPDisabled() && sh_Benefits_Selection.isRPDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"RP Age validation",datamap,index,status);		
	}*/
	
	@Then("^the system validates the RP ineligible age rule with (.*) error messages correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_RP_ineligible_age_rule_with_error_message_correctly( int count, String row_index,String sheetName) throws Throwable 
	{
		index = Integer.parseInt(row_index)-1;
		String actualMessage="";	
		if(count == 2)
		{
			actualMessage=sh_Quote_BuilderPage.getValidationMessageText()+"\n"+sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		}
		if(count == 3)
		{
			actualMessage=sh_Quote_BuilderPage.getValidationMessageText()+"\n"+sh_Quote_BuilderPage.getAdditionalValidationMessageText() + "\n"+sh_Quote_BuilderPage.getThirdValidationMessageText();
		}
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"IP/MIP and RP Age limit",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the RP employment status rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_RP_employment_status_rule(String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		//String actualMessage=sh_Quote_BuilderPage.getIneligibleBenefitText()+"\n"+sh_Quote_BuilderPage.getIneligibleAdditionalBenefitText();
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"IP/MIP and RP Employment limit",datamap,index,actualMessage);	
	}
	
	@Then("^the system validates the RP occupation class rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_RP_occupuation_class_rule(String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		//String actualMessage=sh_Quote_BuilderPage.getIneligibleBenefitText()+"\n"+sh_Quote_BuilderPage.getIneligibleAdditionalBenefitText();
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText()+"\n"+sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"IP/MIP and RP occupation class limit",datamap,index,actualMessage);	
	}
	
	@Then("the system validates the RP occupation class 5 rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_RP_occupuation_class_5_rule(String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;		
		//String actualMessage= sh_Quote_BuilderPage.getIneligibleBenefitText();
		String actualMessage= sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"IP/MIP and RP occupation class 5 limit",datamap,index,actualMessage);	
	}
	
	@Then("the system validates the RP occupation class U rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_RP_occupuation_class_U_rule(String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;		
		//String actualMessage=sh_Quote_BuilderPage.getIneligibleBenefitText()+"\n" + sh_Quote_BuilderPage.getIneligibleAdditionalBenefitText() 
		//						+ "\n" + sh_Quote_BuilderPage.getIneligibleThirdBenefitText();
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText()+"\n" + sh_Quote_BuilderPage.getAdditionalValidationMessageText();
										
														
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"IP/MIP and RP occupation class U limit",datamap,index,actualMessage);	
	}
	@Then("^the system shows Retirement Protection unavailable for Occupation class rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_RP_unvailaby_for_occupuation_class_rule(String row_index,String sheetName) throws Throwable 
	{
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if( sh_Benefits_Selection.isRPDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"RP Occupation class limit",datamap,index,status);				
	}
	
	@Then("^the system validates the RP validation rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_RP_validation_rule(String row_index,String sheetName) throws Throwable 
	{
		index = Integer.parseInt(row_index)-1;		
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText()+"\n"+sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);		
		validation.validateMessage(file,sheetName,"RP validation rule",datamap,index,actualMessage);			
	}
	
	@Then("^the system validates the RP loading validation rule with (.*) error message for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_RP_validation_rule_with_error_message(int error_count, String row_index,String sheetName) throws Throwable 
	{
		index = Integer.parseInt(row_index)-1;		
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
	    if(error_count > 1)
	    {
	    	actualMessage += "\n"+sh_Quote_BuilderPage.getAdditionalValidationMessageText();
	    }
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);		
		validation.validateMessage(file,sheetName,"RP Loading validation rule",datamap,index,actualMessage);			
	}
	
	@Then("the system validates the RP Sum Assured validation rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_RP_Sum_Assured_rule(String row_index,String sheetName) throws Throwable 
	{
		index = Integer.parseInt(row_index)-1;		
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);		
		validation.validateMessage(file,sheetName,"RP SA validation rule",datamap,index,actualMessage);			
	}
	@Then("^the system shows IP,MIP and Retirement Protection unavailable for Occupation class rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_shows_the_IP_MIP_RP_unavialble_rule(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if( sh_Benefits_Selection.isRPDisabled() && sh_Benefits_Selection.isIPDisabled() && sh_Benefits_Selection.isMIPDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"RP Occupation class limit",datamap,index,status);				
	}
	
	@Then("^the system validates the AD age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_AD_age_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isADDisabled() && sh_Benefits_Selection.isAICDisabled() && sh_Benefits_Selection.isWoPDisabled() && sh_Benefits_Selection.isSDTDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"Accidental Death Benefit Age limit",datamap,index,status);			
	}
	
	@Then("^the system validates the AD ineligible age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_AD_ineligible_age_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Accidental Death Ineligible Age limit",datamap,index,actualMessage);				
	}
	
	@Then("^the system validates the AD validation rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_AD_validation_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText()+"\n"+sh_Quote_BuilderPage.getAdditionalValidationMessageText()+"\n"+sh_Quote_BuilderPage.getThirdValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Accidental Death rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the AD Sum Assured validation rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_AD_sum_assured_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Accidental Death Sum Assured rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system removes the AIC and WoP And S&T automatically for (.*) from \"(.*)\" Sheet$")
	public void the_system_removes_the_AD_sub_benefits(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isWoPDisabled() && sh_Benefits_Selection.isAICDisabled() && sh_Benefits_Selection.isSDTDisabled())
		{
			status=true;
		}		
		validation.validateStatus(file,sheetName,"Optional benefits removal",datamap,index,status);			
	}
	
	@Then("^the system validates the AD and SDT Sum assured eligibility rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_AD_SDT_Sum_assured_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"AD and SDT Sum assured eligibility rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the ECU rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_ECU_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isECUDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"Early Cancer Upgrade Selection",datamap,index,status);			
	}	
	
	@Then("^the system validates the ECU validation rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_ECU_validation_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"ECU Validation rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the ECU ineligible benefit rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_ECU_ineligible_benefit_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"ECU Ineligible benefit rule",datamap,index,actualMessage);				
	}
	
	@Then("^the system validates the Parent and ECU ineligible benefit rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_ACLA_ECU_ineligible_benefit_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText()+"\n"+sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"ACLA & ECU Ineligible benefit rule",datamap,index,actualMessage);				
	}
	
	
	@Then("^the system validates the SCLA and ACLA rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_SCLA_ACLA_rule_correctly(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		
		String actualMessage = sh_Quote_BuilderPage.getValidationMessageText()+"\n"+sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		
		validation.validateMessage(file,sheetName,"ACLA & SCLA Validation",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the ECU and Parent validation rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_ECU_Parent_validation_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText()+"\n"+sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"ECU and Parent Validation rule",datamap,index,actualMessage);		
	}
	

	@Then("^the system validates the LifeBB age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_LifeBB_age_rule_correctly(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Quote_BuilderPage.isAccelLivingAssuranceDisabled(0) && sh_Quote_BuilderPage.isAELADisabled(0))
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"LifeBB Age limit",datamap,index,status);	
	}
	
	@Then("^the system gives error messages (.*) with Life BuyBack for (.*) from \"(.*)\" Sheet$")
	public void the_system_gives_error_message_for_Life_BuyBack(int countErrorMessage, String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		String actualMessage = "";
		if(countErrorMessage == 2)
		{			
			actualMessage=sh_Quote_BuilderPage.getBuyBackMessageText() + "\n" + sh_Quote_BuilderPage.getValidationMessageText();
		}
		if(countErrorMessage == 3)
		{
			actualMessage=sh_Quote_BuilderPage.getBuyBackMessageText() + "\n" + sh_Quote_BuilderPage.getValidationMessageText()+"\n"+sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		}
		
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"LifeBB Validation rule",datamap,index,actualMessage);		
	}
	
	@Then("^the system gives ineligible messages (.*) with Life BuyBack for (.*) from \"(.*)\" Sheet$")
	public void the_system_gives_ineligible_message_with_Life_Buyback(int countErrorMessage, String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		String actualMessage = "";
		if(countErrorMessage == 1)
		{			
			//actualMessage=sh_Quote_BuilderPage.getIneligibleBenefitText();
			actualMessage=sh_Quote_BuilderPage.getBuyBackMessageText();
		}
		if(countErrorMessage == 2)
		{
			//actualMessage=sh_Quote_BuilderPage.getIneligibleBenefitText()+"\n"+sh_Quote_BuilderPage.getIneligibleAdditionalBenefitText();
			actualMessage=sh_Quote_BuilderPage.getBuyBackMessageText()+"\n"+sh_Quote_BuilderPage.getValidationMessageText();
		}
		if(countErrorMessage == 3)
		{
			//actualMessage=sh_Quote_BuilderPage.getIneligibleBenefitText()+"\n"+sh_Quote_BuilderPage.getIneligibleAdditionalBenefitText() +"\n"+sh_Quote_BuilderPage.getIneligibleThirdBenefitText();
			actualMessage=sh_Quote_BuilderPage.getBuyBackMessageText()+"\n"+sh_Quote_BuilderPage.getValidationMessageText() +"\n"+sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		}
		if(countErrorMessage == 4)
		{
			actualMessage=sh_Quote_BuilderPage.getBuyBackMessageText()+"\n"+sh_Quote_BuilderPage.getValidationMessageText() +"\n"+ sh_Quote_BuilderPage.getAdditionalValidationMessageText() 
							+"\n"+sh_Quote_BuilderPage.getThirdValidationMessageText();
		}
		
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"LifeBB Ineligible Validation rule",datamap,index,actualMessage);		
		
	}
	
	@Then("the system gives messages (.*) with Life BuyBack with Life Cover for (.*) from \"(.*)\" Sheet$")
	public void the_system_gives_message_with_Life_Buyback_with_life_Cover(int countErrorMessage, String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		String actualMessage = "";
	
		if(countErrorMessage == 3)
		{
			//actualMessage=sh_Quote_BuilderPage.getIneligibleBenefitText()+"\n"+sh_Quote_BuilderPage.getIneligibleAdditionalBenefitText() +"\n"+sh_Quote_BuilderPage.getIneligibleThirdBenefitText();
			actualMessage=sh_Quote_BuilderPage.getValidationMessageText()+"\n"+ sh_Quote_BuilderPage.getSecondBuyBackMessageText() + "\n" + sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		}
		
		if(countErrorMessage == 5)
		{
			actualMessage=sh_Quote_BuilderPage.getValidationMessageText()+"\n"+ sh_Quote_BuilderPage.getSecondBuyBackMessageText() + "\n" + sh_Quote_BuilderPage.getAdditionalValidationMessageText() 
						+"\n"+sh_Quote_BuilderPage.getThirdValidationMessageText() + "\n" + sh_Quote_BuilderPage.getFourthValidationMessageText();
		}
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"LifeBB Ineligible Validation rule",datamap,index,actualMessage);		
		
	}
	
	@Then("^the system removes Life Cover and LifeBB automatically for (.*) from \"(.*)\" Sheet$")
	public void the_system_removes_Life_Cover_and_LifeBB_automatically(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Quote_BuilderPage.isLifeSectionDisplayed()  && sh_ACLA.isACLASectionDisplayed()  && sh_AELA.isAELASectionDisplayed())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"LifeBB removal after Life Cover deselection",datamap,index,status);	
		
	}
	
	@Then("^the system removes the Life BuyBack and AELA automatically for (.*) from \"(.*)\" Sheet$")
	public void the_system_removes_AELA_automatically(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		status = !sh_Quote_BuilderPage.isLifeSectionDisplayed();
		status = sh_AELA.isAELASectionDisplayed();
		if((!sh_Quote_BuilderPage.isLifeSectionDisplayed()) && sh_AELA.isAELASectionDisplayed())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"LifeBB removal after AELA deselection",datamap,index,status);	
		
	}
	
	@Then("^the system removes the Life BuyBack and ACLA automatically for (.*) from \"(.*)\" Sheet$")
	public void the_system_removes_Life_BuyBack_and_ACLA_automatically(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if((!sh_Quote_BuilderPage.isLifeSectionDisplayed()) && sh_ACLA.isACLASectionDisplayed())
		{
			status=true;
		}
		
		validation.validateStatus(file,sheetName,"LifeBB removal after AELA deselection",datamap,index,status);	
		
	}
	@Then("^the system validates the LifeBB with Life Cover age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_LifeBB_with_Life_Cover_Age_rule_correctly(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.getLifeCoverAvailability())
		{
			status=true;
		}
		
		validation.validateStatus(file,sheetName,"LifeBB with Life Cover age validation",datamap,index,status);	
		
	}
	
	
	@Then("^the system validates the LivingBB removal with (.*) rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_LivingBB_age_rule_correctly(String parentBenefit,String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(parentBenefit.contains("ACLA"))
		{			
			status = sh_ACLA.isACLASectionDisplayed();
		}
		if(parentBenefit.contains("SCLA"))
		{	
			status = sh_LivingAssurance.isSCLASectionDisplayed();
		}
		if(parentBenefit.contains("Life"))
		{	
			status= sh_LivingAssurance.isSCLASectionDisplayed() && sh_Quote_BuilderPage.isLifeSectionDisplayed();					
		}
		
		validation.validateStatus(file,sheetName,"Living BuyBack Removal limit",datamap,index,status);	
	}
	
	@Then("^the system validates the LivingBB rule correctly with (.*) error messages for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_LivingBB_rule_correctly(int countErrorMessage,String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		String actualMessage = "";
		if(countErrorMessage == 1)
		{			
			actualMessage=sh_Quote_BuilderPage.getBuyBackMessageText();
		}
		if(countErrorMessage == 2)
		{			
			actualMessage=sh_Quote_BuilderPage.getBuyBackMessageText() + "\n" + sh_Quote_BuilderPage.getValidationMessageText();
		}
		if(countErrorMessage == 3)
		{
			actualMessage=sh_Quote_BuilderPage.getBuyBackMessageText() + "\n" + sh_Quote_BuilderPage.getValidationMessageText()+"\n"+sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		}
		
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"LivingBB Validation rule",datamap,index,actualMessage);		
	}
	@Then("^the system gives ineligible messages (.*) with Living BuyBack for (.*) from \"(.*)\" Sheet$")
	public void the_system_gives_ineligible_message_with_Living_Buyback(int countErrorMessage, String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		String actualMessage = "";
		if(countErrorMessage == 1)
		{			
			actualMessage=sh_Quote_BuilderPage.getBuyBackMessageText();			
		}
		if(countErrorMessage == 2)
		{		
		//	actualMessage=sh_Quote_BuilderPage.getBuyBackMessageText()+"\n"+sh_Quote_BuilderPage.getIneligibleBenefitText();
			actualMessage=sh_Quote_BuilderPage.getBuyBackMessageText()+"\n"+sh_Quote_BuilderPage.getValidationMessageText();
		}
		if(countErrorMessage == 3)
		{
			//actualMessage=sh_Quote_BuilderPage.getIneligibleBenefitText()+"\n"+sh_Quote_BuilderPage.getIneligibleBenefitText() +"\n"+sh_Quote_BuilderPage.getIneligibleAdditionalBenefitText();
			actualMessage=sh_Quote_BuilderPage.getBuyBackMessageText() +"\n"+sh_Quote_BuilderPage.getValidationMessageText() + "\n"+sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		}
		if(countErrorMessage == 4)
		{
			//actualMessage=sh_Quote_BuilderPage.getIneligibleBenefitText()+"\n"+sh_Quote_BuilderPage.getIneligibleBenefitText() +"\n"+sh_Quote_BuilderPage.getIneligibleAdditionalBenefitText();
			
			actualMessage=sh_Quote_BuilderPage.getSecondBuyBackMessageText()+"\n"+sh_Quote_BuilderPage.getValidationMessageText()
							+"\n"+sh_Quote_BuilderPage.getAdditionalValidationMessageText() + "\n"+sh_Quote_BuilderPage.getThirdValidationMessageText();
		}
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Living BuyBack Ineligible Validation rule",datamap,index,actualMessage);		
		
	}
	
	@Then("^the systems does not return premium value for LifeBB on validation error$")
	public void the_system_does_not_return_premium_value_for_LifeBB() throws Throwable
	{
		String isACLA = datamap.get(index).get("LifeBuyBack_ACLA").toString();	
		String isAELA = datamap.get(index).get("LifeBuyBack_AELA").toString();	
		String actualLifeBB;	
		String actualPremium=sh_Quote_BuilderPage.getTotalPremium().replaceAll(",", "");		
		String expectedValue = "";			
		
		if(isACLA.equals("Yes"))
		{
			actualLifeBB=sh_LifeBB.getACLALifeBBValue(0).replaceAll(",", "");	
			Assert.assertEquals(actualLifeBB,expectedValue,"LifeBB premium verification on error");				
		}
		if(isAELA.equals("Yes"))
		{
			actualLifeBB=sh_LifeBB.getAELALifeBBValue(0).replaceAll(",", "");		
			Assert.assertEquals(actualLifeBB,expectedValue,"LifeBB premium verification on error");	
		}
		Assert.assertEquals((actualPremium.equals(null) || actualPremium.equals("0.00") || actualPremium.equals("")),true);		
	}
	

	@Then("^the system validates the SELA age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_SELA_age_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isSELADisabled() && sh_Benefits_Selection.isAICDisabled() && sh_Benefits_Selection.isWoPDisabled() && sh_Benefits_Selection.isSDTDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"SCLA Age limit",datamap,index,status);			
	}
	
	@Then("^the system validates the SELA ineligibility rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_SELA_ineligibility_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"SELA ineligibility rule",datamap,index,actualMessage);				
	}
	
	@Then("^the system validates the SELA validation rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_SELA_validation_rule(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		String actualMessage = sh_Quote_BuilderPage.getValidationMessageText();
		validation.validateMessage(file,sheetName,"SELA Validation",datamap,index,actualMessage); 			
	}
	
	@Then("^the system validates the SDT and FI Age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_SDT_FI_Age_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getFIIneligibleMessageText()+"\n"+sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Specialist & Diagnostic Testing Age",datamap,index,actualMessage);		
	}
	
	@Then("^the system automatically selects S&T for Child for (.*) from \"(.*)\" Sheet$")
	public void the_system_selects_SDT_For_Child_validation_rule(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_SpecialistBenefit.isSDTSelectedForChild())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"S&T Selection for child",datamap,index,status);	
	}	
	
	@Then("^the system validates the SDT Child Age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_SDT_Child_Age_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText()+"\n"+sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Specialist & Diagnostic Testing Child Age",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the SDT validation rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_SDT_validation_rule(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		String actualMessage = sh_Quote_BuilderPage.getSTErrorMessageText();
		validation.validateMessage(file,sheetName,"SDT Validation",datamap,index,actualMessage);		
	}
	
	@Then("^the system removes S&T for Adult and Child automatically for (.*) from \"(.*)\" Sheet$")
	public void the_system_removes_SDT_automatically(String row_index,String sheetName) throws Throwable {			
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_SpecialistBenefit.isSDTSectionDisplayed() && sh_SpecialistBenefit.isSDTChildSectionDisplayed())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"S&T automatic removal",datamap,index,status);		
	}
	
	@Then("^the system removes the Add Person Button automatically for (.*) from \"(.*)\" Sheet$")
	public void the_system_removes_Add_Person_automatically(String row_index,String sheetName) throws Throwable {			
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Quote_BuilderPage.isAddPersonDisplayed())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"Add Person automatic removal",datamap,index,status);		
	}
	
	@Then("^the system disables the S&T for Child automatically for (.*) from \"(.*)\" Sheet$")
	public void the_system_disables_ST_Child_automatically(String row_index,String sheetName) throws Throwable {			
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_SpecialistBenefit.isSDTSNotAvailableForChild())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"S&T for Child disabled automatically",datamap,index,status);		
	}
	
	@Then("^the system validates the FPB age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_FPB_age_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isFPBDisabled() && sh_Benefits_Selection.isAICDisabled() && sh_Benefits_Selection.isWoPDisabled() && sh_Benefits_Selection.isSDTDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"Family Protection Benefit Age limit",datamap,index,status);			
	}
	
	@Then("^the system validates the FPB ineligibility rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_FPB_ineligibility_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"FPB ineligibility rule",datamap,index,actualMessage);				
	}
	
	@Then("^the system validates the FPB validation rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_FPB_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"FPB Validation rule",datamap,index,actualMessage);			
	}
	
	@Then("^the system validates the AELA age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_AELA_age_rule_correctly(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Quote_BuilderPage.isAELADisabled(0))
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"AELA Age limit",datamap,index,status);	
	}	
	
	@Then("^the system validates the AELA ineligibility rule correctly with (.*) error messages for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_AELA_ineligibility_rule_correctly(int count, String row_index, String sheetName) throws Throwable
	{
		
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		//Verify AELA with error message
		String actualMessage = "";
		if(count == 1)
		{
			//actualMessage = sh_Quote_BuilderPage.getIneligibleBenefitText();
			actualMessage = sh_Quote_BuilderPage.getValidationMessageText();
		}
		if(count == 2)
		{
			//actualMessage = sh_Quote_BuilderPage.getIneligibleBenefitText() + "\n" + sh_Quote_BuilderPage.getIneligibleAdditionalBenefitText();
			actualMessage = sh_Quote_BuilderPage.getValidationMessageText() + "\n" + sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		}
		validation.validateMessage(file,sheetName,"AELA Ineligibility Validation",datamap,index,actualMessage);
	}
	
	@Then("^the system removes the AELA automatically for (.*) from \"(.*)\" Sheet$")
	public void the_system_removes_the_AELA_automatically(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Quote_BuilderPage.isLifeSectionDisplayed() && sh_AELA.isAELASectionDisplayed())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"AELA removal after Life Cover deselection",datamap,index,status);	
		
	}
	
	@Then("^the system validates the AELA Premium Option rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_AELA_premium_option_rule_correctly(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		//Verify AELA with error message
		String actualMessage = sh_Quote_BuilderPage.getValidationMessageText();
		validation.validateMessage(file,sheetName,"AELA Validation",datamap,index,actualMessage);	
		
	}
	
	@Then("^the system validates the AELA rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_AELA_rule_correctly(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		//Verify AELA with error message
		String actualMessage = sh_Quote_BuilderPage.getValidationMessageText();
		
		validation.validateMessage(file,sheetName,"AELA Validation",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the AIC age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_AIC_age_rule_correctly(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isAICDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"AIC Age limit",datamap,index,status);	
	}	
	
	@Then("^the system validates the AIC selection rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_AIC_selection_rule_correctly(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isAICDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"AIC Age limit",datamap,index,status);	
	}
	
	@Then("^the system validates the AIC rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_AIC_rule_correctly(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		//Verify AELA with error message
		String actualMessage = sh_Quote_BuilderPage.getValidationMessageText();
		
		validation.validateMessage(file,sheetName,"AIC Validation",datamap,index,actualMessage);		
	}
	
	@Then("^the system validates the Life Cover disabled correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_Life_Cover_disabled_correctly(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		boolean status = false;
		//Verify AELA with Life Cover
		if(sh_Benefits_Selection.getLifeCoverAvailability())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"AELA with Life Cover validation",datamap,index,status);	
	
	}

	
	@Then("^the system validates the Children and Maternity age rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_Children_and_Maternity_age_rule_correctly(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		boolean status = false;
		if(sh_Benefits_Selection.isCMDisabled())
		{
			status = true;			
		}
		
		validation.validateStatus(file,sheetName,"CM age validation",datamap,index,status);			
	}
	 
	@Then("^the system validates the Children and Maternity (.*) error messages correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_Children_and_Maternity_error_messages_correctly(int count, String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		//Verify C&M with error message
		String actualMessage = "";
		if(count == 1)
		{
			actualMessage = sh_Quote_BuilderPage.getValidationMessageText();
		}
		if(count == 2)
		{
			actualMessage = sh_Quote_BuilderPage.getValidationMessageText() + "\n" + sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		}
		if(count == 3)
		{
			actualMessage = sh_Quote_BuilderPage.getValidationMessageText() + "\n" + sh_Quote_BuilderPage.getAdditionalValidationMessageText()
							+ "\n" + sh_Quote_BuilderPage.getThirdValidationMessageText();
		}
		if(count == 4)
		{
			actualMessage = sh_Quote_BuilderPage.getValidationMessageText() + "\n" + sh_Quote_BuilderPage.getAdditionalValidationMessageText()
			+ "\n" + sh_Quote_BuilderPage.getThirdValidationMessageText() + "\n" + sh_Quote_BuilderPage.getFourthValidationMessageText();

		}
		if(count == 5)
		{
			actualMessage = sh_Quote_BuilderPage.getValidationMessageText() + "\n" + sh_Quote_BuilderPage.getAdditionalValidationMessageText()
							+ "\n" + sh_Quote_BuilderPage.getThirdValidationMessageText() + "\n" + sh_Quote_BuilderPage.getFourthValidationMessageText()
							+ "\n" + sh_Quote_BuilderPage.getFifthValidationMessageText();
		}
		
		if(count == 6)
		{
			actualMessage = sh_Quote_BuilderPage.getValidationMessageText() + "\n" + sh_Quote_BuilderPage.getAdditionalValidationMessageText()
							+ "\n" + sh_Quote_BuilderPage.getThirdValidationMessageText() + "\n" + sh_Quote_BuilderPage.getFourthValidationMessageText()
							+ "\n" + sh_Quote_BuilderPage.getFifthValidationMessageText() + "\n" + sh_Quote_BuilderPage.getSixthValidationMessageText();
		}
		
		validation.validateMessage(file,sheetName,"C&M error Validation",datamap,index,actualMessage);
	}
	
	@Then("the system automatically removes the Children and Maternity for (.*) from \"(.*)\" Sheet$")
	public void the_system_automatically_removes_the_Children_and_Maternity(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		boolean status = false;
		if(sh_Benefits_Selection.isCMDisabled())
		{
			status = true;			
		}
		
		validation.validateStatus(file,sheetName,"CM removal validation",datamap,index,status);	
	}
	
	@Then("the system will not automatically remove the Children and Maternity for (.*) from \"(.*)\" Sheet$")
	public void the_system_will_not_automatically_remove_the_Children_and_Maternity(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		boolean status = false;
		if(sh_Benefits_Selection.isCMDisplayed())
		{
			status = true;			
		}
		
		validation.validateStatus(file,sheetName,"CM removal validation",datamap,index,status);	
	}
	
	@Then("the system validates the TPD Condition (.*) error messages correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_TPD_Condition__error_messages_correctly(int count, String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		//Verify TPDC with error message
		String actualMessage = "";
		if(count == 1)
		{
			actualMessage = sh_Quote_BuilderPage.getValidationMessageText();
		}
		if(count == 2)
		{
			actualMessage = sh_Quote_BuilderPage.getValidationMessageText() + "\n" + sh_Quote_BuilderPage.getAdditionalValidationMessageText();
		}
		if(count == 3)
		{
			actualMessage = sh_Quote_BuilderPage.getValidationMessageText() + "\n" + sh_Quote_BuilderPage.getAdditionalValidationMessageText()
							+ "\n" + sh_Quote_BuilderPage.getThirdValidationMessageText();
		}
		if(count == 4)
		{
			actualMessage = sh_Quote_BuilderPage.getValidationMessageText() + "\n" + sh_Quote_BuilderPage.getAdditionalValidationMessageText()
			+ "\n" + sh_Quote_BuilderPage.getThirdValidationMessageText() + "\n" + sh_Quote_BuilderPage.getFourthValidationMessageText();

		}	
		if(count == 6)
		{
			actualMessage = sh_Quote_BuilderPage.getValidationMessageText() + "\n" + sh_Quote_BuilderPage.getAdditionalValidationMessageText()
			+ "\n" + sh_Quote_BuilderPage.getThirdValidationMessageText() + "\n" + sh_Quote_BuilderPage.getFourthValidationMessageText()
			+ "\n" + sh_Quote_BuilderPage.getFifthValidationMessageText() +"\n" + sh_Quote_BuilderPage.getSixthValidationMessageText();

		}	
		validation.validateMessage(file,sheetName,"TPD Condition error Validation",datamap,index,actualMessage);
	}
	
	@Then("the system automatically removes the TPD Condition for APC for (.*) from \"(.*)\" Sheet$")
	public void the_system_automatically_removes_the_TPD_Condition_for_APC(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		boolean status = false;
		if(sh_TPDCondition.isTPDCAPCSectionDisplayed())
		{
			status = true;			
		}
		
		validation.validateStatus(file,sheetName,"TPD Condition with APC removal validation",datamap,index,status);	
	}
	
	
	@Then("the system automatically removes the TPD Condition for SPC for (.*) from \"(.*)\" Sheet$")
	public void the_system_automatically_removes_the_TPD_Condition_for_SPC(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		boolean status = false;
		if(sh_TPDCondition.isTPDCSPCSectionDisplayed())
		{
			status = true;			
		}
		
		validation.validateStatus(file,sheetName,"TPD Condition with SPC removal validation",datamap,index,status);	
	}
	
	@Then("the system automatically removes the TPD Condition for ACLA for (.*) from \"(.*)\" Sheet$")
	public void the_system_automatically_removes_the_TPD_Condition_for_ACLA(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		boolean status = false;
		if(sh_TPDCondition.isTPDCACLASectionDisplayed())
		{
			status = true;			
		}
		
		validation.validateStatus(file,sheetName,"TPD Condition with ACLA removal validation",datamap,index,status);	
	}
	
	@Then("the system automatically removes the TPD Condition for SCLA for (.*) from \"(.*)\" Sheet$")
	public void the_system_automatically_removes_the_TPD_Condition_for_SCLA(String row_index, String sheetName) throws Throwable
	{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		boolean status = false;
		if(sh_TPDCondition.isTPDCSCLASectionDisplayed())
		{
			status = true;			
		}
		
		validation.validateStatus(file,sheetName,"TPD Condition with SCLA removal validation",datamap,index,status);	
	}
	

	@Then("^the systems validates Essential Income Protection rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_Essential_Income_Protection_rule_correctly(String row_index, String sheetName) throws Throwable{
		index = Integer.parseInt(row_index)-1;
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		//Verify TPDC with error message
		String actualMessage = "";	
		actualMessage = sh_Quote_BuilderPage.getValidationMessageText();
		validation.validateMessage(file,sheetName,"EDI Condition error Validation",datamap,index,actualMessage);
	}
	
	@Then("^the systems does not return premium value for EDI on validation error$")
	public void the_system_does_not_return_premium_value_for_EDI() throws Throwable
	{	
		String expectedEDI = "";
		String actualEDI=sh_EssentialDI.getEDIValue(0).replaceAll(",", "");	
		String actualPremium=sh_Quote_BuilderPage.getTotalPremium().replaceAll(",", "");	

		Assert.assertEquals(actualEDI, expectedEDI, "EDI premium validation");
		Assert.assertEquals((actualPremium.equals(null) || actualPremium.equals("0.00") || actualPremium.equals("")),true, "EDI total premium validation");		
	}
	
	@Then("^the systems automatically removes Waiver Of Premium for (.*) from \"(.*)\" Sheet$")
	public void the_system_automatically_removes_Waiver_Of_Premium(String row_index, String sheetName) throws Throwable{
	{
		index = Integer.parseInt(row_index)-1;
		boolean status=false;
		if(sh_Benefits_Selection.isWoPDisabled())
		{
			status=true;
		}
		validation.validateStatus(file,sheetName,"WoP removal",datamap,index,status);
	}
  }

	@Then("^the system validates the SCLA ineligibility rule correctly for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_SCLA_ineligibility_rule_correctly(String row_index,String sheetName) throws Throwable {	
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"SCLA ineligibility rule",datamap,index,actualMessage);				
	}
	
	@Then("^the system validates the MHE rule for (.*) from \"(.*)\" Sheet$")
	public void the_system_validates_the_MHE_rule_correctly (String row_index,String sheetName) throws Throwable {
		index = Integer.parseInt(row_index)-1;
		String actualMessage=sh_Quote_BuilderPage.getValidationMessageText();
		datamap = DataHelper.data(file.getAbsolutePath(),sheetName);
		validation.validateMessage(file,sheetName,"Mental Health Exclusion rule",datamap,index,actualMessage);
		
	}

}
