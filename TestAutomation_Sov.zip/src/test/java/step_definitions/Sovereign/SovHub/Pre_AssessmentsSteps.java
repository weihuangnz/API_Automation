package step_definitions.Sovereign.SovHub;


import static org.junit.Assert.assertEquals;

import java.io.File;
import java.util.HashMap;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import helpers.DataHelper;
import modules.DriverExtension;
import modules.LaunchSovHub;
import pageobjects.SovHub.SH_HomePage;
import pageobjects.SovHub.SH_Login;
import pageobjects.SovHub.SH_PreAssessmentQuery;
import pageobjects.SovHub.SH_PreAssessmentResultsPage;
import pageobjects.SovHub.SH_Pre_Assessment;
import step_definitions.Hooks;

public class Pre_AssessmentsSteps {
	
	public WebDriver driver;
	private SH_Login sh_Login;
	private SH_HomePage sh_HomePage;
	private SH_Pre_Assessment sh_PreAssessment;
	private SH_PreAssessmentResultsPage sH_PreAssessmentResultsPage;
	public List<HashMap<String,String>> datamap;
	public int index;
	
	public Pre_AssessmentsSteps()
	{
		driver = Hooks.driver;
		sh_Login = new SH_Login(driver);
		sh_HomePage = new SH_HomePage(driver);
		sh_PreAssessment = new SH_Pre_Assessment(driver);
		sH_PreAssessmentResultsPage = new SH_PreAssessmentResultsPage(driver);
		datamap = DataHelper.data(System.getProperty("user.dir")+"//src//test//resources//testData/PreAssessmentData.xlsx","Sheet1");

	}
	
	@Given("^I open the Sovereign SovHub page and log in$")
	public void i_open_the_Sovereign_SovHub_page_and_log_in() throws Throwable {

		LaunchSovHub.launchWebsite(driver);
		sh_Login.sovHubLogin();
		
	}

	@When("^when I click on the Pre-Assessment button$")
	public void when_i_click_on_the_Pre_Assessment_button() throws Throwable {

		sh_HomePage.clickPreAssessment();
	}

	@When("^I select a gender, date of birth and click on Proceed for (.*)$")
	public void i_select_a_gender_date_of_birth_and_click_on_Proceed(String row_index) throws Throwable {
		
		index = Integer.parseInt(row_index)-1;
		
		sh_PreAssessment.selectGender(datamap.get(index).get("Gender"));
		sh_PreAssessment.enterDateOfBirth();
		sh_PreAssessment.clickProceed();
		
	}
	
	
	@When("^I select a smoker status$")
	public void i_select_a_smoker_status() throws Throwable {
		
		sh_PreAssessment.selectSmoker(datamap.get(index).get("Smoker"));
		
	}

	@When("^I enter my height and weight$")
	public void i_enter_my_height_and_weight() throws Throwable {
		
		sh_PreAssessment.enterHeight(datamap.get(index).get("Height"));
		sh_PreAssessment.enterWeight(datamap.get(index).get("Weight"));
		
	}

	@When("^I select the name of my condition$")
	public void i_select_the_name_of_my_condition() throws Throwable {
		
		sh_PreAssessment.selectCondition(datamap.get(index).get("ConditionName"));

	}

	@When("^I specify if the condition is still present (.*) and I click on Assess$")
	public void i_specify_if_the_condition_is_still_present_and_I_click_on_Assess(String ConditionPresent) throws Throwable {

		sh_PreAssessment.conditionPresent(ConditionPresent);
		sh_PreAssessment.clickAssess();
	}


	@Then("^the system gives a Pre-Assessment Result$")
	public void the_system_gives_a_Pre_Assessment_Result() throws Throwable {
		
		Assert.assertEquals("Pre-Assessment Result",sh_PreAssessment.getHeaderText());

	}
	
	
	@When("^I specify any undergoing treatment for cancer or within one year of remission$")
	public void i_specify_any_undergoing_treatment_for_cancer_or_within_one_year_of_remission() throws Throwable {

		sh_PreAssessment.enterUndergoingtreatment(datamap.get(index).get("Treatment"));
	}

	@When("^I select a type of Cancer and relapse information$")
	public void i_select_a_type_of_Cancer_and_relapse_information() throws Throwable {
		
		sh_PreAssessment.selectCancerType(datamap.get(index).get("CancerType"));
		sh_PreAssessment.selectRelapse(datamap.get(index).get("Relapse"));

	}

	@When("^I specify any complications or side effects and low grade TNM Classification$")
	public void i_specify_any_complications_or_side_effects_and_low_grade_TNM_Classification() throws Throwable {

		sh_PreAssessment.selectComplications(datamap.get(index).get("Complications"));
		sh_PreAssessment.selectlowGradeTNM(datamap.get(index).get("TNMClassification"));
	}

	@When("^I enter the remission time in months and I click on Assess$")
	public void i_enter_the_remission_time_in_months_and_I_click_on_Assess() throws Throwable {
		
		sh_PreAssessment.enterRemissionTime(datamap.get(index).get("RemissionTime"));
		sh_PreAssessment.clickAssess();

	}

	@Then("^the system gives an expected Pre-Assessment Result$")
	public void the_system_gives_an_expected_Pre_Assessment_Result() throws Throwable {
		
		File file = new File("src/test/resources/testData/PreAssessmentData.xlsx");
		
		try {
			
			assertEquals(datamap.get(index).get("TotalPermanentDisablement"),sH_PreAssessmentResultsPage.getTotalPermanentDis());
			assertEquals(datamap.get(index).get("DisabilityIncome13Weeks"),sH_PreAssessmentResultsPage.getDisabilityIncome13Weeks());
			assertEquals(datamap.get(index).get("DisabilityIncome413Week"),sH_PreAssessmentResultsPage.getDisabilityIncome413Weeks());
			assertEquals(datamap.get(index).get("LivingAssurance"),sH_PreAssessmentResultsPage.getLivingAssurance());
			assertEquals(datamap.get(index).get("LifeResults"),sH_PreAssessmentResultsPage.getLifeResult());
			assertEquals(datamap.get(index).get("HealthCover"),sH_PreAssessmentResultsPage.getHealthCover());
			assertEquals(datamap.get(index).get("DisabilityIncome2Week"),sH_PreAssessmentResultsPage.getDisabilityIncome2Week());

			DataHelper.writeToExcel(file,"Sheet1", index + 1, 18, "PASS");

		}catch(AssertionError e)
		{	
			DataHelper.writeToExcel(file,"Sheet1", index + 1, 18, "FAIL");
		}

	}

}
