package step_definitions.Sovereign.QuickQuote;

import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import helpers.DataHelper;
import modules.DriverExtension;
import modules.LaunchQuickQuote;
import pageobjects.Sovereign.QuickQuote.GetStarted;
import pageobjects.Sovereign.QuickQuote.QuickQuote;
import pageobjects.Sovereign.QuickQuote.QuoteSummary;
import step_definitions.Hooks;

public class QuickQuoteSteps {
	
	public WebDriver driver;
	private GetStarted getStarted;
	private QuickQuote quickQuote;
	private QuoteSummary quoteSummary;
	public List<HashMap<String,String>> datamap;
	public int index;
	
	public QuickQuoteSteps()
	{
		driver = Hooks.driver;
		getStarted = new GetStarted(driver);
		quickQuote = new QuickQuote(driver);
		quoteSummary = new QuoteSummary(driver);
		datamap = DataHelper.data(System.getProperty("user.dir")+"//src//test//resources//testData/Data.xlsx","Sheet1");
	}
	
	
	@Given("^I open the Sovereign Quick Quote page$")
	public void i_open_the_Sovereign_Quick_Quote_page() throws Throwable {
		
		LaunchQuickQuote.launchWebsite(driver);

	}

	@When("^I add an email (.*) on the Get Started page$")
	public void i_add_an_email_on_the_Get_Started_page(String EmailAddress) throws Throwable {
		
		getStarted.enterEmail(EmailAddress);
		getStarted.clickGo();

	}

	@When("^I enter an age (.*) on the Quick Quote page$")
	public void i_enter_an_age_on_the_Quick_Quote_page(String Age) throws Throwable {
		
		quickQuote.enterAge(Age);

	}

	@When("^I select a gender (.*) and smoker (.*)$")
	public void i_select_a_gender_and_smoker(String Gender, String Smoker) throws Throwable {
		
		quickQuote.selectGender(Gender);
		quickQuote.selectSmoker(Smoker);

	}

	@When("^I select a benefit (.*) and enter a benefit amount (.*)$")
	public void i_select_a_benefit_and_enter_a_benefit_amount(String Benefit, String BenefitAmount) throws Throwable {
		
		quickQuote.selectBenefits(Benefit);
		quickQuote.enterBenefitAmount(Benefit, BenefitAmount);

	}

	@Then("^I can calculate a Quick Quote$")
	public void i_can_calculate_a_Quick_Quote() throws Throwable {
		
		quickQuote.clickCalculate();
		DriverExtension.waitForLoadPage(driver);
		assertTrue(quoteSummary.premiumHeaderDisplayed());
		Thread.sleep(2000);

	}
	
	@Then("^I can successfully calculate a Quick Quote$")
	public void i_can_successfully_calculate_a_Quick_Quote() throws Throwable {
		
		quickQuote.selectOccupationClass();
		quickQuote.clickCalculate();
		DriverExtension.waitForLoadPage(driver);
		assertTrue(quoteSummary.premiumHeaderDisplayed());
		Thread.sleep(2000);
	}
	
	
	//EXCEL
	
	@When("^I add an email on the Get Started page for (.*)$")
	public void i_add_an_email_on_the_Get_Started_page_for(String row_index) throws Throwable {
		
		index = Integer.parseInt(row_index)-1;
		
		System.out.println("Index is: " + index);

		getStarted.enterEmail(datamap.get(index).get("EmailAddress"));
		getStarted.clickGo();
	}

	@When("^I enter an age on the Quick Quote page$")
	public void i_enter_an_age_on_the_Quick_Quote_page() throws Throwable {

		System.out.println("HERE WE GO");
		System.out.println("Index is: " + index);
		System.out.println(datamap.get(index).get("AgeAd"));
		quickQuote.enterAge(datamap.get(index).get("AgeAd"));
	}

	@When("^I select a gender and smoker$")
	public void i_select_a_gender_and_smoker() throws Throwable {
		
		quickQuote.selectGender(datamap.get(index).get("Gender"));
		quickQuote.selectSmoker(datamap.get(index).get("Smoker"));

	}

	@When("^I select three benefits and enter benefit amounts$")
	public void i_select_a_benefit_and_enter_a_benefit_amount() throws Throwable {
		
		quickQuote.selectBenefits(datamap.get(index).get("Benefit1"));
		quickQuote.enterBenefitAmount(datamap.get(index).get("Benefit1"), datamap.get(index).get("BenefitAmount1"));
		
		quickQuote.selectBenefits(datamap.get(index).get("Benefit2"));
		quickQuote.enterBenefitAmount(datamap.get(index).get("Benefit2"), datamap.get(index).get("BenefitAmount2"));
		
		quickQuote.selectBenefits(datamap.get(index).get("Benefit3"));
		quickQuote.enterBenefitAmount(datamap.get(index).get("Benefit3"), datamap.get(index).get("BenefitAmount3"));
		

	}

	
	
	

}
