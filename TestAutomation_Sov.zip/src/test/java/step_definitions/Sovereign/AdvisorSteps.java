package step_definitions.Sovereign;

import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import modules.LaunchSovereign;
import pageobjects.Sovereign.RequestCallBackPage;
import pageobjects.Sovereign.SOV_HomePage;
import step_definitions.Hooks;

public class AdvisorSteps {
	
    public WebDriver driver;
    private SOV_HomePage sov_HomePage;
    private RequestCallBackPage requestCallBackPage;
	
	
	public AdvisorSteps()
	{
		driver = Hooks.driver;
		sov_HomePage = new SOV_HomePage(driver);
		requestCallBackPage = new RequestCallBackPage(driver);

	}
	
	@Given("^I open the Sovereign home page$")
	public void i_open_the_Sovereign_home_page() throws Throwable {
		
		LaunchSovereign.launchWebsite(driver);

	}

	@When("^I click on Find an Advisor$")
	public void i_click_on_Find_an_Advisor() throws Throwable {

		sov_HomePage.clickFindAdvisor();
		
	}

	@When("^I enter first name (.*) and last name (.*)$")
	public void i_enter_first_name_and_last_name(String FirstName, String LastName) throws Throwable {
		
		requestCallBackPage.enterfirstNamelastName(FirstName, LastName);

	}

	@When("^I enter a date of birth and an address (.*)$")
	public void i_enter_a_date_of_birth_and_an_address(String Address) throws Throwable {

		requestCallBackPage.enterDateOfBirth();
		requestCallBackPage.enterAddress(Address);

	}

	@When("^I enter a phone number (.*) and email address (.*)$")
	public void i_enter_a_phone_number_and_email_address(String PhoneNumber, String Email) throws Throwable {
		
		requestCallBackPage.enterPhoneNumber(PhoneNumber);
		requestCallBackPage.enterEmailAddress(Email);

	}

	@Then("^I can leave a note for an Advisor$")
	public void i_can_leave_a_note_for_an_Advisor() throws Throwable {
		
		requestCallBackPage.enterDescription("Not going to press Request a Call Back as this is prod!!");
		Thread.sleep(10000);

	}


}
