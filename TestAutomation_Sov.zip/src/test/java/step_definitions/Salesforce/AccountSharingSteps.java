package step_definitions.Salesforce;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import helpers.DataHelper;
import modules.LaunchSalesForce;

import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import pageobjects.Mailinator.Mail_Body_Page;
import pageobjects.Mailinator.Mail_Login_Page;
import pageobjects.Salesforce.*;
import step_definitions.Hooks;

public class AccountSharingSteps {

    public WebDriver driver;
    private SF_LoginPage sFLoginPage;
    private Mail_Login_Page mail_login_page;
    private Mail_Body_Page mail_body_page;
    private SF_Home_Page sF_Home_Page;
    private SF_AdministerMenuPage sF_AdministerMenuPage;
    private SF_AccountSharingRulesPage sF_AccountSharingRulesPage;
    private SF_NetworkPage sF_NetworkPage;
    private SF_NewSharingPage sF_NewSharingPage;
    private SF_NetworkEditPage sF_NetworkEditPage;
    public List<HashMap<String,String>> datamap;

    String AccountName;
    String AccountId;
    String salesForceURL;


    public AccountSharingSteps()
    {
        driver = Hooks.driver;
        sFLoginPage = new SF_LoginPage(driver);
        mail_login_page = new Mail_Login_Page(driver);
        mail_body_page = new Mail_Body_Page(driver);
        sF_Home_Page = new SF_Home_Page(driver);
        sF_AdministerMenuPage = new SF_AdministerMenuPage(driver);
        sF_AccountSharingRulesPage = new SF_AccountSharingRulesPage(driver);
        sF_NetworkPage = new SF_NetworkPage(driver);
        sF_NewSharingPage = new SF_NewSharingPage(driver);
        sF_NetworkEditPage = new SF_NetworkEditPage(driver);
        datamap = DataHelper.data(System.getProperty("user.dir")+"//src//test//resources//testData/Data.xlsx","Sheet1");
    }


    @Given("^I log into Salesforce$")
    public void i_log_into_Salesforce() throws Throwable {
    	
    	int index = Integer.parseInt("1")-1;
    	
    	for(HashMap h:datamap)
        {
            System.out.println(h.keySet());
            System.out.println(h.values());
        }
    	
    	// sendKeys(datamap.get(index).get("Username"));
    	
    	System.out.println("HERE:");
    	System.out.println(datamap.get(index).get("Username"));

    	
    	
        LaunchSalesForce.launchWebsite(driver);
        sFLoginPage.salesForceLogin();

    }

    @When("^I setup the Account Sharing Rules for an account$")
    public void i_setup_the_Account_Sharing_Rules_for_an_account() throws Throwable {

        AccountName = System.getProperty("AccountName");

        //AccountName = "Pieter Tester";

        sF_Home_Page.selectGlobalHeaderOption("Setup");
        sF_AdministerMenuPage.clickSecurityControls();
        sF_AdministerMenuPage.clickSharingSettings();
        sF_AccountSharingRulesPage.clickNewAccountSharingRulesBtn();
        sF_AccountSharingRulesPage.enterLabelName(AccountName);

        sF_AccountSharingRulesPage.selectDropDownRecords(sF_AccountSharingRulesPage.ownedBy,"Portal Roles and Subordinates");
        sF_AccountSharingRulesPage.selectDropDownRecords(sF_AccountSharingRulesPage.ownedByR,AccountName + " Partner User");
        sF_AccountSharingRulesPage.selectDropDownRecords(sF_AccountSharingRulesPage.sharedWith,"Portal Roles and Subordinates");
        sF_AccountSharingRulesPage.selectDropDownRecords(sF_AccountSharingRulesPage.sharedwithR,AccountName + " Partner User");

        sF_AccountSharingRulesPage.selectDropDownRecords(sF_AccountSharingRulesPage.assetAccess, "Read/Write");
        sF_AccountSharingRulesPage.selectDropDownRecords(sF_AccountSharingRulesPage.oppertunityAccess, "Read/Write");
        sF_AccountSharingRulesPage.selectDropDownRecords(sF_AccountSharingRulesPage.caseAccess, "Read/Write");

        sF_AccountSharingRulesPage.clickSave();

        driver.switchTo().alert().accept();

    }

    @When("^I configure the User and Group Sharing account settings$")
    public void i_configure_the_User_and_Group_Sharing_account_settings() throws Throwable {

        AccountName = System.getProperty("AccountId");

        //AccountId = "0015D000003ukS2";

        salesForceURL = LaunchSalesForce.getSalesforceURL();
        driver.get(salesForceURL + "/" + AccountId);

        sF_NetworkPage.clickSharingBtn();
        sF_NewSharingPage.clickAdd();

        sF_NewSharingPage.selectDropDownRecords(sF_NewSharingPage.searchDropDown, "Portal Roles and Subordinates");
        sF_NewSharingPage.selectDropDownRecords(sF_NewSharingPage.availableDropDown, "Portal Role and Subordinates: " + AccountName + " Partner User");

        sF_NewSharingPage.clickRightSelectArrow();

        sF_NewSharingPage.selectDropDownRecords(sF_NewSharingPage.accountAccessDropDown, "Read/Write");
        sF_NewSharingPage.selectDropDownRecords(sF_NewSharingPage.workAccessDropDown, "Read/Write");
        sF_NewSharingPage.selectDropDownRecords(sF_NewSharingPage.caseAccessDropDown, "Read/Write");

        sF_NewSharingPage.clickSave();

    }

    @Then("^the user account can log into Katipolt$")
    public void the_user_account_can_log_into_Katipolt() throws Throwable {

        driver.get(salesForceURL + "/" + AccountId);

        sF_NetworkPage.clickEdit();
        sF_NetworkEditPage.selectSharingCompleteCheckBox();
        sF_NetworkEditPage.clickSave();

    }

}
