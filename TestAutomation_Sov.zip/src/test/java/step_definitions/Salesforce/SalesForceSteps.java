package step_definitions.Salesforce;

import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.When;
import helpers.HtmlTableHelper;
import modules.DriverExtension;
import pageobjects.Salesforce.SF_AgentLookupPage;
import pageobjects.Salesforce.SF_Home_Page;
import pageobjects.Salesforce.SF_PolicyApplicationPage;
import pageobjects.Salesforce.SF_SearchClient;
import pageobjects.Salesforce.SF_WorkListPage;
import step_definitions.Hooks;

public class SalesForceSteps {
	
	public WebDriver driver;
	private SF_WorkListPage sf_WorkListPage;
	private SF_Home_Page sf_Home_Page;
	private SF_PolicyApplicationPage sf_PolicyApplicationPage;
	private SF_AgentLookupPage sf_AgentLookupPage;
	private SF_SearchClient sf_SearchClient;
	
	public SalesForceSteps()
	{
		driver = Hooks.driver;
		sf_WorkListPage = new SF_WorkListPage(driver);
		sf_Home_Page = new SF_Home_Page(driver);
		sf_PolicyApplicationPage = new SF_PolicyApplicationPage(driver);
		sf_AgentLookupPage = new SF_AgentLookupPage(driver);
		sf_SearchClient = new SF_SearchClient(driver);
	}
	
	
	@When("^I click on the Work List Tab$")
	public void i_click_on_the_Work_List_Tab() throws Throwable {
		
		sf_Home_Page.clickSalesforceTab(sf_Home_Page.workListTab);

	}

	@When("^I select a Work List Type (.*) and click on New PA$")
	public void i_select_a_Work_List_Type_and_click_on_New_PA(String WorkListType) throws Throwable {
		
		sf_WorkListPage.selectWorkListOption(WorkListType);
		//DriverExtension.skipLoadingAnimation(driver);
		
		sf_WorkListPage.findAndClickNewPA();
		
	}
	
	@When("^I select an Agent (.*) and click Next$")
	public void i_select_an_Agent_and_click_Next(String Agent) throws Throwable {

		sf_PolicyApplicationPage.enterAgentName(Agent);
		sf_AgentLookupPage.selectAgentFromLookup(Agent);
		sf_PolicyApplicationPage.clickNext();
		
	}
	
	
	@When("^I enter a First Name (.*), Last Name (.*) and Date of Birth (.*)$")
	public void i_enter_a_First_Name_Last_Name_and_Date_of_Birth(String FirstName, String LastName, String DOB) throws Throwable {

		sf_SearchClient.enterFirstName_LastName(FirstName, LastName);
		sf_SearchClient.enterDateOfBirth(DOB);
	}

	@When("^I click on Finish$")
	public void i_click_on_Finish() throws Throwable {
		
		sf_SearchClient.clickFinish();
		Thread.sleep(10000);

	}

}
