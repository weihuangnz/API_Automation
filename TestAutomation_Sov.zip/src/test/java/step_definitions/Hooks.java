package step_definitions;

import browserStrategy.BrowserStrategy;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import enums.BrowserEnum;
import step_definitions.Sovereign.SovHub.Quote_BuilderSteps;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Hooks
{
    public static WebDriver driver;
    public static String browser;
    public static final String USERNAME = "prathibakankanal1";
    public static final String AUTOMATE_KEY = "Nag6W1LY7uG6qNVV87cD";
    public static final String URL = "https://" + USERNAME + ":" + AUTOMATE_KEY + "@hub-cloud.browserstack.com/wd/hub";
    private Quote_BuilderSteps steps = new Quote_BuilderSteps();

    public String getScenarioName() {
        return scenarioName;
    }

    public void setScenarioName(String scenarioName) {
        this.scenarioName = scenarioName;
    }

    private String scenarioName;
    public enum Browser {
        CHROME(),
        FIREFOX(),
        JENKINS();
    }

    @Before
    public void openBrowser(Scenario scenario) throws Throwable {

        Properties properties = new Properties();
        InputStream input = null;
        input = new FileInputStream("src/test/resources/Browser.properties");
        properties.load(input);

        //Get the browser type
        browser = properties.getProperty("BrowserType");

        //reflection we're looking for the strategy class using the name
        try {

            Class<?> clazz = Class.forName(BrowserEnum.valueOf(browser.toUpperCase()).toString());
            Object browser = clazz.newInstance();
            BrowserStrategy browserStrategy = (BrowserStrategy)browser;
            browserStrategy.getBrowserConfigurations(scenario.getName());
            driver =browserStrategy.getDriver();

        }catch (IllegalArgumentException e){
            System.out.println("Please set the browser to firefox, ie or chrome in the Browser.properties file");
            driver = null;
            return;
        }
    }

    @After
    /**
     * Embed a screenshot in test report if test is marked as failed
     */
    public void embedScreenshot(Scenario scenario) throws Throwable {    	
        
        if(scenario.isFailed()) {
        	byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshot, "image/png");
            steps.i_logout_from_SovHub();
        } 
       
        driver.quit();

    }

}