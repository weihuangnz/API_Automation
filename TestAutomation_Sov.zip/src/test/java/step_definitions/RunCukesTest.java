package step_definitions;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

/**
 * Created by AmstelB on 12/10/2016.
 * For Tags - use @smoke for Jenkins and @local for local runs
 */

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "classpath:features",
        plugin = {"pretty", "html:target/cucumber-html-report", "json:target/cucumber.json"},
        tags = {"@BusinessContinuityValidation"}
)
public class RunCukesTest { }
