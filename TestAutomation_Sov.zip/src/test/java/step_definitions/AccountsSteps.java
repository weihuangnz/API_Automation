package step_definitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import modules.DriverExtension;
import modules.LaunchSalesForce;
import org.openqa.selenium.WebDriver;
import pageobjects.Account.AccountInfoPage;
import pageobjects.Account.AccountsHomePage;
import pageobjects.Account.NewAccountPage;
import pageobjects.Salesforce.SF_LoginPage;

import static org.testng.AssertJUnit.assertEquals;

/**
 * Created by AmstelB on 3/05/2017.
 */
public class AccountsSteps {

    public WebDriver driver;
    private SF_LoginPage SFLoginPage;
    private AccountsHomePage accountsHomePage;
    private NewAccountPage newAccountPage;

    public AccountsSteps()
    {
        driver = Hooks.driver;
        SFLoginPage = new SF_LoginPage(driver);
        accountsHomePage = new AccountsHomePage(driver);
        newAccountPage = new NewAccountPage(driver);
    }

    String AccountName;
    String AccountNumber;


    @Given("^I open the SalesForce Accounts page and click on new account$")
    public void i_open_the_SalesForce_Accounts_page_and_click_on_new_account() throws Throwable {

        LaunchSalesForce.launchWebsite(driver);
        SFLoginPage.salesForceLogin();
        accountsHomePage.clickNewAccount();

    }

    @When("^I enter Account Name (.*) and Parent Account (.*) and Account Number (.*)$")
    public void i_enter_Account_Name_and_Parent_Account_and_Account_Number(String accountName, String parentAccount, String accountNumber) throws Throwable {

        int randomInt = DriverExtension.getRandomInteger();
        AccountName = accountName + "-" + randomInt;
        AccountNumber = accountNumber;

        newAccountPage.enterAccountName(AccountName);
        newAccountPage.enterAccountNumber(AccountNumber);

    }

    @When("^I select Type (.*) and enter Phone (.*)$")
    public void i_select_Type_and_enter_Phone(String type, String phoneNumber) throws Throwable {

        newAccountPage.selectType(type);
        newAccountPage.enterPhoneNumber(phoneNumber);
    }

    @When("^I enter Billing Street (.*) and Billing City (.*) and Postal Code (.*)$")
    public void i_enter_Billing_Street_and_Billing_City_and_Postal_Code(String billingStreet, String billingCity, String postalCode) throws Throwable {

        newAccountPage.enterBillingStreet(billingStreet);
        newAccountPage.enterBillingCity(billingCity);
        newAccountPage.enterPostalCode(postalCode);

    }

    @When("^I click on Copy Billing Address to Shipping Address link$")
    public void i_click_on_Copy_Billing_Address_to_Shipping_Address_link() throws Throwable {

        newAccountPage.copyBillingAddressLink.click();
    }

    @When("^I enter a description (.*) and click Save$")
    public void i_enter_a_description_and_click_Save(String description) throws Throwable {

        newAccountPage.enterDescription(description);
        newAccountPage.clickSave();

    }

    @Then("^I am able to successfully create a SalesForce account$")
    public void i_am_able_to_successfully_create_a_SalesForce_account() throws Throwable {

        AccountInfoPage accountInfo = new AccountInfoPage(driver);
        assertEquals(AccountName, accountInfo.accountName.getText());
        assertEquals(AccountNumber, accountInfo.accountNumber.getText());

    }
}
