package PropertiesFilesStrategy;

import java.util.ResourceBundle;

public class PropertiesFileUtil {

    private static PropertiesFileUtil instance = null;
    private ResourceBundle rb;

    public static PropertiesFileUtil getInstance(String fileName){

        if(instance == null){
            instance = new PropertiesFileUtil(fileName);
        }else{
            instance.rb = ResourceBundle.getBundle(fileName);
        }
        return instance;
    }

    protected PropertiesFileUtil(String fileName){
      rb= ResourceBundle.getBundle(fileName);
    }

    public String getProperty(String key){
        return rb.getString(key);
    }
}
