package transform;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ivanna on 19/05/2017.
 */
public class ObjectDTO{

    private String user;
    private String password;
    private String worksNumber;
    private String worksName;
    private List<String> labourCodes;
    private List<String>otherCodes;
    private String description;
    private String firstName;
    private String lastName;
    private String email;

    public ObjectDTO(){
        this.labourCodes=new ArrayList<>();
    }

    public String getWorksName() {
        return worksName;
    }

    public void setWorksName(String worksName) {
        this.worksName = worksName;
    }
    public List<String> getLabourCodes() {
        return labourCodes;
    }

    public void setLabourCodes(List<String> labourCodes) {
        this.labourCodes = labourCodes;
    }

    public List<String> getOtherCodes() {
        return otherCodes;
    }

    public void setOtherCodes(List<String> otherCodes) {
        this.otherCodes = otherCodes;
    }
    public String getWorksNumber() {
        return worksNumber;
    }

    public void setWorksNumber(String worksNumber) {
        this.worksNumber = worksNumber;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }


    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

}
