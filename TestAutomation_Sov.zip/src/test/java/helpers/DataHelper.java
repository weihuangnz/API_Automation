package helpers;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class DataHelper {
 
public static List<HashMap<String,String>> data(String filepath,String sheetName)
   {
      List<HashMap<String,String>> mydata = new ArrayList<>();
      try
      {
         FileInputStream fs = new FileInputStream(filepath);
         XSSFWorkbook workbook = new XSSFWorkbook(fs);
         XSSFSheet sheet = workbook.getSheet(sheetName);
         Row HeaderRow = sheet.getRow(0);
         for(int i=1;i<sheet.getPhysicalNumberOfRows();i++)
         {
            Row currentRow = sheet.getRow(i);
            HashMap<String,String> currentHash = new HashMap<String,String>();
            for(int j=0;j<currentRow.getPhysicalNumberOfCells();j++)
            {
               Cell currentCell = currentRow.getCell(j);
               switch (currentCell.getCellType())
               {
               case Cell.CELL_TYPE_STRING:                  
                  currentHash.put(HeaderRow.getCell(j).getStringCellValue(), currentCell.getStringCellValue());
                  break;
               }
            }
            mydata.add(currentHash);
         }
         workbook.close();
         fs.close();
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }
      return mydata;
   }
   
   public static void writeToExcel(File file,String sheet, int row, int column, String value)
   {
   try {
			XSSFWorkbook wb = null;
			XSSFSheet sh = null;
			
   			FileInputStream fis = new FileInputStream(file);
   			wb = new XSSFWorkbook(fis);
   			sh = wb.getSheet(sheet);
   			
   			sh.getRow(row).createCell(column).setCellValue(value);
   		
   			FileOutputStream fos =new FileOutputStream(file);
   			wb.write(fos);
   			wb.close();
   		}catch(Exception e)
   		{
   			e.printStackTrace();
   		}
   }   
   
   public static HashMap<String,String> getColumnNumbers(String filepath,String sheetName)
   {
	   HashMap<String,String> columnMap = new HashMap<String,String>();
      try
      {
         FileInputStream fs = new FileInputStream(filepath);
         XSSFWorkbook workbook = new XSSFWorkbook(fs);
         XSSFSheet sheet = workbook.getSheet(sheetName);
         Row HeaderRow = sheet.getRow(0);
         for(int i=1;i<sheet.getPhysicalNumberOfRows();i++)
         {           
        	
            for(int j=0;j<HeaderRow.getPhysicalNumberOfCells();j++)
            {              
            	columnMap.put(HeaderRow.getCell(j).getStringCellValue(), String.valueOf(j));             
            }            
         }
         workbook.close();
         fs.close();
      }
      catch (Exception e)
      {
         e.printStackTrace();
      }
      return columnMap;
   }
}