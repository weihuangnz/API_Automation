package helpers;

import org.apache.log4j.Logger;

/**
 * Created by AmstelB on 12/10/2016.
 */
public class Log {

    private static Logger Log = Logger.getLogger(helpers.Log.class.getName());

    public static void info(String message)
    {
        Log.info(message);
    }


    //can also use methods like these:
    public static void startTestCase(String sTestCaseName){
        Log.info("Started Test case");
    }

    public static void endTestCase(String sTestCaseName){
        Log.info("Ended Test Case");
        //test
        //test2
    }
}
