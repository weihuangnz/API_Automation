package helpers;

import modules.DriverExtension;
import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * Created by AmstelB on 9/05/2017.
 */
public class HtmlTableHelper {

    public static int count = 1;

    /**
     *
     * @param element
     * @param cellValue
     * @param pagination
     * Sample Usage:  HtmlTableHelper.clickItemInTableSearchable(purchasesPage.productsTable, "INVP12", purchasesPage.tablePages);
     */
    public static void clickItemInTableSearchable(WebDriver driver, WebElement element,  String cellValue, List<WebElement> pagination){
        try{
            //DriverExtension.skipLoadingAnimation(driver);
            boolean found = false;
            WebElement table = element;
            List<WebElement> allRows = table.findElements(By.tagName("tr"));
            for (WebElement row : allRows) {
                if(found == true)
                {
                    break;
                }
                List<WebElement> cells = row.findElements(By.xpath("./*"));
                for (WebElement cell : cells) {

                    if(cell.getText().equals(cellValue))
                    {
                        cell.click();
                        found = true;
                        break;
                    }
                }
            }
            if(found == false)
            {
                count++;
                clickNextTablePage(driver, element, cellValue, pagination);
            }
        }catch (Exception e){
            Log.info("Could not find element in table - "+e.getMessage());
            throw (e);
        }
    }

    public static void clickNextTablePage(WebDriver driver, WebElement element,  String cellValue,List<WebElement> pagination)
    {
        String strCount = Integer.toString(count);
        List<WebElement> allElements = pagination;

        for (WebElement ielement: allElements) {

            if(ielement.getText().equals(strCount))
            {
                ielement.click();
                break;
            }
        }

        if(cellValue == "INVP")
        {
            clickItemInTableStartsWith(driver,element, cellValue, pagination);
        }
        else
        {
            clickItemInTableSearchable(driver,element, cellValue, pagination);
        }
    }

    public static boolean findItemInTable(WebElement element, String cellValue){

        boolean isFound = false;
        try{
            WebElement table = element;
            List<WebElement> allRows = table.findElements(By.tagName("tr"));
            for (WebElement row : allRows) {
                List<WebElement> cells = row.findElements(By.xpath("./*"));
                for (WebElement cell : cells) {

                    String found = cell.getText();
                    if(StringUtils.isNotEmpty(found)) {
                        found = found.trim();
                        if(found.equals(cellValue))
                        {
                            isFound = true;
                            break;
                        }
                    }
                }
                if(isFound){
                    break;
                }
            }
        }catch (Exception e){
            Log.info("Could not find element in table - "+e.getMessage());
            throw (e);
        }
        return isFound;
    }

    /**
     *
     * @param element
     * @param cellValue
     * @param pagination
     */
    public static void clickItemInTableStartsWith(WebDriver driver, WebElement element,  String cellValue, List<WebElement> pagination){
        try{
            DriverExtension.skipLoadingAnimation(driver);
            boolean found = false;
            WebElement table = element;
            List<WebElement> allRows = table.findElements(By.tagName("tr"));
            for (WebElement row : allRows) {
                if(found == true)
                {
                    break;
                }
                List<WebElement> cells = row.findElements(By.xpath("./*"));
                for (WebElement cell : cells) {

                    if(cell.getText().startsWith(cellValue))
                    {
                        cell.click();
                        found = true;
                        break;
                    }
                }
            }
            if(found == false)
            {
                count++;
                clickNextTablePage(driver, element, cellValue, pagination);
            }
        }catch (Exception e){
            Log.info("Could not find element in table - "+e.getMessage());
            throw (e);
        }
    }


    public static void findAndClickItemInTable(WebElement table, String cellValue){

        try{
            List<WebElement> allRows = table.findElements(By.tagName("td"));
            for (WebElement row : allRows) {
                List<WebElement> cells = row.findElements(By.xpath("./*"));

                for (WebElement cell : cells) {

                    if(cell.getText().equals(cellValue))
                    {
                            cell.click();
                            return;
                    }
                }
            }
        }catch (Exception e){
            Log.info("Could not find element in table - "+e.getMessage());
            throw (e);
        }
    }

    /**
     *
     * @param element
     */
    public static boolean hasElements(WebDriver driver, WebElement element){
            DriverExtension.skipLoadingAnimation(driver);
            WebElement table = element;
            List<WebElement> allRows = table.findElements(By.tagName("tr"));
            return !allRows.isEmpty();
    }


    /**
     * @param driver
     * @param table
     * @param cellValue
     * Sample Usage:  HtmlTableHelper.clickItemInTable(driver, productspage.productsTable, "Atlas Gentech");
     */
    public static void clickOnCheckboxElementInTable(WebDriver driver, WebElement table,  String cellValue){
        try{
            WebElement tabl = table;
            List<WebElement> allRows = tabl.findElements(By.tagName("tr"));
            for (WebElement row : allRows) {
                List<WebElement> cells = row.findElements(By.xpath("./*"));
                for (WebElement cell : cells) {

                    if(cell.getText().equals(cellValue))
                    {   String chekboXpath =  "//td[text()='"+cell.getText()+"']//preceding-sibling::td[1]";
                        WebElement checkbox = DriverExtension.findElementSafe(driver,By.xpath(chekboXpath));

                        if(DriverExtension.exist(checkbox)){
                           checkbox.click();
                        }

                    }
                }
            }
        }catch (Exception e){
            Log.info("Could not find element in table - "+e.getMessage());
            throw (e);
        }
    }

    public static void clickonTheFirsElementInTable(WebElement table){

        try{
            List<WebElement> allRows = table.findElements(By.tagName("td"));
            for (WebElement row : allRows) {
                List<WebElement> cells = row.findElements(By.xpath("./*"));
                if(!cells.isEmpty()){
                    WebElement element = cells.get(0);
                    element.click();
                    return;
                }
            }
        }catch (Exception e){
            Log.info("Error when you try to click on the first Element - "+e.getMessage());
            throw (e);
        }
    }

}

