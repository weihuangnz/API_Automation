package enums;


public enum BrowserEnum {

    CHROME("browserStrategy.ChromeStrategy"),
    FIREFOX("browserStrategy.FirexfoxStrategy"),
    IPAD("browserStrategy.Jenkins_iPad"),
    JENKINS("browserStrategy.JenkinsStrategy");


    private final String text;

    /**
     * @param text
     */
    private BrowserEnum(final String text) {
        this.text = text;
    }

    /* (non-Javadoc)
     * @see java.lang.Enum#toString()
     */
    @Override
    public String toString() {
        return text;
    }
}
