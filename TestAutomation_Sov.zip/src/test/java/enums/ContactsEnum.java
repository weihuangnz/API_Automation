package enums;

/**
 * Created by AmstelB on 12/06/2017.
 */
    public enum ContactsEnum {
        FirstName("Pieter"),
        LastName("Test"),
        Email("pieter@cloudinit.nz");

        private final String text;

        /**
         * @param text
         */
        private ContactsEnum(final String text) {
            this.text = text;
        }

        /* (non-Javadoc)
         * @see java.lang.Enum#toString()
         */
        @Override
        public String toString() {
            return text;
        }
    }

