package enums;

public enum InsuranceTypeEnum {
	
	InsuranceType1("Life Cover"),
	InsuranceType2("Income Protection"),
	InsuranceType3("Trauma"),
	InsuranceType4("Total Permanent Disablement"),
	InsuranceType5("Life Cover");

	private final String text;
	
	private InsuranceTypeEnum(String text){
		this.text=text;
	}
	
	public String toString()
	{
		return this.text;
	}
}
