package enums;

/**
 * Created by AmstelB on 12/06/2017.
 */
    public enum OccupationClassEnum {
    	OccupationClass1("Actuary"),
    	OccupationClass2("Acupuncturist"),
        OccupationClass3("Air Crash Investigator"),
        OccupationClass4("Arborist"),
        OccupationClass5("Retired"),
        OccupationClass9("Acrobat");

        private final String text;

        /**
         * @param text
         */
        private OccupationClassEnum(final String text) {
            this.text = text;
        }

        /* (non-Javadoc)
         * @see java.lang.Enum#toString()
         */
        @Override
        public String toString() {
            return text;
        }
    }

