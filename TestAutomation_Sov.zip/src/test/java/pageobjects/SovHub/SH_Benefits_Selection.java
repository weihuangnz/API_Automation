package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import pageobjects.BaseClass;

public class SH_Benefits_Selection extends BaseClass{

	public SH_Benefits_Selection(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(how= How.XPATH, using="//button[@title='Add TotalCare Max - Personal']")
	public static List <WebElement> addPersonalBenefits;

	@FindBy(how= How.XPATH, using="//button[@title='Add TotalCare Max - Business']")
	public static List <WebElement> addBusinessBenefits;
	
	//@FindBy(how= How.XPATH, using="//span[text()='Life']/preceding::button[1]")
	@FindBy(how= How.XPATH, using="//Button[contains(@title,'Life Cover')]")
	public static WebElement addLifeCoverBtn;
	
	@FindBy(how= How.XPATH, using="//span[contains(text(), 'TotalCare Max - Personal')]//following::div[contains(@class,'slds-p-around_small title')]/following::button[1]")
	public static WebElement personalCoverCloseBtn;
	
	@FindBy(how= How.XPATH, using="//span[contains(text(), 'TotalCare Max - Business')]//following::div[contains(@class,'slds-p-around_small title')]/following::button[1]")
	public static WebElement businessCoverCloseBtn;
	
	@FindBy(how= How.XPATH, using="//span[text()='Life']/following::span[1]")
	public static List <WebElement> notAvailableBenefitMsg;
	
	@FindBy(how= How.XPATH, using="//span[text()='Life']/parent::button/preceding::lightning-button-icon-stateful[contains(@class,'error')]")
	public static List <WebElement> lifeCoverNotAvailable;
	
	@FindBy(how= How.XPATH, using="//span[text()='Waiver of Premium']/parent::button/preceding-sibling::lightning-button-icon-stateful[contains(@class,'error')]")
	public static List <WebElement> wopNotAvailable;
	
	@FindBy(how= How.XPATH, using="//span[text()='Income Protection']/parent::button/preceding-sibling::lightning-button-icon-stateful[contains(@class,'error')]")
	public static List <WebElement> ipNotAvailable;	
	
	@FindBy(how= How.XPATH, using="//span[text()='Mortgage and Income Protection']/parent::button/preceding-sibling::lightning-button-icon-stateful[contains(@class,'error')]")
	public static List <WebElement> mipNotAvailable;		
	
	@FindBy(how= How.XPATH, using="//span[text()='Specialist & Diagnostic Testing']/parent::button/preceding-sibling::lightning-button-icon-stateful[contains(@class,'error')]")
	public static List <WebElement> sdtNotAvailable;
	
	@FindBy(how= How.XPATH, using="//span[text()='Living Assurance']/parent::button/preceding-sibling::lightning-button-icon-stateful[contains(@class,'error')]")
	public static List <WebElement> laNotAvailable;	
	
	@FindBy(how= How.XPATH, using="//span[text()='Total Permanent Disablement']/parent::button/preceding-sibling::lightning-button-icon-stateful[contains(@class,'error')]")
	public static List <WebElement> tpdNotAvailable;
	
	@FindBy(how= How.XPATH, using="//span[text()='Redundancy']/parent::button/preceding-sibling::lightning-button-icon-stateful[contains(@class,'error')]")
	public static List <WebElement> redundancyNotAvailable;
	
	@FindBy(how= How.XPATH, using="//span[text()='Progressive Care']/parent::button/preceding-sibling::lightning-button-icon-stateful[contains(@class,'error')]")
	public static List <WebElement> spcNotAvailable;
	
	@FindBy(how= How.XPATH, using="//span[text()='Retirement Protection']/parent::button/preceding-sibling::lightning-button-icon-stateful[contains(@class,'error')]")
	public static List<WebElement> rpNotAvailable;
	
	@FindBy(how= How.XPATH, using="//span[text()='Accidental Death']/parent::button/preceding-sibling::lightning-button-icon-stateful[contains(@class,'error')]")
	public static List <WebElement> adNotAvailable;
	
	@FindBy(how= How.XPATH, using="//span[text()='Accidental Injury Cover']/parent::button/preceding-sibling::lightning-button-icon-stateful[contains(@class,'error')]")
	public static List <WebElement> aicNotAvailable;	

	@FindBy(how= How.XPATH, using="//span[text()='Accelerated Essential Living Assurance']/parent::button/preceding-sibling::lightning-button-icon-stateful[contains(@class,'error')]")
	public static List<WebElement> aelaNotAvailable;

	@FindBy(how= How.XPATH, using="//span[text()='Essential Living Assurance']/parent::button/preceding-sibling::lightning-button-icon-stateful[contains(@class,'error')]")
	public static List <WebElement> selaNotAvailable;

	@FindBy(how= How.XPATH, using="//span[text()=\"Children's and Maternity\"]/parent::button/preceding-sibling::lightning-button-icon-stateful[contains(@class,'error')]")
	public static List <WebElement> cmNotAvailable;
	
	@FindBy(how= How.XPATH, using="//button[@title='Specialist & Diagnostic Testing']")
	public static WebElement specialistButton;
	
	@FindBy(how= How.XPATH, using="//button[@title='Waiver of Premium']")
	public static WebElement WaiverButton;
	
	@FindBy(how= How.NAME, using="PrvtHlth")
	public static WebElement privateHealthButton;
	
	@FindBy(how= How.XPATH, using="//button[@title='Private Health Cover']")
	public static WebElement healthCoverButton;	
	
	@FindBy(how= How.XPATH, using="//button[@title='Private Health Plus']")
	public static WebElement healthPlusButton;
		
	@FindBy(how= How.XPATH, using="//button[@title='Health Waiver of Premium']")
	public static WebElement healthWaiverButton;	
	
	//@FindBy(how= How.XPATH, using="//div[contains(text(), 'Private Health') and contains(@class,'slds-p-around_small title')]/following::button")
	@FindBy(how=How.XPATH, using="//div[contains(@class,'slds-p-around_small title')]/following::lightning-primitive-icon")
	public static WebElement privateHealthCloseBtn;
	
	@FindBy(how = How.XPATH, using = "//span[text()='Health Waiver of Premium']/preceding::lightning-button-icon-stateful[contains(@class,'error')]")
	public static List<WebElement> healthNotAvailable;
	
	@FindBy(how= How.XPATH, using="//button[@title='Income Protection']")
	public static WebElement incomeProtectionButton;
	
	@FindBy(how= How.XPATH, using="//button[@title='Mortgage and Income Protection']")
	public static WebElement mipButton;
	
	@FindBy(how= How.XPATH, using="//button[@title='Redundancy']")
	public static WebElement redundancyButton;
	
	@FindBy(how= How.XPATH, using="//button[@title='Living Assurance']")
	public static WebElement livingAssuranceButton;	
	
	@FindBy(how= How.XPATH, using="//button[@title='Total Permanent Disablement']")
	public static WebElement tpdButton;	
	
	@FindBy(how= How.XPATH, using="//button[@title='Family Protection']")
	public static WebElement fpButton;
	
	@FindBy(how= How.XPATH, using="//button[@title='Accidental Death']")
	public static WebElement adButton;
	
	@FindBy(how= How.XPATH, using="//button[@title='Accidental Injury Cover']")
	public static WebElement aicButton;
	
	@FindBy(how= How.XPATH, using="//button[@title='Early Cancer Upgrade']")
	public static WebElement ecuButton;
	
	@FindBy(how= How.XPATH, using="//button[@title=\"Children's and Maternity\"]")
	public static WebElement cmButton;
	
	@FindBy(how= How.XPATH, using="//button[@title='Progressive Care']")
	public static WebElement spcButton;
	
	@FindBy(how= How.XPATH, using="//button[@title='Essential Living Assurance']")
	public static WebElement selaButton;
	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[text()='Accelerated Living Assurance']")
	public static WebElement aclaBenefit;

	@FindBy(how= How.XPATH, using="//lightning-formatted-text[text()='Accelerated Progressive Care']")
	public static WebElement apcBenefit;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Private Health Cover')]/following::span[contains(@class,'uiOutputText')]" )
	public static List<WebElement> ineligibleErrorMessage;
	
	@FindBy(how=How.XPATH, using="//div[@class='slds-form-element__help']")
	public static WebElement inputErrorMessage;
	
	@FindBy(how= How.XPATH, using="//button[@title='Retirement Protection']")
	public static WebElement rpButton;
	
	@FindBy(how= How.XPATH, using="//span[text()='Early Cancer Upgrade']/parent::button/preceding-sibling::lightning-button-icon-stateful[contains(@class,'error')]")
	public static List <WebElement> ecuNotAvailable;
	
	@FindBy(how= How.XPATH, using="//button[@title='Essential Income Protection']")
	public static WebElement ediButton;
	
	@FindBy(how= How.XPATH, using="//button[@title='Waiver of Premium']")
	public static WebElement wopButton;
	
	@FindBy(how= How.XPATH, using="//button[@title='Rural Continuity']")
	public static WebElement rcButton;
	
	@FindBy(how= How.XPATH, using="//button[@title='Business Income Support']")
	public static WebElement bisButton;
	
	@FindBy(how=How.XPATH, using="//button[contains(text(),'ADD PERSON')]")
	public static WebElement addPersonButton;
	
	@FindBy(how= How.XPATH, using="//span[text()='Family Protection']/parent::button/preceding-sibling::lightning-button-icon-stateful[contains(@class,'error')]")
	public static List <WebElement> fpNotAvailable;
	
	@FindBy(how= How.XPATH, using="//button[@title='Business Continuity']")
	public static WebElement businessContinuityButton;
	
	public void addPersBenefits(int person) throws InterruptedException
	{
		clickSafelyJS(addPersonalBenefits.get(person));
	}
	
	public void addLifeCover() throws InterruptedException
	{
		clickSafelyJS(addLifeCoverBtn);
	}

	public void closePersonalCover() throws InterruptedException
	{
		clickSafelyJS(personalCoverCloseBtn);
	}

	public String getAvailableBenefitMessage() throws InterruptedException
	{
		String availibiltyMessage = null;		
		if(!notAvailableBenefitMsg.isEmpty()){
			availibiltyMessage = getTextSafely(notAvailableBenefitMsg.get(0));
			return availibiltyMessage;
		}
		else
		{
			return null;
		}
	}
	
	public boolean getLifeCoverAvailability()
	{
		return lifeCoverNotAvailable.get(0).isDisplayed();
	}
	
	public boolean isIPDisabled()
	{
		return ipNotAvailable.get(0).isDisplayed();
	}
	
	public boolean isMIPDisabled()
	{
		return mipNotAvailable.get(0).isDisplayed();
	}
	
	public boolean isWoPDisabled()
	{
		return wopNotAvailable.get(0).isDisplayed();
	}
	
	public boolean isSDTDisabled()
	{
		return sdtNotAvailable.get(0).isDisplayed();
	}
	
	public boolean isRedundancyDisabled()
	{
		return redundancyNotAvailable.get(0).isDisplayed();
	}
	
	public boolean isLADisabled()
	{
		return laNotAvailable.get(0).isDisplayed();
	}
	
	public boolean isAELADisabled()
	{
		return aelaNotAvailable.get(0).isDisplayed();
	}
	public boolean isTPDDisabled()
	{
		return tpdNotAvailable.get(0).isDisplayed();
	}
	
	public boolean isSPCDisabled() throws InterruptedException
	{		
		return spcNotAvailable.get(0).isDisplayed();
	}
	public void addSpecialistAndDiagnosticTesting() throws InterruptedException
	{
		clickSafelyJS(specialistButton);
	}

	public boolean isRPDisabled()
	{
		return rpNotAvailable.get(0).isDisplayed();
	}
	
	public boolean isCMDisabled()
	{
		return cmNotAvailable.get(0).isDisplayed();
	}
	
	public void addHealthCover() throws InterruptedException
	{
		clickSafelyJS(privateHealthButton);
		clickSafelyJS(healthCoverButton);
		clickSafelyJS(privateHealthCloseBtn);
	}
	
	public void addHealthPlus() throws InterruptedException
	{
		clickSafelyJS(privateHealthButton);
		clickSafelyJS(healthPlusButton);
		clickSafelyJS(privateHealthCloseBtn);
	}
	
	public void addHealthWaiverOfPremium() throws InterruptedException
	{
		clickSafelyJS(privateHealthButton);
		clickSafelyJS(healthWaiverButton);
		clickSafelyJS(privateHealthCloseBtn);
	}	
	
	public void addWaiverOfPremium() throws InterruptedException
	{
		clickSafelyJS(WaiverButton);
	}
	public void addIncomeProtection() throws InterruptedException
	{
		selectIncomeProtection();
		clickSafelyJS(personalCoverCloseBtn);
	}
	
	public boolean checkWoPAutomaticSelection() throws InterruptedException
	{
		boolean status=false;
		status=isElementSelected(WaiverButton);
		return status;
	}
	
	public void selectIncomeProtection() throws InterruptedException
	{
		clickSafelyJS(addPersonalBenefits.get(0));
		clickSafelyJS(incomeProtectionButton);		
	}
	
	public void selectMIP() throws InterruptedException
	{
		clickSafelyJS(addPersonalBenefits.get(0));
		clickSafelyJS(mipButton);		
	}
	
	public void selectRedundancy() throws InterruptedException
	{
		clickSafelyJS(addPersonalBenefits.get(0));
		clickSafelyJS(redundancyButton);		
	}
	
	public void addRuralContinuity() throws InterruptedException
	{
		clickSafelyJS(rcButton);			
	}
	
	public void addBIS() throws InterruptedException
	{
		clickSafelyJS(bisButton);			
	}
	public void addRedundancy() throws InterruptedException
	{
		selectRedundancy();
		clickSafelyJS(personalCoverCloseBtn);
	}
	
	public void addMortgageIncomeProtection() throws InterruptedException
	{
		selectMIP();
		clickSafelyJS(personalCoverCloseBtn);
	}
	public void selectLivingAssurance() throws InterruptedException
	{
		clickSafelyJS(addPersonalBenefits.get(0));
		clickSafelyJS(livingAssuranceButton);		
	}
	
	public void selectLivingAssurance(String benefitCateogry) throws InterruptedException
	{		
		openBenefitSelectionList(benefitCateogry);
		clickSafelyJS(livingAssuranceButton);		
	}
	
	public void addLivingAssurance() throws InterruptedException
	{
		clickSafelyJS(livingAssuranceButton);	
		//selectLivingAssurance();
		//clickSafelyJS(personalCoverCloseBtn);
	}
	
	public void addLivingAssurance(String benefitCateogry) throws InterruptedException
	{
		selectLivingAssurance(benefitCateogry);		
		closeBenefitSelectionList(benefitCateogry);
	}
	
	public boolean isHealthCoverDisabled() throws InterruptedException
	{		
		clickSafelyJS(privateHealthButton);
		return healthNotAvailable.get(0).isDisplayed();
	}
	
	public boolean isHealthPlusDisabled() throws InterruptedException
	{		
		clickSafelyJS(privateHealthButton);
		return healthNotAvailable.get(1).isDisplayed();
	}
	
	public boolean isHealthWaiverDisabled() throws InterruptedException
	{	
		clickSafelyJS(privateHealthButton);
		int count = healthNotAvailable.size();
		return healthNotAvailable.get(count-1).isDisplayed();
	}
	
	public void selectTPD() throws InterruptedException
	{
		clickSafelyJS(addPersonalBenefits.get(0));
		clickSafelyJS(tpdButton);		
	}
	public void selectTPD(String benefitCategory) throws InterruptedException
	{
		openBenefitSelectionList(benefitCategory);
		clickSafelyJS(tpdButton);		
	}
	
	public void addTPD() throws InterruptedException
	{
		clickSafelyJS(tpdButton);	
		//selectTPD();
		//clickSafelyJS(personalCoverCloseBtn);
	}
	
	public void addTPD(String benefitCategory) throws InterruptedException
	{
		selectTPD(benefitCategory);
		closeBenefitSelectionList(benefitCategory);
	}

	public void selectCM() throws InterruptedException
	{
		clickSafelyJS(addPersonalBenefits.get(0));
		clickSafelyJS(cmButton);		
	}
	
	public void addCM() throws InterruptedException
	{
		selectCM();
		clickSafelyJS(personalCoverCloseBtn);
	}
	
	public void selectECU(String benefitCategory) throws InterruptedException
	{
		openBenefitSelectionList(benefitCategory);
		clickSafelyJS(ecuButton);		
	}
	
	public void selectECU() throws InterruptedException
	{
		clickSafelyJS(addPersonalBenefits.get(0));
		clickSafelyJS(ecuButton);		
	}
	
	public void addECU() throws InterruptedException
	{
		clickSafelyJS(ecuButton);		
		//selectECU();
		//clickSafelyJS(personalCoverCloseBtn);
	}
	
	public void addECU(String benefitCategory) throws InterruptedException
	{
		selectECU(benefitCategory);
		closeBenefitSelectionList(benefitCategory);
	}
	
	
	public void selectAD() throws InterruptedException
	{
		clickSafelyJS(addPersonalBenefits.get(0));
		clickSafelyJS(adButton);		
	}
	
	
	public void addAD() throws InterruptedException
	{
		selectAD();
		clickSafelyJS(personalCoverCloseBtn);
	}
	
	
	public void removeAD() throws InterruptedException
	{
		selectAD();		
	}
	
	public void selectAIC() throws InterruptedException
	{
		clickSafelyJS(addPersonalBenefits.get(0));
		clickSafelyJS(aicButton);		
	}
	
	public void selectAIC(String benefitCategory) throws InterruptedException
	{
		openBenefitSelectionList(benefitCategory);
		clickSafelyJS(aicButton);	
	}
	
	public void addAIC() throws InterruptedException
	{
		clickSafelyJS(aicButton);	
		//selectAIC();
		//clickSafelyJS(personalCoverCloseBtn);
	}
	
	public void addAIC(String benefitCategory) throws InterruptedException
	{
		selectAIC(benefitCategory);
		clickSafelyJS(businessCoverCloseBtn);
	}
	
	public void selectFP() throws InterruptedException
	{
		clickSafelyJS(addPersonalBenefits.get(0));
		clickSafelyJS(fpButton);		
	}
	
	public void addFP() throws InterruptedException
	{
		selectFP();
		clickSafelyJS(personalCoverCloseBtn);
	}
	
	public void selectSPC() throws InterruptedException
	{
		clickSafelyJS(addPersonalBenefits.get(0));
		clickSafelyJS(spcButton);		
	}
	
	public void selectSPC(String benefitCategory) throws InterruptedException
	{
		openBenefitSelectionList(benefitCategory);
		clickSafelyJS(spcButton);		
	}
	public void addSPC() throws InterruptedException
	{
		clickSafelyJS(spcButton);
		//selectSPC();
		//clickSafelyJS(personalCoverCloseBtn);
	}
	public void addSPC(String benefitCategory) throws InterruptedException
	{
		selectSPC(benefitCategory);
		closeBenefitSelectionList(benefitCategory);
	}
	public boolean isAPCDisabled() throws InterruptedException
	{		
		return isNotDisplayed(apcBenefit);
	}
	
	public boolean isACLADisabled() throws InterruptedException
	{		
		return isNotDisplayed(aclaBenefit);
	}	
	
	public void selectRP() throws InterruptedException
	{
		
		clickSafelyJS(addPersonalBenefits.get(0));
		clickSafelyJS(rpButton);		
	}
	public void addRP() throws InterruptedException
	{
		selectRP();
		clickSafelyJS(personalCoverCloseBtn);		
	}
	
	public void addPerson() throws InterruptedException
	{		
		clickSafelyJS(addPersonButton);
	}
	
	public boolean isADDisabled()
	{
		return adNotAvailable.get(0).isDisplayed();
	}
	
	public boolean isAICDisabled()
	{
		return aicNotAvailable.get(0).isDisplayed();
	}
	
	public boolean isECUDisabled()
	{
		return ecuNotAvailable.get(0).isDisplayed();
	}
	
	public void selectSELA() throws InterruptedException
	{
		clickSafelyJS(addPersonalBenefits.get(0));
		clickSafelyJS(selaButton);		
	}
	
	public void addSELA() throws InterruptedException
	{
		selectSELA();
		clickSafelyJS(personalCoverCloseBtn);		
	}
	
	public void selectEDI() throws InterruptedException
	{
		clickSafelyJS(addPersonalBenefits.get(0));
		clickSafelyJS(ediButton);		
	}
	
	public void addEDI() throws InterruptedException
	{
		selectEDI();
		clickSafelyJS(personalCoverCloseBtn);		
	}
	
	public void removeWOP() throws InterruptedException
	{
		clickSafelyJS(addPersonalBenefits.get(0));
		clickSafelyJS(wopButton);		
		clickSafelyJS(personalCoverCloseBtn);	
	}
	public boolean isSELADisabled()
	{
		return selaNotAvailable.get(0).isDisplayed();
	}
	
	public boolean isAddPersonDisabled()
	{
		return isNotDisplayed(addPersonButton);
	}
	
	public boolean isFPBDisabled()
	{
		return fpNotAvailable.get(0).isDisplayed();
	}
	
	public boolean isCMDisplayed()
	{
		return cmButton.isDisplayed();		
	}
	
	public void closeBenefitSelectionList(String benefitCateogry) throws InterruptedException 
	{
		switch(benefitCateogry)
		{
		case "TCMP":
			clickSafelyJS(personalCoverCloseBtn);
			break;
		case "TCMB":
			clickSafelyJS(businessCoverCloseBtn);
			break;
		case "LSPB":
			//TO DO
			break;
		case "LSPP":
			//TO DO
			break;
		default:
			clickSafelyJS(personalCoverCloseBtn);
		}
		
	}
	public void openBenefitSelectionList(String benefitCateogry) throws InterruptedException 
	{
		switch(benefitCateogry)
		{
		case "TCMP":
			clickSafelyJS(addPersonalBenefits.get(0));
			break;
		case "TCMB":
			clickSafelyJS(addBusinessBenefits.get(0));
			break;
		case "LSPB":
			//TO DO
			break;
		case "LSPP":
			//TO DO
			break;
		default:
			clickSafelyJS(addPersonalBenefits.get(0));
		}
		
	}
	
	//TCMB Business Continuity
	public void addBusinessContinuity() throws InterruptedException
	{
		selectBusinessContinuity();
		clickSafelyJS(businessCoverCloseBtn);
	}
	
	public void selectBusinessContinuity() throws InterruptedException
	{
		clickSafelyJS(addBusinessBenefits.get(0));
		clickSafelyJS(businessContinuityButton);
	}
}
