package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import pageobjects.BaseClass;

public class SH_BIS extends BaseClass{

	public SH_BIS(WebDriver driver) {
		super(driver);
	}
	
	//@FindBy(how= How.NAME, using="inputBenefitAmount")
	@FindBy(how= How.XPATH, using="//div[text()='Business Income Support']/following::input[@name='inputBenefitAmount']")
	public static List <WebElement> sumAssured;		
	
	@FindBy(how=How.XPATH, using="//div[text()='Business Income Support']/following::button[text()='Annually']")
	public static List<WebElement> annuallyFrequency;
	
	@FindBy(how=How.XPATH, using="//div[text()='Business Income Support']/following::button[text()='Monthly']")
	public static List<WebElement> monthlyFrequency;
	
	@FindBy(how= How.XPATH, using="//div[text()='Business Income Support']/following::legend[contains(text(), 'Waiting Period in Weeks')]/following::button[1]")
	public static List <WebElement> waitingPeriod26;
	
	@FindBy(how= How.XPATH, using="//div[text()='Business Income Support']/following::legend[contains(text(), 'Waiting Period in Weeks')]/following::button[2]")
	public static List <WebElement> waitingPeriod52;
	
	@FindBy(how= How.XPATH, using="//div[text()='Business Income Support']/following::legend[contains(text(), 'Waiting Period in Weeks')]/following::button[3]")
	public static List <WebElement> waitingPeriod104;
	
	@FindBy(how= How.XPATH, using="//div[text()='Business Income Support']/following::span[text()='Add More']/parent::button[1]")
	public static List <WebElement> addBISLoading;
	
	@FindBy(how= How.XPATH, using="//div[text()='Business Income Support']/following::span[text()='Show/Hide Loading']/parent::a")
	public static WebElement showHideBISLoading;	
	
	@FindBy(how= How.XPATH, using="//div[text()='Business Income Support']/following::input[@name='inputLoading']")
	public static List <WebElement> bisLoadingPercentage;


		
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[text()='Business Income Support']/following::lightning-formatted-number")
	public static List <WebElement> bisValue;
	
	@FindBy(how= How.XPATH, using="//div[text()='Business Income Support']/preceding::lightning-icon[contains(@class,'check')]")
	public static WebElement bisCheck;
	
	@FindBy(how= How.XPATH, using="//div[text()='Business Income Support']/preceding::button[contains(@class,'missionControlWarning')]")
	public static WebElement bisWarning;
	
	@FindBy(how= How.XPATH, using="//div[text()='Business Income Support']")
	public static WebElement bisSection;
	
	
	public void enterSumAssured(String amount, int person) throws InterruptedException
	{
		skipLoadingAnimation();
		if(amount!=null)
		{			
			sendKeysSafely(sumAssured.get(person),amount);			
		}
		skipLoadingAnimation();
	}
	
	public void selectSumAssuredFrequency(String frquency, int person) throws InterruptedException
	{
		switch (frquency)
		{
		case "Annually":
			clickSafely(annuallyFrequency.get(person));    	
			break;

		case "Monthly":    		
			clickSafely(monthlyFrequency.get(person));
			break;
		}
	}
	

	public void selectWaitingPeriod(String waitingPeriod, int person) throws InterruptedException
	{
		switch (waitingPeriod)
		{
		case "26":
			clickSafelyJS(waitingPeriod26.get(person));
			break;

		case "52":
			clickSafelyJS(waitingPeriod52.get(person));
			break;

		case "104":
			clickSafelyJS(waitingPeriod104.get(person));
			break;	
		default:
			clickSafelyJS(waitingPeriod26.get(person));
			break;
		}
	}
	public void enterLoadingPercentage(String percentage, int person) throws InterruptedException
	{
		if(percentage!=null)
		{
			clickSafely(addBISLoading.get(person));
			clickSafely(showHideBISLoading);	
			scrollIntoView(bisLoadingPercentage.get(person));	
			sendKeysSafely(bisLoadingPercentage.get(person),percentage);			
		}
	}
	
	public String getBISValue(int person)
	{
		String value = getTextSafely(bisValue.get(person));
		if(value.length()>0)
		{
			value = value.substring(1); 
		}
		return value;
	}
	
	public boolean isBISStatusSuccessful()
	{		  	
		return bisCheck.isDisplayed();
	}
	
	public boolean isBISStatusWarning()
	{		  	
		return bisWarning.isDisplayed();
	}

	
	public boolean isBISSectionDisplayed() throws Exception
	{
		return isNotDisplayed(bisSection);
	}
	
}
