package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import pageobjects.BaseClass;

public class SH_LivingAssurance extends BaseClass{

	public SH_LivingAssurance(WebDriver driver) {
		super(driver);
	}
	
	//@FindBy(how= How.NAME, using="inputBenefitAmount")
	@FindBy(how= How.XPATH, using="//div[text()='Living Assurance']/following::input[@name='inputBenefitAmount']")
	public static List <WebElement> sumAssured;	
	
	@FindBy(how= How.XPATH, using="//div[text()='Living Assurance']/following::legend[contains(text(), 'Indexation')]/following::button[1]")
	public static List <WebElement> indexed;

	@FindBy(how= How.XPATH, using="//div[text()='Living Assurance']/following::legend[contains(text(), 'Indexation')]/following::button[2]")
	public static List <WebElement> level;
	
	@FindBy(how= How.XPATH, using="//div[text()='Living Assurance']/following::button[text()='Rate for Age']")
	public static List <WebElement> rateForAge;

	@FindBy(how= How.XPATH, using="//div[text()='Living Assurance']/following::button[text()='10 Year']")
	public static List <WebElement> tenYear;

	@FindBy(how= How.XPATH, using="//div[text()='Living Assurance']/following::button[text()='To Age 65']")
	public static List <WebElement> toAge65;
	
	@FindBy(how= How.XPATH, using="//div[text()='Living Assurance']/following::span[text()='Add More']/parent::button[1]")
	public static List <WebElement> addLALoading;
	
	@FindBy(how= How.XPATH, using="//div[text()='Living Assurance']/following::span[text()='Show/Hide Loading']/parent::a")
	public static WebElement showHideLALoading;
	
	@FindBy(how= How.XPATH, using="//div[text()='Living Assurance']/following::span[text()='Add TPD Condition']/parent::a")
	public static WebElement showHideTPDCondition;
	
	@FindBy(how= How.XPATH, using="//div[text()='Living Assurance']/following::input[@name='inputLoading']")
	public static List <WebElement> laLoadingPercentage;
	
	@FindBy(how= How.XPATH, using="//div[text()='Living Assurance']/following::input[@name='inputLoadingTerm']")
	public static List <WebElement> laLoadingTerm;

	@FindBy(how= How.XPATH, using="//div[text()='Living Assurance']/following::input[@name='inputPerMille']")
	public static List <WebElement> laPerMille;
	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[text()='Living Assurance']/following::lightning-formatted-number")
	public static List <WebElement> laValue;
	
	@FindBy(how= How.XPATH, using="//div[text()='Living Assurance']/preceding::lightning-icon[contains(@class,'check')]")
	public static WebElement laCheck;
	
	@FindBy(how= How.XPATH, using="//div[text()='Living Assurance']/preceding::button[contains(@class,'missionControlWarning')]")
	public static WebElement laWarning;	
	
	@FindBy(how= How.XPATH, using="//div[text()='Living Assurance']/following::legend[contains(text(), 'Living Buy-Back')]/following::button[1]")
	public static List <WebElement> livingBuyBackOptionYes;

	@FindBy(how= How.XPATH, using="//div[text()='Living Assurance']/following::legend[contains(text(), 'Living Buy-Back')]/following::button[2]")
	public static List <WebElement> livingBuyBackOptionNo;
	
	@FindBy(how= How.XPATH, using="//div[text()='Living Assurance']")
	public static WebElement sclaSection;
	
	
	public void enterSumAssured(String amount, int person) throws InterruptedException
	{
		skipLoadingAnimation();
		if(amount!=null)
		{			
			sendKeysSafely(sumAssured.get(person),amount);			
		}
		skipLoadingAnimation();
	}
	
	public void selectIndexation(String indexation, int person) throws InterruptedException
	{
		switch (indexation)
		{
		case "Indexed":
			clickSafely(indexed.get(person));    	
			break;

		case "Level":    		
			clickSafely(level.get(person));
			break;
		}
	}
	
	public void selectPremiumOption(String PremiumOption, int person) throws InterruptedException
	{
		switch (PremiumOption)
		{
		case "Rate For Age":
			clickSafelyJS(rateForAge.get(person));
			break;

		case "10 Year":
			clickSafelyJS(tenYear.get(person));
			break;

		case "To Age 65":
			clickSafelyJS(toAge65.get(person));
			break;		
		}
	}
	
	public void enterLoadingPercentage(String percentage, int person) throws InterruptedException
	{
		if(percentage!=null)
		{
			clickSafely(addLALoading.get(person));
			clickSafely(showHideLALoading);	
			scrollIntoView(laLoadingPercentage.get(person));	
			sendKeysSafely(laLoadingPercentage.get(person),percentage);			
		}
	}
	
	public void addTPDCondition(int person) throws InterruptedException
	{
		clickSafely(addLALoading.get(person));
		clickSafely(showHideTPDCondition);	
	}
	
	public void enterLoadingTerm(String term, int person) throws InterruptedException
	{
		if(term!=null)
		{
			sendKeysSafely(laLoadingTerm.get(person),term);
		}
		else
		{
			sendKeysSafely(laLoadingTerm.get(person),"");
		}
	}

	public void enterPerMille(String mille, int person) throws InterruptedException
	{
		if(mille!=null)
		{
			sendKeysSafely(laPerMille.get(person),mille);
			sendEnterKeysSafely(laPerMille.get(person));
		}
	}
	
	public String getLAValue(int person)
	{
		String value = getTextSafely(laValue.get(person));
		if(value.length()>0)
		{
			value = value.substring(1); 
		}
		return value;
	}
	
	public boolean isLAStatusSuccessful()
	{		  	
		return laCheck.isDisplayed();
	}
	
	public boolean isLAStatusWarning()
	{		  	
		return laWarning.isDisplayed();
	}
	
	public void selectLivingBuyBack(String LivingBuyBack, int person) throws InterruptedException
	{
		switch (LivingBuyBack)
		{
		case "Yes":
			clickSafelyJS(livingBuyBackOptionYes.get(person));
			break;

		case "No":
			clickSafelyJS(livingBuyBackOptionNo.get(person));
			break;				
		}
	}
	
	public void selectLivingBuyBackDiscount(String LivingBuyBack, int person) throws InterruptedException
	{		
		//to do, UI hasn't implemented yet 2018-10-04
	}

	public boolean isLivingBBButtonDispayed(int person) throws InterruptedException
	{
		return isNotDisplayed(livingBuyBackOptionYes.get(0));
		
	}
	
	public boolean isSCLASectionDisplayed() throws Exception
	{
		return isNotDisplayed(sclaSection);
	}
	
}
