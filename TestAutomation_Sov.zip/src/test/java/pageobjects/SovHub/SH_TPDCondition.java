package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import pageobjects.BaseClass;

public class SH_TPDCondition extends BaseClass{

	public SH_TPDCondition(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[text()='Accelerated Progressive Care']/following::lightning-formatted-text[contains(text(),'TPD Condition')]/following::lightning-formatted-number")
	public static List <WebElement> tpdcAPCValue;
	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[text()='Accelerated Living Assurance']/following::lightning-formatted-text[contains(text(),'TPD Condition')]/following::lightning-formatted-number")
	public static List <WebElement> tpdcACLAValue;
	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[text()='Progressive Care']/following::lightning-formatted-text[contains(text(),'TPD Condition')]/following::lightning-formatted-number")
	public static List <WebElement> tpdcSPCValue;
	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[text()='Living Assurance']/following::lightning-formatted-text[contains(text(),'TPD Condition')]/following::lightning-formatted-number")
	public static List <WebElement> tpdcSCLAValue;

	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Progressive Care']/following::div[text()='TPD Condition']/following::span[text()='Add More']/parent::button[1]")
	public static List <WebElement> addTPDCAPCLoading;
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Progressive Care']/following::div[text()='TPD Condition']/following::span[text()='Show/Hide Loading']/parent::a")
	public static WebElement showHideTPDCAPCLoading;
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Progressive Care']/following::div[text()='TPD Condition']/following::input[@name='inputLoading']")
	public static List <WebElement> tpdcAPCLoadingPercentage;
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Living Assurance']/following::div[text()='TPD Condition']/following::span[text()='Add More']/parent::button[1]")
	public static List <WebElement> addTPDCACLALoading;
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Living Assurance']/following::div[text()='TPD Condition']/following::span[text()='Show/Hide Loading']/parent::a")
	public static WebElement showHideTPDCACLALoading;
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Living Assurance']/following::div[text()='TPD Condition']/following::input[@name='inputLoading']")
	public static List <WebElement> tpdcACLALoadingPercentage;
	
	@FindBy(how= How.XPATH, using="//div[text()='Progressive Care']/following::div[text()='TPD Condition']/following::span[text()='Add More']/parent::button[1]")
	public static List <WebElement> addTPDCSPCLoading;
	
	@FindBy(how= How.XPATH, using="//div[text()='Progressive Care']/following::div[text()='TPD Condition']/following::span[text()='Show/Hide Loading']/parent::a")								  
	public static WebElement showHideTPDCSPCLoading;
	
	@FindBy(how= How.XPATH, using="//div[text()='Progressive Care']/following::div[text()='TPD Condition']/following::input[@name='inputLoading']")
	public static List <WebElement> tpdcSPCLoadingPercentage;
	
	@FindBy(how= How.XPATH, using="//div[text()='Living Assurance']/following::div[text()='TPD Condition']/following::span[text()='Add More']/parent::button[1]")
	public static List <WebElement> addTPDCSCLALoading;
	
	@FindBy(how= How.XPATH, using="//div[text()='Living Assurance']/following::div[text()='TPD Condition']/following::span[text()='Show/Hide Loading']/parent::a")
	public static WebElement showHideTPDCSCLALoading;
	
	@FindBy(how= How.XPATH, using="//div[text()='Living Assurance']/following::div[text()='TPD Condition']/following::input[@name='inputLoading']")
	public static List <WebElement> tpdcSCLALoadingPercentage;
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Progressive Care']/following::div[text()='TPD Condition']/following::lightning-primitive-icon")
	public static List<WebElement> tpdcAPCAddMore;
	
	@FindBy(how=How.XPATH, using="//div[text()='Accelerated Progressive Care']/following::div[text()='TPD Condition']/following::span[text()='Remove Benefit']")
	public static List<WebElement> tpdcAPCRemoveBenefit;
	
	@FindBy(how= How.XPATH, using="//div[text()='Progressive Care']/following::div[text()='TPD Condition']/following::lightning-primitive-icon")
	public static List<WebElement> tpdcSPCAddMore;
	
	@FindBy(how=How.XPATH, using="//div[text()='Progressive Care']/following::div[text()='TPD Condition']/following::span[text()='Remove Benefit']")
	public static List<WebElement> tpdcSPCRemoveBenefit;
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Living Assurance']/following::div[text()='TPD Condition']/following::lightning-primitive-icon")
	public static List<WebElement> tpdcACLAAddMore;
	
	@FindBy(how=How.XPATH, using="//div[text()='Accelerated Living Assurance']/following::div[text()='TPD Condition']/following::span[text()='Remove Benefit']")
	public static List<WebElement> tpdcACLARemoveBenefit;
	
	@FindBy(how= How.XPATH, using="//div[text()='Living Assurance']/following::div[text()='TPD Condition']/following::lightning-primitive-icon")
	public static List<WebElement> tpdcSCLAAddMore;
	
	@FindBy(how=How.XPATH, using="//div[text()='Living Assurance']/following::div[text()='TPD Condition']/following::span[text()='Remove Benefit']")
	public static List<WebElement> tpdcSCLARemoveBenefit;
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Living Assurance']/following::div[text()='TPD Condition']")
	public static WebElement tpdcACLASection;	
	
	@FindBy(how= How.XPATH, using="//div[text()='Living Assurance']/following::div[text()='TPD Condition']")
	public static WebElement tpdcSCLASection;
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Progressive Care']/following::div[text()='TPD Condition']")
	public static WebElement tpdcAPCSection;
	
	@FindBy(how= How.XPATH, using="//div[text()='Progressive Care']/following::div[text()='TPD Condition']")
	public static WebElement tpdcSPCSection;
	
	public void enterTPDCSPCLoading(String percentage, int person) throws InterruptedException
	{
		if(percentage!=null)
		{
			clickSafely(addTPDCSPCLoading.get(person));
			clickSafely(showHideTPDCSPCLoading);			
			sendKeysSafely(tpdcSPCLoadingPercentage.get(person),percentage);			
		}
	}

	public void enterTPDCAPCLoading(String percentage, int person) throws InterruptedException
	{
		if(percentage!=null)
		{
			clickSafely(addTPDCAPCLoading.get(person));
			clickSafely(showHideTPDCAPCLoading);			
			sendKeysSafely(tpdcAPCLoadingPercentage.get(person),percentage);			
		}
	}

	public void enterTPDCACLALoading(String percentage, int person) throws InterruptedException
	{
		if(percentage!=null)
		{
			clickSafely(addTPDCACLALoading.get(person));
			clickSafely(showHideTPDCACLALoading);			
			sendKeysSafely(tpdcACLALoadingPercentage.get(person),percentage);			
		}
	}
	
	public void enterTPDCSCLALoading(String percentage, int person) throws InterruptedException
	{
		if(percentage!=null)
		{
			clickSafely(addTPDCSCLALoading.get(person));
			clickSafely(showHideTPDCSCLALoading);			
			sendKeysSafely(tpdcSCLALoadingPercentage.get(person),percentage);			
		}
	}


	public String getTPDCAPCValue(int person)
	{
		String value = getTextSafely(tpdcAPCValue.get(person));
		if(value.length()>0)
		{
			value = value.substring(1); 
		}
		return value;
	}
	
	public String getTPDCACLAValue(int person)
	{
		String value = getTextSafely(tpdcACLAValue.get(person));
		if(value.length()>0)
		{
			value = value.substring(1); 
		}
		return value;
	}
	public String getTPDCSPCValue(int person)
	{
		String value = getTextSafely(tpdcSPCValue.get(person));
		if(value.length()>0)
		{
			value = value.substring(1); 
		}
		return value;
	}
	
	public String getTPDCSCLAValue(int person)
	{
		String value = getTextSafely(tpdcSCLAValue.get(person));
		if(value.length()>0)
		{
			value = value.substring(1); 
		}
		return value;
	}
	
	public void removeTPDCACLA(int person) throws InterruptedException
	{
		clickSafely(tpdcACLAAddMore.get(0));
		clickSafely(tpdcACLARemoveBenefit.get(0));		
	}
	
	public void removeTPDCSCLA(int person) throws InterruptedException
	{
		clickSafely(tpdcSCLAAddMore.get(0));
		clickSafely(tpdcSCLARemoveBenefit.get(0));		
	}
	
	public void removeTPDCAPC(int person) throws InterruptedException
	{
		clickSafely(tpdcAPCAddMore.get(0));
		clickSafely(tpdcAPCRemoveBenefit.get(0));		
	}
	
	public void removeTPDCSPC(int person) throws InterruptedException
	{
		clickSafely(tpdcSPCAddMore.get(0));
		clickSafely(tpdcSPCRemoveBenefit.get(0));		
	}
	
	public boolean isTPDCACLASectionDisplayed()
	{
		return isNotDisplayed(tpdcACLASection);		
	}
	
	public boolean isTPDCSCLASectionDisplayed()
	{
		return isNotDisplayed(tpdcSCLASection);		
	}
	
	public boolean isTPDCAPCSectionDisplayed()
	{
		return isNotDisplayed(tpdcAPCSection);		
	}
	
	public boolean isTPDCSPCSectionDisplayed()
	{
		return isNotDisplayed(tpdcSPCSection);		
	}

}
