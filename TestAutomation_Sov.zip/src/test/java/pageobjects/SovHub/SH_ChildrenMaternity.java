package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import pageobjects.BaseClass;

public class SH_ChildrenMaternity extends BaseClass{

	public SH_ChildrenMaternity(WebDriver driver) {
		super(driver);
	}
	

	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[contains(text(),\"Children's and Maternity\")]/following::lightning-formatted-number")
	public static List <WebElement> cmValue;
		
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Children's and Maternity')]/preceding::lightning-icon[contains(@class,'check')]")
	public static WebElement cmCheck;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Children's and Maternity')]/preceding::button[contains(@class,'missionControlWarning')]")
	public static WebElement cmWarning;	
	
	
	public String getCMValue(int person)
	{
		String value = getTextSafely(cmValue.get(person)).substring(1);    	
		return value;
	}
	
	public boolean isMCStatusSuccessful()
	{		  	
		return cmCheck.isDisplayed();
	}
	
	public boolean isMCStatusWarning()
	{		  	
		return cmWarning.isDisplayed();
	}
	
}
