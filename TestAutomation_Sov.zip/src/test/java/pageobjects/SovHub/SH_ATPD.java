package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import pageobjects.BaseClass;

public class SH_ATPD extends BaseClass{

	public SH_ATPD(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Accelerated Total Permanent Disablement')]/following::input[@name='inputBenefitAmount']")
	public static List <WebElement> sumAssured;	
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Total Permanent Disablement']/following::legend[contains(text(), 'Indexation')]/following::button[1]")
	public static List <WebElement> indexed;

	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Total Permanent Disablement']/following::legend[contains(text(), 'Indexation')]/following::button[2]")
	public static List <WebElement> level;
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Total Permanent Disablement']/following::button[text()='Rate for Age']")
	public static List <WebElement> rateForAge;

	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Total Permanent Disablement']/following::button[text()='10 Year']")
	public static List <WebElement> tenYear;

	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Total Permanent Disablement']/following::button[text()='To Age 65']")
	public static List <WebElement> toAge65;
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Total Permanent Disablement']/following::button[text()='Own Occupation']")
	public static List <WebElement> ownOccupation;
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Total Permanent Disablement']/following::button[text()='Any Occupation']")
	public static List <WebElement> anyOccupation;
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Total Permanent Disablement']/following::legend[contains(text(), 'Benefit Term')]/following::button[text()='To Age 65']")
	public static List <WebElement> benefitTerm65;
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Total Permanent Disablement']/following::legend[contains(text(), 'Benefit Term')]/following::button[text()='To Age 70']")
	public static List <WebElement> benefitTerm70;
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Total Permanent Disablement']/following::input[@name='inputLoading']")
	public static List <WebElement> loading;

	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Total Permanent Disablement']/following::input[@name='inputLoadingTerm']")
	public static List <WebElement> loadingTerm;

	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Total Permanent Disablement']/following::input[@name='inputPerMille']")
	public static List <WebElement> perMille;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Accelerated Total Permanent Disablement')]/following::span[text()='Show/Hide Loading']/parent::a")
	public static WebElement showHideLoading;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Accelerated Total Permanent Disablement')]/following::span[text()='Add More']/parent::button[1]")
	public static List <WebElement> addLoading;	

	@FindBy(how= How.XPATH, using="//div[@class='slds-float--left ']")
	public static List <WebElement> expandLoading;
	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[contains(text(),'Total Permanent Disablement')]/following::lightning-formatted-number")
	public static List <WebElement> atpdValue;
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Total Permanent Disablement']")
	public static WebElement atpdSection;	
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Total Permanent Disablement']/following::legend[contains(text(),'Business Safeguard')]/following::button[text()='Yes']")
	public static WebElement bsATPDYes;
	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[contains(text(),'Accelerated Total Permanent Disablement')]/following::lightning-formatted-text[contains(text(),'Business Safeguard')]/following::lightning-formatted-number")
	public static List <WebElement> atpdBSValue;
	
	public void enterSumAssured(String amount, int person) throws InterruptedException
	{
		if(amount!=null)
		{			
			sendKeysSafely(sumAssured.get(person),amount);			
		}
	}
	
	public void selectIndexation(String indexation, int person) throws InterruptedException
	{
		switch (indexation)
		{
		case "Indexed":
			clickSafely(indexed.get(person));    	
			break;

		case "Level":    		
			clickSafely(level.get(person));
			break;
		}
	}
	
	public void selectPremiumOption(String PremiumOption, int person) throws InterruptedException
	{
		switch (PremiumOption)
		{
		case "Rate For Age":
			clickSafelyJS(rateForAge.get(person));
			break;

		case "10 Year":
			clickSafelyJS(tenYear.get(person));
			break;

		case "To Age 65":
			clickSafelyJS(toAge65.get(person));
			break;		
		}
	}
	
	public void selectBenefitType(String type, int person) throws InterruptedException
	{
		switch (type)
		{
		case "Own Occupation":
			clickSafely(ownOccupation.get(person));    	
			break;

		case "Any Occupation":    		
			clickSafely(anyOccupation.get(person));
			break;
		}
	}
	
	public void selectBenefitTerm(String term, int person) throws InterruptedException
	{
		switch (term)
		{
		case "To Age 65":
			clickSafely(benefitTerm65.get(person));    	
			break;

		case "To Age 70":    		
			clickSafely(benefitTerm70.get(person));
			break;
		}
	}
	
	public void enterLoading(String percentage, int person) throws InterruptedException
	{
		if(percentage!=null)
		{
			clickSafely(addLoading.get(person));
			clickSafely(showHideLoading);			
			sendKeysSafely(loading.get(person),percentage);			
		}
	}

	public void enterLoadingTerm(String term, int person) throws InterruptedException
	{
		if(term!=null)
		{
			sendKeysSafely(loadingTerm.get(person),term);
		}
		else
		{
			sendKeysSafely(loadingTerm.get(person),"");
		}
	}

	public void enterPerMille(String mille, int person) throws InterruptedException
	{
		if(mille!=null)
		{
			sendKeysSafely(perMille.get(person),mille);
			sendEnterKeysSafely(perMille.get(person));
		}
	}
	
	public String getATPDValue(int person)
	{
		String value = getTextSafely(atpdValue.get(person));
		if(value.length()>0)
		{
			value = value.substring(1); 
		}
		return value;
	}
	
	public boolean isATPDSectionDisplayed() throws Exception
	{
		return isNotDisplayed(atpdSection);
	}
	
	public void addBSATPD() throws InterruptedException
	{		
		clickSafelyJS(bsATPDYes);		
	}
	
	public String getBSATPDValue(int person)
	{
		String value = getTextSafely(atpdBSValue.get(person));
		if(value.length()>0)
		{
			value = value.substring(1); 
		}
		return value;
	}

}
