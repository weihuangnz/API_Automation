package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import pageobjects.BaseClass;

public class SH_LivingBB extends BaseClass{

	public SH_LivingBB(WebDriver driver) {
		super(driver);
	}
	

	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[contains(text(),'Living Buy-Back')]/following::lightning-formatted-number")
	public static List <WebElement> livingBBValue;
		
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Living Buy-Back')]/preceding::lightning-icon[contains(@class,'check')]")
	public static WebElement livingBBCheck;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Living Buy-Back')]/preceding::button[contains(@class,'missionControlWarning')]")
	public static WebElement livingBBWarning;	
	
	
	public String getLivingBBValue(int person)
	{
		String value = getTextSafely(livingBBValue.get(person)).substring(1);    	
		return value;
	}
	
	public boolean isLivingBBStatusSuccessful()
	{		  	
		return livingBBCheck.isDisplayed();
	}
	
	public boolean isLivingBBStatusWarning()
	{		  	
		return livingBBWarning.isDisplayed();
	}
	
}
