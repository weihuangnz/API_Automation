package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import pageobjects.BaseClass;

public class SH_LogOut extends BaseClass{
	
    public SH_LogOut(WebDriver driver)
    {
        super(driver);
    }
    
	@FindBy(how= How.XPATH, using="//h2[contains(text(), 'Thanks for using SOVHUB')]")
	public static WebElement logOutText;
	
	
	public String getLogoutText()
	{
		String logoutText = logOutText.getText();
		return logoutText;
	}
    
}
