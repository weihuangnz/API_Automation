package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import modules.DriverExtension;
import pageobjects.BaseClass;

public class SH_MortgageIncomeProtection extends BaseClass{

	public SH_MortgageIncomeProtection(WebDriver driver){
		super(driver);
	}
	
	@FindBy(how= How.XPATH, using="//div[text()='Mortgage and Income Protection']/following::legend[contains(text(), 'Protection Type')]/following::button[2]")
	public static List <WebElement> mortgage;

	@FindBy(how= How.XPATH, using="//div[text()='Mortgage and Income Protection']/following::legend[contains(text(), 'Protection Type')]/following::button[1]")
	public static List <WebElement> income;
	
	@FindBy(how= How.XPATH, using="//div[text()='Mortgage and Income Protection']/following::legend[contains(text(), 'Sum Assured Frequency')]/following::button[2]")
	public static List <WebElement> monthly;
	
	@FindBy(how= How.XPATH, using="//div[text()='Mortgage and Income Protection']/following::legend[contains(text(), 'Sum Assured Frequency')]/following::button[1]")
	public static List <WebElement> annually;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Mortgage and Income Protection')]/following::input[@name='inputBenefitAmount']")
	public static List <WebElement> sumAssured;	
	
	@FindBy(how= How.XPATH, using="//div[text()='Mortgage and Income Protection']/following::legend[contains(text(), 'Indexation')]/following::button[1]")
	public static List <WebElement> indexed;

	@FindBy(how= How.XPATH, using="//div[text()='Mortgage and Income Protection']/following::legend[contains(text(), 'Indexation')]/following::button[2]")
	public static List <WebElement> level;
	
	@FindBy(how= How.XPATH, using="//div[text()='Mortgage and Income Protection']/following::button[text()='Rate for Age']")
	public static List <WebElement> rateForAge;

	@FindBy(how= How.XPATH, using="//div[text()='Mortgage and Income Protection']/following::button[text()='10 Year']")
	public static List <WebElement> tenYear;

	@FindBy(how= How.XPATH, using="//div[text()='Mortgage and Income Protection']/following::button[text()='To Age 65']")
	public static List <WebElement> toAge65;
	
	
	@FindBy(how= How.XPATH, using="//div[text()='Mortgage and Income Protection']/following::legend[contains(text(), 'Payment Period')]/following::button[text()='2 years']")
	public static List <WebElement> pp2years;
	
	@FindBy(how= How.XPATH, using="//div[text()='Mortgage and Income Protection']/following::legend[contains(text(), 'Payment Period')]/following::button[text()='5 years']")
	public static List <WebElement> pp5years;
	
	@FindBy(how= How.XPATH, using="//div[text()='Mortgage and Income Protection']/following::legend[contains(text(), 'Payment Period')]/following::button[text()='To Age 65']")
	public static List <WebElement> ppToAge65;
	
	@FindBy(how= How.XPATH, using="//div[text()='Mortgage and Income Protection']/following::legend[contains(text(), 'Payment Period')]/following::button[text()='To Age 70']")
	public static List <WebElement> ppToAge70;
	
	@FindBy(how= How.XPATH, using="//div[text()='Mortgage and Income Protection']/following::legend[contains(text(), 'Waiting Period')]/following::button[text()='4']")
	public static List <WebElement> wp4;
	
	@FindBy(how= How.XPATH, using="//div[text()='Mortgage and Income Protection']/following::legend[contains(text(), 'Waiting Period')]/following::button[text()='8']")
	public static List <WebElement> wp8;
	
	@FindBy(how= How.XPATH, using="//div[text()='Mortgage and Income Protection']/following::legend[contains(text(), 'Waiting Period')]/following::button[text()='13']")
	public static List <WebElement> wp13;
	
	@FindBy(how= How.XPATH, using="//div[text()='Mortgage and Income Protection']/following::legend[contains(text(), 'Waiting Period')]/following::button[text()='26']")
	public static List <WebElement> wp26;
	
	@FindBy(how= How.XPATH, using="//div[text()='Mortgage and Income Protection']/following::legend[contains(text(), 'Waiting Period')]/following::button[text()='52']")
	public static List <WebElement> wp52;
	
	@FindBy(how= How.XPATH, using="//div[text()='Mortgage and Income Protection']/following::legend[contains(text(), 'Waiting Period')]/following::button[text()='104']")
	public static List <WebElement> wp104;
	
	@FindBy(how= How.XPATH, using="//div[text()='Mortgage and Income Protection']/following::legend[contains(text(), 'Mental Health Limitation')]/following::button[1]")
	public static List <WebElement> mentalHealthYes;

	@FindBy(how= How.XPATH, using="//div[text()='Mortgage and Income Protection']/following::legend[contains(text(), 'Mental Health Limitation')]/following::button[2]")
	public static List <WebElement> mentalHealthNo;
	
	@FindBy(how= How.XPATH, using="//div[text()='Mortgage and Income Protection']/following::legend[contains(text(), 'Mental Health Exclusion')]/following::button[1]")
	public static List <WebElement> mentalHealthExclusionYes;

	@FindBy(how= How.XPATH, using="//div[text()='Mortgage and Income Protection']/following::legend[contains(text(), 'Mental Health Exclusion')]/following::button[2]")
	public static List <WebElement> mentalHealthExclusionNo;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Mortgage and Income Protection')]/following::span[text()='Add More']/parent::button[1]")
	public static List <WebElement> addMIPLoading;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Mortgage and Income Protection')]/following::span[text()='Show/Hide Loading']/parent::a")
	public static WebElement showHideMIPLoading;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Mortgage and Income Protection')]/following::input[@name='inputLoading']")
	public static List <WebElement> mipLoadingPercentage;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Mortgage and Income Protection')]/following::lightning-formatted-number")
	public static List <WebElement> mipValue;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Mortgage and Income Protection')]/preceding::lightning-icon[contains(@class,'check')]")
	public static WebElement mipCheck;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Mortgage and Income Protection')]/preceding::button[contains(@class,'missionControlWarning')]")
	public static WebElement mipWarning;	
	
	@FindBy(how= How.NAME, using="inputMonthlyRepaymentAmount")
	public static List <WebElement> monthlyMortgageAmount;
	
	
	public void selectMortgageType(String type, int person) throws InterruptedException
	{
		switch (type)
		{
		case "Mortgage":
			clickSafely(mortgage.get(person));    	
			break;

		case "Income":    		
			clickSafely(income.get(person));
			break;
		}
		skipLoadingAnimation();
	}
	
	public void selectMentalHealthOption(String option, int person) throws InterruptedException
	{		
		DriverExtension.scrollToBottom(driver);	
		switch (option)
		{
		case "Yes":
			clickSafelyJS(mentalHealthYes.get(person));
			break;

		case "No":
			clickSafelyJS(mentalHealthNo.get(person));
			break;
		}
	}
	
	public void selectMentalHealthExclusion(String option, int person) throws InterruptedException
	{		
		DriverExtension.scrollToBottom(driver);	
		switch (option)
		{
		case "Yes":
			clickSafelyJS(mentalHealthExclusionYes.get(person));
			break;

		case "No":
			clickSafelyJS(mentalHealthExclusionNo.get(person));
			break;
		}
	}
	
	public void enterMIPLoadingPercentage(String percentage, int person) throws InterruptedException
	{
		if(percentage!=null)
		{
			clickSafely(addMIPLoading.get(person));
			clickSafely(showHideMIPLoading);	
			scrollIntoView(mipLoadingPercentage.get(person));	
			sendKeysSafely(mipLoadingPercentage.get(person),percentage);			
		}
	}
	
	public void enterMonthlyMortgageAmount(String amount, int person) throws InterruptedException
	{
		if(amount!=null)
		{
			clickSafely(monthlyMortgageAmount.get(person));				
			sendKeysSafely(monthlyMortgageAmount.get(person),amount);			
		}
	}
	
	
	public void selectSumAssuredFrequency(String frequency, int person) throws InterruptedException
	{
		switch (frequency)
		{
		case "Annually":
			clickSafely(annually.get(person));    	
			break;

		case "Monthly":    		
			clickSafely(monthly.get(person));
			break;
		}
	}
	
	public void selectPaymentPeriod(String period, int person) throws InterruptedException
	{
		switch (period)
		{
		case "2 years":
			clickSafely(pp2years.get(person));    	
			break;

		case "5 years":    		
			clickSafely(pp5years.get(person));
			break;
			
		case "To Age 65":    		
			clickSafely(ppToAge65.get(person));
			break;
			
		case "To Age 70":    		
			clickSafely(ppToAge70.get(person));
			break;
		}
	}
	
	public void selectWaitingPeriod(String period, int person) throws InterruptedException
	{
		switch (period)
		{
		case "4":
			clickSafely(wp4.get(person));    	
			break;

		case "8":    		
			clickSafely(wp8.get(person));
			break;
			
		case "13":    		
			clickSafely(wp13.get(person));
			break;
			
		case "26":    		
			clickSafely(wp26.get(person));
			break;
			
		case "52":    		
			clickSafely(wp52.get(person));
			break;
			
		case "104":    		
			clickSafely(wp104.get(person));
			break;
		}
	}
	
	public void enterSumAssured(String amount, int person) throws InterruptedException
	{
		if(amount!=null)
		{			
			sendKeysSafely(sumAssured.get(person),amount);			
		}
	}
	
	public void selectIndexation(String indexation, int person) throws InterruptedException
	{
		switch (indexation)
		{
		case "Indexed":
			clickSafely(indexed.get(person));    	
			break;

		case "Level":    		
			clickSafely(level.get(person));
			break;
		}
	}
	
	public void selectPremiumOption(String PremiumOption, int person) throws InterruptedException
	{
		switch (PremiumOption)
		{
		case "Rate For Age":
			clickSafelyJS(rateForAge.get(person));
			break;

		case "10 Year":
			clickSafelyJS(tenYear.get(person));
			break;

		case "To Age 65":
			clickSafelyJS(toAge65.get(person));
			break;		
		}
	}
	
	public String getMIPValue(int person)
	{
		String value = getTextSafely(mipValue.get(person));
		if(value.length()>0)
		{
			value = value.substring(1); 
		} 
		return value;
	}
	
	public boolean isMIPStatusSuccessful()
	{		  	
		return mipCheck.isDisplayed();
	}
	
	public boolean isMIPStatusWarning()
	{		  	
		return mipWarning.isDisplayed();
	}


}
