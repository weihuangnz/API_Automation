package pageobjects.SovHub;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import PropertiesFilesStrategy.PropertiesFileUtil;
import modules.DriverExtension;
import pageobjects.BaseClass;

public class SH_Login extends BaseClass {
	
    public SH_Login(WebDriver driver)
    {
        super(driver);
    }
    
    String propFileName;
    
    
    @FindBy(how= How.ID, using="username")
    public static WebElement userName;
    
    @FindBy(how= How.ID, using="password")
    public static WebElement passWord;
     
    @FindBy(how= How.XPATH, using="//input[@type='submit']")
    public static WebElement logIn;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(),'sso')]/parent::button")
    public static WebElement ssoButton;
    
  
   
    public void sovHubLogin() throws IOException, InterruptedException {

    	propFileName = DriverExtension.getEnvironment();
    	
    	PropertiesFileUtil properties = PropertiesFileUtil.getInstance(propFileName);
    	
    	if(properties != null)
    	{
    		//clickSafely(ssoButton);	
    		sendKeysSafely(userName,properties.getProperty("sovHubUsername"));
    		sendKeysSafely(passWord,properties.getProperty("sovHubPassword"));            
            DriverExtension.waitforElementThenClick(driver, logIn);
    	}else
    	{
    		throw new FileNotFoundException("Property file " + propFileName + " not found..." );
    	}

    }

}
