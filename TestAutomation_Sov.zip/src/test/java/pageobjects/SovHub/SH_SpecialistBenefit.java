package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import pageobjects.BaseClass;

public class SH_SpecialistBenefit extends BaseClass{

	public SH_SpecialistBenefit(WebDriver driver) {
		super(driver);
	}		

	@FindBy(how= How.XPATH, using="//div[text()='Specialist & Diagnostic Testing']/following::legend[text()='Excess']/following::button[1]")
	public static List <WebElement> zeroExcess;
	
	@FindBy(how= How.XPATH, using="//div[text()='Specialist & Diagnostic Testing']/following::legend[text()='Excess']/following::button[2]")
	public static List <WebElement> additionalExcess;

	//@FindBy(how= How.XPATH, using="//legend[contains(text(),'Child Benefit')]/following::button[1]")
	@FindBy(how= How.XPATH, using="//legend[contains(text(),'Specialist & Diagnostic Testing - Child')]/following::button[1]")
	public static List <WebElement> childCoverYes;

	//@FindBy(how= How.XPATH, using="//legend[contains(text(),'Child Benefit')]/following::button[2]")
	@FindBy(how= How.XPATH, using="//legend[contains(text(),'Specialist & Diagnostic Testing - Child')]/following::button[1]")
	public static List <WebElement> childCoverNo;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Specialist & Diagnostic Testing')]/following::span[text()='Show/Hide Loading']/parent::a")
	public static WebElement showHideSTLoading;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Specialist & Diagnostic Testing')]/following::span[text()='Add More']/parent::button[1]")
	public static List <WebElement> addSTLoading;	

	@FindBy(how= How.XPATH, using="//div[contains(text(),'Specialist & Diagnostic Testing')]/following::div[contains(@class,'quote-benefit')]")
	public static List <WebElement> specialistLoading;

	@FindBy(how= How.XPATH, using="//div[contains(text(),'Specialist & Diagnostic Testing')]/following::input[@name='inputLoading']")
	public static List <WebElement> specialistLoadingPercentage;

	@FindBy(how= How.NAME, using="numberOfChildren")
	public static List <WebElement> numberOfChildren;

	@FindBy(how= How.XPATH, using="//button[@title='Add Children']")
	public static List <WebElement> addChildren;
	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[text()='Specialist & Diagnostic Testing']/following::lightning-formatted-number[1]")
	public static List <WebElement> specialistValue;
	
	//@FindBy(how= How.XPATH, using="//lightning-formatted-text[text()='Child Benefit']/following::lightning-formatted-number[1]")
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[text()='Specialist & Diagnostic Testing - Child']/following::lightning-formatted-number[1]")
	public static List<WebElement> specialistChildrenValue;
	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[text()='Specialist & Diagnostic Testing']/preceding::lightning-icon[contains(@class,'check')]")	
	public static WebElement sdtCheck;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Specialist & Diagnostic Testing')]/preceding::button[contains(@class,'missionControlWarning')][1]")
	public static WebElement sdtWarning;
	
	@FindBy(how= How.XPATH, using="(//div[text()='Specialist & Diagnostic Testing'])[1]")
	public static WebElement sdtAdultSection;
	
	@FindBy(how= How.XPATH, using="(//div[text()='Specialist & Diagnostic Testing'])[2]")
	public static WebElement sdtChildSection;
	
	@FindBy(how= How.XPATH, using="(//div[text()='Specialist & Diagnostic Testing'])[2]/following::button[contains(@class,'AddBenefitButton')]")
	public static WebElement sdtChildSelection;
	
	@FindBy(how= How.XPATH, using="(//div[text()='Specialist & Diagnostic Testing'])[2]/following::button[contains(@class,'ActionButton')]")
	public static WebElement sdtChildNotAvailable;
		

	public void selectExcess(String excessValue, int person) throws InterruptedException
	{
		switch (excessValue)
		{
		case "$0":
			clickSafely(zeroExcess.get(person));    	
			break;

		case "$300":    		
			clickSafely(additionalExcess.get(person));
			break;
		}		
	}
	
	public void selectChildCover(String cover, int person) throws InterruptedException
	{	
		switch (cover)
		{
		case "Yes":
			clickSafely(childCoverYes.get(person));    	
			break;

		case "No":    		
			clickSafely(childCoverNo.get(person));
			break;
		}
	}
	
	public void selectNumberOfChildren(String number, int person) throws InterruptedException
	{
		clickSafely(numberOfChildren.get(person));
		selectByText(numberOfChildren.get(0),number);		
	}
	
	public void addChildren(int person) throws InterruptedException
	{
		clickSafely(addChildren.get(person));
	}
	
	public void enterSpecialistLoadingPercentage(String percentage, int person) throws InterruptedException
	{
		if(percentage!=null)
		{
			clickSafely(addSTLoading.get(person));
			clickSafely(showHideSTLoading);
			sendKeysSafely(specialistLoadingPercentage.get(person),percentage);			
		}
	}	
	
	public String getSpecialistValue(int person)
	{
		String value = getTextSafely(specialistValue.get(person));
		if(value.length()>0)
		{
			value = value.substring(1); 
		}
		return value;
	}
	
	public String getSpecialistChildrenValue(int person)
	{
		
		String value = getTextSafely(specialistChildrenValue.get(person));
		if(value.length()>0)
		{
			value = value.substring(1); 
		}
		return value;
	}
	
	public boolean isSDTStatusSuccessful()
	{		  	
		return sdtCheck.isDisplayed();
	}
	
	public boolean isSDTStatusWarning()
	{		  	
		return sdtWarning.isDisplayed();
	}
	
	public boolean isSDTSelectedForChild()
	{		  	
		return sdtChildSelection.isDisplayed();
	}
	
	public boolean isSDTSectionDisplayed() throws Exception
	{
		return isNotDisplayed(sdtAdultSection);
	}
	
	public boolean isSDTChildSectionDisplayed() throws Exception
	{
		return isNotDisplayed(sdtChildSection);
	}
	
	public boolean isSDTSNotAvailableForChild()
	{		  	
		return sdtChildNotAvailable.isDisplayed();
	}

}
