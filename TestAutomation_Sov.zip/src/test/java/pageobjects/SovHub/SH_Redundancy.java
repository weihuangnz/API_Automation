package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import pageobjects.BaseClass;

public class SH_Redundancy extends BaseClass{

	public SH_Redundancy(WebDriver driver) {
		super(driver);
	}

	@FindBy(how= How.XPATH, using="//div[contains(text(),'Redundancy')]/following::input[@name='inputBenefitAmount']")
	public static List <WebElement> sumAssured;	
	
	@FindBy(how= How.XPATH, using="//div[text()='Redundancy']/following::legend[contains(text(), 'Sum Assured Frequency')]/following::button[2]")
	public static List <WebElement> monthly;
	
	@FindBy(how= How.XPATH, using="//div[text()='Redundancy']/following::legend[contains(text(), 'Sum Assured Frequency')]/following::button[1]")
	public static List <WebElement> annually;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Redundancy')]/following::lightning-formatted-number")
	public static List <WebElement> redundancyValue;
	
	public void selectSumAssuredFrequency(String frequency, int person) throws InterruptedException
	{
		switch (frequency)
		{
		case "Annually":
			clickSafely(annually.get(person));    	
			break;

		case "Monthly":    		
			clickSafely(monthly.get(person));
			break;
		}
	}
	
	public void enterSumAssured(String amount, int person) throws InterruptedException
	{
		if(amount!=null)
		{			
			sendKeysSafely(sumAssured.get(person),amount);			
		}
	}
	
	public String getRedundancyValue(int person)
	{
		String value = getTextSafely(redundancyValue.get(person));
		if(value.length()>0)
			{
				value = value.substring(1); 
			}   	
		return value;
	}
}
