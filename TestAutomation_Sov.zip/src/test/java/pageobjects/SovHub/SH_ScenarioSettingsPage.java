package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import pageobjects.BaseClass;

public class SH_ScenarioSettingsPage extends BaseClass{
	
	public SH_ScenarioSettingsPage(WebDriver driver)
	{
		super(driver);
	}
	
    @FindBy(how= How.XPATH, using="//div[text()='OTHER ADJUSTMENTS']")
    public static WebElement otherAdjustments;  
    
    @FindBy(how= How.NAME, using="CommissionSelect")
    public static List <WebElement> commissionAdjustment;
    
    @FindBy(how= How.NAME, using="save")
    public static WebElement saveBtn;
    
    @FindBy(how= How.NAME, using="PaymentFrequencySelect")
    public static List <WebElement> paymentFrequency;    
  
    @FindBy(how= How.XPATH, using="//button[text()='YES']")
    public static WebElement policyFeesYes;
    
    @FindBy(how= How.XPATH, using="//button[text()='NO']")
    public static WebElement policyFeesNo;  
    
    @FindBy(how= How.XPATH, using="//legend[text()='Waive Private Health Policy Fee']/following::button[1]")
    public static WebElement phPolicyFeesYes;
    
    @FindBy(how= How.XPATH, using="//legend[text()='Waive Private Health Policy Fee']/following::button[2]")
    public static WebElement phPolicyFeesNo; 
    
    @FindBy(how= How.XPATH, using="//span[text()='Commission on Private Health benefits']/following::select[1]")
    public static WebElement phCommissionAdjustment;  
    
    @FindBy(how= How.XPATH, using="//legend[text()='Group Discount']/following::button[text()='Yes']")
    public static WebElement groupDiscountYes;
    
    @FindBy(how= How.XPATH, using="//legend[text()='Group Discount']/following::button[text()='No']")
    public static WebElement groupDiscountNo;
  
          
    public void expandOtherAdjustments() throws InterruptedException
    {
    	//skipLoadingAnimation();
    	clickSafely(otherAdjustments);
    }
    
    public void enterCommision(String commission) throws InterruptedException
    {
    	clickSafely(commissionAdjustment.get(0));
    	selectByText(commissionAdjustment.get(0),commission);  	
    }
    
    public void clickSave() throws InterruptedException
    {
    	clickSafely(saveBtn);
    }  
    
    
    public void selectPaymentfrequency(String frequency, int person) throws InterruptedException
    {
    	clickSafely(paymentFrequency.get(person));    	
        selectByText(paymentFrequency.get(0),frequency);
    }
    
    public void selectPolicyFeesOption(String policyFees) throws InterruptedException
	{
		switch (policyFees)
		{
		case "Yes":
			clickSafelyJS(policyFeesYes);
			break;

		case "No":
			clickSafelyJS(policyFeesNo);
			break;		
		}
	}
    
    public void selectPHPolicyFeesOption(String policyFees) throws InterruptedException
   	{
   		switch (policyFees)
   		{
   		case "Yes":
   			clickSafelyJS(phPolicyFeesYes);
   			break;

   		case "No":
   			clickSafelyJS(phPolicyFeesNo);
   			break;		
   		}
   	}
    
    public void enterPHCommision(String commission) throws InterruptedException
    {
    	clickSafely(phCommissionAdjustment);
    	selectByText(phCommissionAdjustment,commission);  	
    }
    
    public void selectGroupDiscount(String discount) throws InterruptedException
	{
		switch (discount)
		{
		case "Yes":
			clickSafelyJS(groupDiscountYes);
			break;

		case "No":
			clickSafelyJS(groupDiscountNo);
			break;		
		}
	}
	

}
