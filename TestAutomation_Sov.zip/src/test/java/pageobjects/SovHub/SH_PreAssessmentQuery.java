package pageobjects.SovHub;

import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import modules.DriverExtension;
import pageobjects.BaseClass;

public class SH_PreAssessmentQuery extends BaseClass{

    public SH_PreAssessmentQuery(WebDriver driver)
    {
        super(driver);
    }
    
    @FindBy(how= How.XPATH, using="//h1")
    public static WebElement header;
    
  
     
    public String getHearderText()
    {
    	String headerText = header.getText();
    	return headerText;
    }
    
 
    
}
