package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import modules.DriverExtension;
import pageobjects.BaseClass;

public class SH_Rename_QuotePage extends BaseClass {
	
	
	public SH_Rename_QuotePage(WebDriver driver) {
		super(driver);
	}
	
	
	@FindBy(how= How.NAME, using="quoteBuilderName")
	public static WebElement quoteName;
	
    @FindBy(how= How.NAME, using="save")
    public static WebElement okBtn;
	
	
	public void renameQuote(String quoteNameText)
	{
		DriverExtension.waitForElementToAppear(driver,quoteName);
		quoteName.clear();
		quoteName.sendKeys(quoteNameText);
		
		okBtn.click();
	}
	
	

}
