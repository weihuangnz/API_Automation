package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import pageobjects.BaseClass;

public class SH_SELA extends BaseClass{

	public SH_SELA(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(how= How.XPATH, using="//div[text()='Essential Living Assurance']/following::input[@name='inputBenefitAmount']")
	public static List <WebElement> sumAssured;	
	
	@FindBy(how= How.XPATH, using="//div[text()='Essential Living Assurance']/following::legend[contains(text(), 'Indexation')]/following::button[1]")
	public static List <WebElement> indexed;

	@FindBy(how= How.XPATH, using="//div[text()='Essential Living Assurance']/following::legend[contains(text(), 'Indexation')]/following::button[2]")
	public static List <WebElement> level;
	
	@FindBy(how= How.XPATH, using="//div[text()='Essential Living Assurance']/following::button[text()='Rate for Age']")
	public static List <WebElement> rateForAge;

	@FindBy(how= How.XPATH, using="//div[text()='Essential Living Assurance']/following::button[text()='10 Year']")
	public static List <WebElement> tenYear;

	@FindBy(how= How.XPATH, using="//div[text()='Essential Living Assurance']/following::button[text()='To Age 65']")
	public static List <WebElement> toAge65;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Essential Living Assurance')]/following::span[text()='Add More']/parent::button[1]")
	public static List <WebElement> addSELALoading;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Essential Living Assurance')]/following::span[text()='Show/Hide Loading']/parent::a")
	public static WebElement showHideSELALoading;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Essential Living Assurance')]/following::input[@name='inputLoading']")
	public static List <WebElement> selaLoadingPercentage;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Essential Living Assurance')]/following::input[@name='inputLoadingTerm']")
	public static List <WebElement> selaLoadingTerm;

	@FindBy(how= How.XPATH, using="//div[contains(text(),'Essential Living Assurance')]/following::input[@name='inputPerMille']")
	public static List <WebElement> selaPerMille;
	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[contains(text(),'Essential Living Assurance')]/following::lightning-formatted-number")
	public static List <WebElement> selaValue;
	
	public void enterSumAssured(String amount, int person) throws InterruptedException
	{
		if(amount!=null)
		{			
			sendKeysSafely(sumAssured.get(person),amount);			
		}
	}
	
	public void selectPremiumOption(String PremiumOption, int person) throws InterruptedException
	{
		switch (PremiumOption)
		{
		case "Rate For Age":
			clickSafelyJS(rateForAge.get(person));
			break;

		case "10 Year":
			clickSafelyJS(tenYear.get(person));
			break;

		case "To Age 65":
			clickSafelyJS(toAge65.get(person));
			break;		
		}
	}
	
	public void selectIndexation(String indexation, int person) throws InterruptedException
	{
		switch (indexation)
		{
		case "Indexed":
			clickSafely(indexed.get(person));    	
			break;

		case "Level":    		
			clickSafely(level.get(person));
			break;
		}
	}
	
	public void enterLoadingPercentage(String percentage, int person) throws InterruptedException
	{
		if(percentage!=null)
		{
			clickSafely(addSELALoading.get(person));
			clickSafely(showHideSELALoading);	
			scrollIntoView(selaLoadingPercentage.get(person));	
			sendKeysSafely(selaLoadingPercentage.get(person),percentage);			
		}
	}
	
	public void enterLoadingTerm(String term, int person) throws InterruptedException
	{
		if(term!=null)
		{
			sendKeysSafely(selaLoadingTerm.get(person),term);
		}
		else
		{
			sendKeysSafely(selaLoadingTerm.get(person),"");
		}
	}

	public void enterPerMille(String mille, int person) throws InterruptedException
	{
		if(mille!=null)
		{
			sendKeysSafely(selaPerMille.get(person),mille);
			sendEnterKeysSafely(selaPerMille.get(person));
		}
	}
	
	public String getSELAValue(int person)
	{
		String value = getTextSafely(selaValue.get(person));
		if(value.length()>0)
		{
			value = value.substring(1); 
		}
		return value;
	}

}
