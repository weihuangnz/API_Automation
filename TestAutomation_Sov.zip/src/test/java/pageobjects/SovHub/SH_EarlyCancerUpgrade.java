package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import pageobjects.BaseClass;

public class SH_EarlyCancerUpgrade extends BaseClass{

	public SH_EarlyCancerUpgrade(WebDriver driver) {
		super(driver);
	}

	@FindBy(how= How.XPATH, using="//div[contains(text(),'Early Cancer Upgrade')]/following::input[@name='inputBenefitAmount']")
	public static List <WebElement> sumAssured;

	@FindBy(how= How.XPATH, using="//div[text()='Early Cancer Upgrade']/following::input[@name='inputLoading']")
	public static List <WebElement> loading;

	@FindBy(how= How.XPATH, using="//div[text()='Early Cancer Upgrade']/following::input[@name='inputLoadingTerm']")
	public static List <WebElement> loadingTerm;

	@FindBy(how= How.XPATH, using="//div[text()='Early Cancer Upgrade']/following::input[@name='inputPerMille']")
	public static List <WebElement> perMille;

	@FindBy(how= How.XPATH, using="//div[contains(text(),'Early Cancer Upgrade')]/following::span[text()='Show/Hide Loading']/parent::a")
	public static WebElement showHideLoading;

	@FindBy(how= How.XPATH, using="//div[contains(text(),'Early Cancer Upgrade')]/following::span[text()='Add More']/parent::button[1]")
	public static List <WebElement> addLoading;	

	@FindBy(how= How.XPATH, using="//div[@class='slds-float--left ']")
	public static List <WebElement> expandLoading;

	@FindBy(how= How.XPATH, using="//div[contains(text(),'Early Cancer Upgrade')]/following::lightning-formatted-number")
	public static List <WebElement> ecuValue;

	public void enterLoading(String percentage, int person) throws InterruptedException
	{
		if(percentage!=null)
		{
			clickSafely(addLoading.get(person));
			clickSafely(showHideLoading);			
			sendKeysSafely(loading.get(person),percentage);			
		}
	}

	public void enterLoadingTerm(String term, int person) throws InterruptedException
	{
		if(term!=null)
		{
			sendKeysSafely(loadingTerm.get(person),term);
		}
		else
		{
			sendKeysSafely(loadingTerm.get(person),"");
		}
	}

	public void enterPerMille(String mille, int person) throws InterruptedException
	{
		if(mille!=null)
		{
			sendKeysSafely(perMille.get(person),mille);
			sendEnterKeysSafely(perMille.get(person));
		}
		else
		{
			sendKeysSafely(perMille.get(person),"");
		}
	}

	public String getECUValue(int person)
	{
		String value = getTextSafely(ecuValue.get(person));
		if(value.length()>0)
		{
			value = value.substring(1); 
		}
		return value;
	}

	public String getSumAssured(int person) 
	{					
		return getAttributeSafely(sumAssured.get(person),"value").substring(1);
	}
	
	public String isSumAssuredDisabled(int person)
	{
		return getAttributeSafely(sumAssured.get(person),"outerHTML");
	}
}
