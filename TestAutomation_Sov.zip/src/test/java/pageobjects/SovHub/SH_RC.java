package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import pageobjects.BaseClass;

public class SH_RC extends BaseClass{

	public SH_RC(WebDriver driver) {
		super(driver);
	}
	
	//@FindBy(how= How.NAME, using="inputBenefitAmount")
	@FindBy(how= How.XPATH, using="//div[text()='Rural Continuity']/following::input[@name='inputBenefitAmount']")
	public static List <WebElement> sumAssured;		
	
	@FindBy(how=How.XPATH, using="//div[text()='Rural Continuity']/following::button[text()='Annually']")
	public static List<WebElement> annuallyFrequency;
	
	@FindBy(how=How.XPATH, using="//div[text()='Rural Continuity']/following::button[text()='Monthly']")
	public static List<WebElement> monthlyFrequency;
	
	@FindBy(how= How.XPATH, using="//div[text()='Rural Continuity']/following::legend[contains(text(), 'Payment Period')]/following::button[1]")
	public static List <WebElement> sixMonth;

	@FindBy(how= How.XPATH, using="//div[text()='Rural Continuity']/following::legend[contains(text(), 'Payment Period')]/following::button[2]")
	public static List <WebElement> oneYear;
	
	@FindBy(how= How.XPATH, using="//div[text()='Rural Continuity']/following::legend[contains(text(), 'Payment Period')]/following::button[3]")
	public static List <WebElement> twoYear;
	
	@FindBy(how= How.XPATH, using="//div[text()='Rural Continuity']/following::legend[contains(text(), 'Waiting Period in Weeks')]/following::button[1]")
	public static List <WebElement> waitingPeriod4;
	
	@FindBy(how= How.XPATH, using="//div[text()='Rural Continuity']/following::legend[contains(text(), 'Waiting Period in Weeks')]/following::button[2]")
	public static List <WebElement> waitingPeriod8;
	
	@FindBy(how= How.XPATH, using="//div[text()='Rural Continuity']/following::legend[contains(text(), 'Waiting Period in Weeks')]/following::button[3]")
	public static List <WebElement> waitingPeriod13;
	
	@FindBy(how= How.XPATH, using="//div[text()='Rural Continuity']/following::span[text()='Add More']/parent::button[1]")
	public static List <WebElement> addRCLoading;
	
	@FindBy(how= How.XPATH, using="//div[text()='Rural Continuity']/following::span[text()='Show/Hide Loading']/parent::a")
	public static WebElement showHideRCLoading;	
	
	@FindBy(how= How.XPATH, using="//div[text()='Rural Continuity']/following::input[@name='inputLoading']")
	public static List <WebElement> rcLoadingPercentage;


		
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[text()='Rural Continuity']/following::lightning-formatted-number")
	public static List <WebElement> rcValue;
	
	@FindBy(how= How.XPATH, using="//div[text()='Rural Continuity']/preceding::lightning-icon[contains(@class,'check')]")
	public static WebElement rcCheck;
	
	@FindBy(how= How.XPATH, using="//div[text()='Rural Continuity']/preceding::button[contains(@class,'missionControlWarning')]")
	public static WebElement rcWarning;	
	
	@FindBy(how= How.XPATH, using="//div[text()='Rural Continuity']/following::legend[contains(text(), 'Partial Disablement')]/following::button[1]")
	public static List <WebElement> partialDisablementOptionYes;

	@FindBy(how= How.XPATH, using="//div[text()='Rural Continuity']/following::legend[contains(text(), 'Partial Disablement')]/following::button[2]")
	public static List <WebElement> partialDisablementOptionNo;
	
	@FindBy(how= How.XPATH, using="//div[text()='Rural Continuity']/following::legend[contains(text(), 'ACC Offsets')]/following::button[1]")
	public static List <WebElement> ACCOffsetsOptionYes;

	@FindBy(how= How.XPATH, using="//div[text()='Rural Continuity']/following::legend[contains(text(), 'ACC Offsets')]/following::button[2]")
	public static List <WebElement> ACCOffsetsOptionNo;
	

	@FindBy(how= How.XPATH, using="//div[text()='Rural Continuity']/following::legend[contains(text(), 'Peak Season')]/following::button[1]")
	public static List <WebElement> peakSeasonOptionYes;

	@FindBy(how= How.XPATH, using="//div[text()='Rural Continuity']/following::legend[contains(text(), 'Peak Season')]/following::button[2]")
	public static List <WebElement> peakSeasonOptionNo;
	
	@FindBy(how= How.XPATH, using="//div[text()='Rural Continuity']")
	public static WebElement rcSection;
	
	
	public void enterSumAssured(String amount, int person) throws InterruptedException
	{
		skipLoadingAnimation();
		if(amount!=null)
		{			
			sendKeysSafely(sumAssured.get(person),amount);			
		}
		skipLoadingAnimation();
	}
	
	public void selectSumAssuredFrequency(String frquency, int person) throws InterruptedException
	{
		switch (frquency)
		{
		case "Annually":
			clickSafely(annuallyFrequency.get(person));    	
			break;

		case "Monthly":    		
			clickSafely(monthlyFrequency.get(person));
			break;
		}
	}
	
	public void selectPaymentPeriod(String paymentPeriod, int person) throws InterruptedException
	{
		switch (paymentPeriod)
		{
		case "6 months":
			clickSafelyJS(sixMonth.get(person));
			break;

		case "1 year":
			clickSafelyJS(oneYear.get(person));
			break;

		case "2 years":
			clickSafelyJS(twoYear.get(person));
			break;	
		default:
			clickSafelyJS(sixMonth.get(person));
			break;
		}
	}
	
	public void selectWaitingPeriod(String waitingPeriod, int person) throws InterruptedException
	{
		switch (waitingPeriod)
		{
		case "4":
			clickSafelyJS(waitingPeriod4.get(person));
			break;

		case "8":
			clickSafelyJS(waitingPeriod8.get(person));
			break;

		case "13":
			clickSafelyJS(waitingPeriod13.get(person));
			break;	
		default:
			clickSafelyJS(waitingPeriod4.get(person));
			break;
		}
	}
	public void enterLoadingPercentage(String percentage, int person) throws InterruptedException
	{
		if(percentage!=null)
		{
			clickSafely(addRCLoading.get(person));
			clickSafely(showHideRCLoading);	
			scrollIntoView(rcLoadingPercentage.get(person));	
			sendKeysSafely(rcLoadingPercentage.get(person),percentage);			
		}
	}
	
	
	
	public String getRCValue(int person)
	{
		String value = getTextSafely(rcValue.get(person));
		if(value.length()>0)
		{
			value = value.substring(1); 
		}
		return value;
	}
	
	public boolean isRCStatusSuccessful()
	{		  	
		return rcCheck.isDisplayed();
	}
	
	public boolean isRCStatusWarning()
	{		  	
		return rcWarning.isDisplayed();
	}
	
	public void selectPartialDisablement(String partialDisablement, int person) throws InterruptedException
	{
		switch (partialDisablement)
		{
		case "Yes":
			clickSafelyJS(partialDisablementOptionYes.get(person));
			break;

		case "No":
			clickSafelyJS(partialDisablementOptionNo.get(person));
			break;	
		default:
			clickSafelyJS(partialDisablementOptionYes.get(person));
			break;
		}
	}
	
	public void selectACCOffsets(String accOffsets, int person) throws InterruptedException
	{
		switch (accOffsets)
		{
		case "Yes":
			clickSafelyJS(ACCOffsetsOptionYes.get(person));
			break;

		case "No":
			clickSafelyJS(ACCOffsetsOptionNo.get(person));
			break;	
		default:
			clickSafelyJS(ACCOffsetsOptionYes.get(person));
			break;
		}
	}
	
	public void selectPeakSeason(String peakSeason, int person) throws InterruptedException
	{
		switch (peakSeason)
		{
		case "Yes":
			clickSafelyJS(peakSeasonOptionYes.get(person));
			break;

		case "No":
			clickSafelyJS(peakSeasonOptionNo.get(person));
			break;	
		default:
			clickSafelyJS(peakSeasonOptionYes.get(person));
			break;
		}
	}	
	
	public boolean isRCSectionDisplayed() throws Exception
	{
		return isNotDisplayed(rcSection);
	}
	
}
