package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import modules.DriverExtension;
import pageobjects.BaseClass;

public class SH_RetirementProtection extends BaseClass{

	public SH_RetirementProtection(WebDriver driver) {
		super(driver);
	}
	@FindBy(how= How.XPATH, using="//div[text()='Retirement Protection']/following::button[text()='3']")
	public static List <WebElement> percentage3;

	@FindBy(how= How.XPATH, using="//div[text()='Retirement Protection']/following::button[text()='4']")
	public static List <WebElement> percentage4;	
	
	
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Retirement Protection')]/following::lightning-formatted-number")
	public static List <WebElement> rpValue;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Retirement Protection')]/preceding::lightning-icon[contains(@class,'check')]")
	public static WebElement rpCheck;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Retirement Protection')]/preceding::button[contains(@class,'missionControlWarning')]")
	public static WebElement rpWarning;	
	
	
	public void selectPercentage(String percentage, int person) throws InterruptedException
	{		
		DriverExtension.scrollToBottom(driver);	
		switch (percentage)
		{
		case "3":
			clickSafelyJS(percentage3.get(person));
			break;

		case "4":
			clickSafelyJS(percentage4.get(person));
			break;
		}
	}
	
	
	
	public String getRPValue(int person)
	{
		String value = getTextSafely(rpValue.get(person)).substring(1);    	
		return value;
	}
	
	public boolean isRPStatusSuccessful()
	{		  	
		return rpCheck.isDisplayed();
	}
	
	public boolean isRPStatusWarning()
	{		  	
		return rpWarning.isDisplayed();
	}

}
