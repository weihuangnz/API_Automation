package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import pageobjects.BaseClass;

public class SH_ProgressiveCare extends BaseClass{

	public SH_ProgressiveCare(WebDriver driver) {
		super(driver);
	}
	
	//@FindBy(how= How.NAME, using="inputBenefitAmount")
	@FindBy(how= How.XPATH, using="//div[text()='Progressive Care']/following::input[@name='inputBenefitAmount']")
	public static List <WebElement> sumAssured;	
	
	@FindBy(how= How.XPATH, using="//div[text()='Progressive Care']/following::legend[contains(text(), 'Indexation')]/following::button[1]")
	public static List <WebElement> indexed;

	@FindBy(how= How.XPATH, using="//div[text()='Progressive Care']/following::legend[contains(text(), 'Indexation')]/following::button[2]")
	public static List <WebElement> level;
	
	@FindBy(how= How.XPATH, using="//div[text()='Progressive Care']/following::button[text()='Rate for Age']")
	public static List <WebElement> rateForAge;

	@FindBy(how= How.XPATH, using="//div[text()='Progressive Care']/following::button[text()='10 Year']")
	public static List <WebElement> tenYear;

	@FindBy(how= How.XPATH, using="//div[text()='Progressive Care']/following::button[text()='To Age 65']")
	public static List <WebElement> toAge65;
	
	@FindBy(how= How.XPATH, using="//div[text()='Progressive Care']/following::span[text()='Add More']/parent::button[1]")
	public static List <WebElement> addSPCLoading;
	
	@FindBy(how= How.XPATH, using="//div[text()='Progressive Care']/following::span[text()='Show/Hide Loading']/parent::a")
	public static WebElement showHideSPCLoading;
	
	@FindBy(how= How.XPATH, using="//div[text()='Progressive Care']/following::span[text()='Add TPD Condition']/parent::a")
	public static WebElement addTPDCondition;
	
	@FindBy(how= How.XPATH, using="//div[text()='Progressive Care']/following::input[@name='inputLoading']")
	public static List <WebElement> spcLoadingPercentage;
	
	@FindBy(how= How.XPATH, using="//div[text()='Progressive Care']/following::input[@name='inputLoadingTerm']")
	public static List <WebElement> spcLoadingTerm;

	@FindBy(how= How.XPATH, using="//div[text()='Progressive Care']/following::input[@name='inputPerMille']")
	public static List <WebElement> spcPerMille;
	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[text()='Progressive Care']/following::lightning-formatted-number")
	public static List <WebElement> spcValue;
	
	@FindBy(how= How.XPATH, using="//div[text()='Progressive Care']/preceding::lightning-icon[contains(@class,'check')]")
	public static WebElement spcCheck;
	
	@FindBy(how= How.XPATH, using="//div[text()='Progressive Care']/preceding::button[contains(@class,'missionControlWarning')]")
	public static WebElement spcWarning;	
	
	public void enterSumAssured(String amount, int person) throws InterruptedException
	{
		if(amount!=null)
		{			
			sendKeysSafely(sumAssured.get(person),amount);			
		}
	}
	
	public void selectIndexation(String indexation, int person) throws InterruptedException
	{
		switch (indexation)
		{
		case "Indexed":
			clickSafely(indexed.get(person));    	
			break;

		case "Level":    		
			clickSafely(level.get(person));
			break;
		}
	}
	
	public void selectPremiumOption(String PremiumOption, int person) throws InterruptedException
	{
		switch (PremiumOption)
		{
		case "Rate For Age":
			clickSafelyJS(rateForAge.get(person));
			break;

		case "10 Year":
			clickSafelyJS(tenYear.get(person));
			break;

		case "To Age 65":
			clickSafelyJS(toAge65.get(person));
			break;		
		}
	}
	
	public void enterLoadingPercentage(String percentage, int person) throws InterruptedException
	{
		if(percentage!=null)
		{
			clickSafely(addSPCLoading.get(person));
			clickSafely(showHideSPCLoading);	
			scrollIntoView(spcLoadingPercentage.get(person));	
			sendKeysSafely(spcLoadingPercentage.get(person),percentage);			
		}
	}
	
	public void addTPDCondition(int person) throws InterruptedException
	{
		clickSafely(addSPCLoading.get(person));
		clickSafely(addTPDCondition);	
	}
	
	public void enterLoadingTerm(String term, int person) throws InterruptedException
	{
		if(term!=null)
		{
			sendKeysSafely(spcLoadingTerm.get(person),term);
		}
		else
		{
			sendKeysSafely(spcLoadingTerm.get(person),"");
		}
	}

	public void enterPerMille(String mille, int person) throws InterruptedException
	{
		if(mille!=null)
		{
			sendKeysSafely(spcPerMille.get(person),mille);
			sendEnterKeysSafely(spcPerMille.get(person));
		}
	}
	
	public String getSPCValue(int person)
	{
		String value = getTextSafely(spcValue.get(person)).substring(1);    	
		return value;
	}
	
	public boolean isSPCStatusSuccessful()
	{		  	
		return spcCheck.isDisplayed();
	}
	
	public boolean isSPCStatusWarning()
	{		  	
		return spcWarning.isDisplayed();
	}

}
