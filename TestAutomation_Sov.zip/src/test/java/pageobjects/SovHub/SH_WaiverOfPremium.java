package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import pageobjects.BaseClass;

public class SH_WaiverOfPremium extends BaseClass{

	public SH_WaiverOfPremium(WebDriver driver) {
		super(driver);
	}

	//Waiting Period (Weeks) 
	@FindBy(how= How.XPATH, using="//div[text()='Waiver of Premium']/following::legend[contains(text(), 'Waiting Period')]/following::button[text()='2']")
	public static List <WebElement> wp2;
	
	@FindBy(how= How.XPATH, using="//div[text()='Waiver of Premium']/following::legend[contains(text(), 'Waiting Period')]/following::button[text()='4']")
	public static List <WebElement> wp4;
	
	@FindBy(how= How.XPATH, using="//div[text()='Waiver of Premium']/following::legend[contains(text(), 'Waiting Period')]/following::button[text()='8']")
	public static List <WebElement> wp8;
	
	@FindBy(how= How.XPATH, using="//div[text()='Waiver of Premium']/following::legend[contains(text(), 'Waiting Period')]/following::button[text()='13']")
	public static List <WebElement> wp13;
	
	@FindBy(how= How.XPATH, using="//div[text()='Waiver of Premium']/following::legend[contains(text(), 'Waiting Period')]/following::button[text()='26']")
	public static List <WebElement> wp26;
	
	@FindBy(how= How.XPATH, using="//div[text()='Waiver of Premium']/following::legend[contains(text(), 'Waiting Period')]/following::button[text()='52']")
	public static List <WebElement> wp52;
	
	@FindBy(how= How.XPATH, using="//div[text()='Waiver of Premium']/following::legend[contains(text(), 'Waiting Period')]/following::button[text()='104']")
	public static List <WebElement> wp104;

	@FindBy(how= How.XPATH, using="//div[contains(text(),'Waiver of Premium')]/following::div[contains(@class,'quote-benefit')]")
	public static List <WebElement> wopLoading;

	@FindBy(how= How.XPATH, using="//div[contains(text(),'Waiver of Premium')]/following::input[@name='inputLoading']")
	public static List <WebElement> wopLoadingPercentage;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Waiver of Premium')]/following::lightning-formatted-number")
	public static List <WebElement> wopValue;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Waiver of Premium')]/following::span[text()='Add More']/parent::button[1]")
	public static List <WebElement> addWoPLoading;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Waiver of Premium')]/following::span[text()='Show/Hide Loading']/parent::a")
	public static WebElement showHideWoPLoading;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Waiver of Premium')]/preceding::lightning-icon[contains(@class,'check')]")
	public static WebElement wopCheck;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Waiver of Premium')]/preceding::button[contains(@class,'missionControlWarning')]")
	public static WebElement wopWarning;	

	public void selectWaitingPeriod(String period, int person) throws InterruptedException
	{
		switch (period)
		{
		case "2":
			clickSafely(wp2.get(person));    	
			break;
			
		case "4":
			clickSafely(wp4.get(person));    	
			break;

		case "8":    		
			clickSafely(wp8.get(person));
			break;
			
		case "13":    		
			clickSafely(wp13.get(person));
			break;
			
		case "26":    		
			clickSafely(wp26.get(person));
			break;
			
		case "52":    		
			clickSafely(wp52.get(person));
			break;
			
		case "104":    		
			clickSafely(wp104.get(person));
			break;
		}
	}
	
	public void enterWOPLoadingPercentage(String percentage, int person) throws InterruptedException
	{
		if(percentage!=null)
		{
			clickSafely(addWoPLoading.get(person));
			clickSafely(showHideWoPLoading);	
			scrollIntoView(wopLoadingPercentage.get(person));	
			sendKeysSafely(wopLoadingPercentage.get(person),percentage);			
		}
	}	
	
	public String getWOPValue(int person)
	{
		String value = getTextSafely(wopValue.get(person));
		if(value.length()>0)
		{
			value = value.substring(1); 
		} 
		return value;
	}
	
	public boolean isWoPStatusSuccessful()
	{		  	
		return wopCheck.isDisplayed();
	}
	
	public boolean isWoPStatusWarning()
	{		  	
		return wopWarning.isDisplayed();
	}

}
