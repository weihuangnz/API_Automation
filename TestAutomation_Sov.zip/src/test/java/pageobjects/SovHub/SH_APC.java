package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import pageobjects.BaseClass;

public class SH_APC extends BaseClass{

	public SH_APC(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Accelerated Progressive Care')]/following::input[@name='inputBenefitAmount']")
	public static List <WebElement> sumAssured;	
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Progressive Care']/following::button[text()='Rate for Age']")
	public static List <WebElement> rateForAge;

	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Progressive Care']/following::button[text()='10 Year']")
	public static List <WebElement> tenYear;

	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Progressive Care']/following::button[text()='To Age 65']")
	public static List <WebElement> toAge65;
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Progressive Care']/following::input[@name='inputLoading']")
	public static List <WebElement> loading;

	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Progressive Care']/following::input[@name='inputLoadingTerm']")
	public static List <WebElement> loadingTerm;

	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Progressive Care']/following::input[@name='inputPerMille']")
	public static List <WebElement> perMille;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Accelerated Progressive Care')]/following::span[text()='Show/Hide Loading']/parent::a")
	public static WebElement showHideLoading;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Accelerated Progressive Care')]/following::span[text()='Add TPD Condition']/parent::a")
	public static WebElement showHideTPDCondition;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Accelerated Progressive Care')]/following::span[text()='Add More']/parent::button[1]")
	public static List <WebElement> addLoading;	

	@FindBy(how= How.XPATH, using="//div[@class='slds-float--left ']")
	public static List <WebElement> expandLoading;
	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[contains(text(),'Accelerated Progressive Care')]/following::lightning-formatted-number")
	public static List <WebElement> apcValue;
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Progressive Care']")
	public static WebElement apcSection;	
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Progressive Care']/following::lightning-primitive-icon")
	public static List<WebElement> apcAddMore;
	
	@FindBy(how=How.XPATH, using="//div[text()='Accelerated Progressive Care']/following::span[text()='Remove Benefit']")
	public static List<WebElement> apcRemoveBenefit;
	
	public void enterSumAssured(String amount, int person) throws InterruptedException
	{
		if(amount!=null)
		{			
			sendKeysSafely(sumAssured.get(person),amount);			
		}
	}
	
	public void selectPremiumOption(String PremiumOption, int person) throws InterruptedException
	{
		switch (PremiumOption)
		{
		case "Rate For Age":
			clickSafelyJS(rateForAge.get(person));
			break;

		case "10 Year":
			clickSafelyJS(tenYear.get(person));
			break;

		case "To Age 65":
			clickSafelyJS(toAge65.get(person));
			break;		
		}
	}
	
	public void enterLoading(String percentage, int person) throws InterruptedException
	{
		if(percentage!=null)
		{
			clickSafely(addLoading.get(person));
			clickSafely(showHideLoading);			
			sendKeysSafely(loading.get(person),percentage);			
		}
	}

	public void addTPDCondition(int person) throws InterruptedException
	{
		clickSafely(addLoading.get(person));
		clickSafely(showHideTPDCondition);	
	}
	
	public void enterLoadingTerm(String term, int person) throws InterruptedException
	{
		if(term!=null)
		{
			sendKeysSafely(loadingTerm.get(person),term);
		}
		else
		{
			sendKeysSafely(loadingTerm.get(person),"");
		}
	}

	public void enterPerMille(String mille, int person) throws InterruptedException
	{
		if(mille!=null)
		{
			sendKeysSafely(perMille.get(person),mille);
			sendEnterKeysSafely(perMille.get(person));
		}
	}
	
	public String getAPCValue(int person)
	{
		String value = getTextSafely(apcValue.get(person)).substring(1);    	
		return value;
	}

	public boolean isAPCSectionDisplayed()
	{
		return isNotDisplayed(apcSection);		
	}
	
	public void removeAPC(int person) throws InterruptedException
	{
		clickSafely(apcAddMore.get(0));
		clickSafely(apcRemoveBenefit.get(0));
		
	}
}
