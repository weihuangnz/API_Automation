package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import pageobjects.BaseClass;

public class SH_AccidentalInjuryCover extends BaseClass{

	public SH_AccidentalInjuryCover(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(how= How.XPATH, using="//div[text()='Accidental Injury Cover']/following::legend[contains(text(), 'Sum Assured Frequency')]/following::button[2]")
	public static List <WebElement> monthly;
	
	@FindBy(how= How.XPATH, using="//div[text()='Accidental Injury Cover']/following::legend[contains(text(), 'Sum Assured Frequency')]/following::button[1]")
	public static List <WebElement> annually;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Accidental Injury Cover')]/following::input[@name='inputBenefitAmount']")
	public static List <WebElement> sumAssured;	
	
	@FindBy(how= How.XPATH, using="//div[text()='Accidental Injury Cover']/following::legend[contains(text(), 'Indexation')]/following::button[1]")
	public static List <WebElement> indexed;

	@FindBy(how= How.XPATH, using="//div[text()='Accidental Injury Cover']/following::legend[contains(text(), 'Indexation')]/following::button[2]")
	public static List <WebElement> level;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Accidental Injury Cover')]/following::span[text()='Add More']/parent::button[1]")
	public static List <WebElement> addLoading;	
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Accidental Injury Cover')]/following::span[text()='Show/Hide Loading']/parent::a")
	public static WebElement showHideLoading;	
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Accidental Injury Cover')]/following::lightning-formatted-number")
	public static List <WebElement> aicValue;
	
	public void selectSumAssuredFrequency(String frequency, int person) throws InterruptedException
	{
		switch (frequency)
		{
		case "Annually":
			clickSafely(annually.get(person));    	
			break;

		case "Monthly":    		
			clickSafely(monthly.get(person));
			break;
		}
	}
	
	public void enterSumAssured(String amount, int person) throws InterruptedException
	{
		if(amount!=null)
		{			
			sendKeysSafely(sumAssured.get(person),amount);			
		}
	}
	
	public void selectIndexation(String indexation, int person) throws InterruptedException
	{
		switch (indexation)
		{
		case "Indexed":
			clickSafely(indexed.get(person));    	
			break;

		case "Level":    		
			clickSafely(level.get(person));
			break;
		}
	}	
	
	
	public String getAICValue(int person)
	{
		String value = getTextSafely(aicValue.get(person));    
		if(value.length()>0)
		{
			value = value.substring(1); 
		} 
		return value;
	}

}
