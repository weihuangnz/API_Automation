package pageobjects.SovHub;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import modules.DriverExtension;
import pageobjects.BaseClass;

public class SH_HomePage extends BaseClass{
	
    public SH_HomePage(WebDriver driver)
    {
        super(driver);
    }
    
    
    @FindBy(how= How.XPATH, using="//a[contains(@href,'pre-assessment')]")
    public static WebElement preAssessmentBtn;
    
    @FindBy(how= How.XPATH, using="//a[contains(@href,'quote-builder')]")
    public static WebElement quoteBuilderBtn;
    
    @FindBy(how= How.XPATH, using="//*[@title='Home']")
    public static WebElement homeButton;
    
    @FindBy(how= How.XPATH, using="//img[@class='profile-icon']")
    public static WebElement profileName;
    
    @FindBy(how= How.XPATH, using="//a[@class='profileName']")
    public static WebElement tempProdProfileName;

    @FindBy(how= How.XPATH, using="//a[@title='Logout']")
    public static WebElement logoutButton;  
    
    @FindBy(how= How.XPATH, using="//h2[@class='pipeline']")
    public static WebElement pipelineHeader;  
    
    @FindBy(how= How.XPATH, using="//table[@data-aura-class='uiVirtualDataTable']")
    public static WebElement pipelineTable; 
    
    @FindBy(how= How.XPATH, using="//div[@class='QBTitle']")
    public static WebElement quoteBuilderTitle;     
    
    
    public void clickPreAssessment() throws InterruptedException
    {
    	//DriverExtension.waitforElementThenClick(driver, preAssessmentBtn);
    	clickSafely(preAssessmentBtn);
    }
    
    public void clickQuoteBuilder() throws InterruptedException
    {
//    	clickSafely(quoteBuilderBtn);  	    	
    	clickSafelyJS(quoteBuilderBtn);  	
    	skipLoadingAnimation();
    	if(!isQuoteBuilderPageDisplayed())
    	{
    		clickSafelyJS(quoteBuilderBtn);  	    	
        	skipLoadingAnimation();
    	}
    }
    
    public void clickHome() throws InterruptedException
    {
    	clickSafely(homeButton);
    }
    
    
    public void clickLogout() throws InterruptedException
    {
    	clickSafely(logoutButton);
    }
    
    public void expandMenu() throws InterruptedException
    {
    	clickSafely(profileName);
    }
    
    public void expandProdProfileMenu() throws InterruptedException
    {
    	clickSafely(tempProdProfileName);
    }
    
    public String checkPipelineHeaderText()
    {
    	String pipelineText = pipelineHeader.getText();
    	return pipelineText;
    }
    
    public boolean isQuoteBuilderPageDisplayed()
    {
    	boolean status=false;
    	String headerText=getTextSafely(quoteBuilderTitle);
    	if(headerText.contains("QUOTE BUILDER"))
    	{
    		status=true;
    	}
    	return status;
    }
    

}
