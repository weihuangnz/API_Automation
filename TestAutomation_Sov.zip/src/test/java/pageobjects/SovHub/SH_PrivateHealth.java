package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import modules.DriverExtension;
import pageobjects.BaseClass;

public class SH_PrivateHealth extends BaseClass{

	public SH_PrivateHealth(WebDriver driver) {
		super(driver);
	}

	@FindBy(how= How.XPATH, using="//div[text()='Private Health Cover']/following::button[text()='$0']")
	public static List <WebElement> hcExcess0;
	
	@FindBy(how= How.XPATH, using="//div[text()='Private Health Cover']/following::button[text()='$250']")
	public static List <WebElement> hcExcess250;
	
	@FindBy(how= How.XPATH, using="//div[text()='Private Health Cover']/following::button[text()='$500']")
	public static List <WebElement> hcExcess500;
	
	@FindBy(how= How.XPATH, using="//div[text()='Private Health Cover']/following::button[text()='$750']")
	public static List <WebElement> hcExcess750;
	
	@FindBy(how= How.XPATH, using="//div[text()='Private Health Cover']/following::button[text()='$1000']")
	public static List <WebElement> hcExcess1000;
	
	@FindBy(how= How.XPATH, using="//div[text()='Private Health Cover']/following::button[text()='$2000']")
	public static List <WebElement> hcExcess2000;
	
	@FindBy(how= How.XPATH, using="//div[text()='Private Health Cover']/following::button[text()='$4000']")
	public static List <WebElement> hcExcess4000;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Private Health Cover')]/following::span[text()='Add More']/parent::button[1]")
	public static List <WebElement> addHCLoading;	

	@FindBy(how= How.XPATH, using="//div[contains(text(),'Private Health Cover')]/following::input[@name='inputLoading']")
	public static List <WebElement> healthCoverPercentage;
	
	@FindBy(how= How.XPATH, using="//div[text()='Private Health Plus']/following::button[text()='$0']")
	public static List <WebElement> hpExcess0;
	
	@FindBy(how= How.XPATH, using="//div[text()='Private Health Plus']/following::button[text()='$250']")
	public static List <WebElement> hpExcess250;
	
	@FindBy(how= How.XPATH, using="(//span[text()='Show/Hide Loading']/parent::a)[1]")
	public static WebElement showHideHCLoading;	
	
	@FindBy(how= How.XPATH, using="(//span[text()='Show/Hide Loading']/parent::a)[2]")
	public static WebElement showHideHPLoading;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Private Health Plus')]/following::span[text()='Add More']/parent::button[1]")
	public static List <WebElement> addHPLoading;	

	@FindBy(how= How.XPATH, using="//div[contains(text(),'Private Health Plus')]/following::input[@name='inputLoading']")
	public static List <WebElement> healthPlusPercentage;
	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[text()='Private Health Cover']/following::lightning-formatted-number[1]")
	public static List <WebElement> healthCoverValue;
	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[text()='Private Health Plus']/following::lightning-formatted-number[1]")
	public static List <WebElement> healthPlusValue;	
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Private Health Cover')]/preceding::lightning-icon[contains(@class,'check')]")
	public static List<WebElement> phCheck;
	
	//@FindBy(how= How.XPATH, using="//div[contains(text(),'Private Health Cover')]/preceding::lightning-icon[contains(@class,'warning')]")
	@FindBy(how=How.XPATH, using="//div[contains(text(),'Private Health Cover')]/preceding::button[contains(@class,'Warning')]")
	public static List<WebElement> phWarning;
	
	@FindBy(how=How.XPATH, using="//div[text()='Health Waiver of Premium']/following::legend[text()='Waiting Period in Weeks']/following::button[text()='8']")
	private static List <WebElement> hwWaitingPeriod8;
	
	@FindBy(how=How.XPATH, using="//div[text()='Health Waiver of Premium']/following::legend[text()='Waiting Period in Weeks']/following::button[text()='13']")
	private static List <WebElement> hwWaitingPeriod13;	
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'HEALTH WAIVER OF PREMIUM')]/following::span[text()='Add More']/parent::button[1]")
	private static List <WebElement> addHWLoading;	
	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[text()='Health Waiver of Premium']/following::lightning-formatted-number[1]")
	public static List <WebElement> healthWaiverValue;	
	
	public void selectHealthCoverExcess(String excessValue, int person) throws InterruptedException
	{
		switch (excessValue)
		{
		case "$0":
			clickSafely(hcExcess0.get(person));    	
			break;

		case "$250":    		
			clickSafely(hcExcess250.get(person));
			break;
			
		case "$500":    		
			clickSafely(hcExcess500.get(person));
			break;
			
		case "$750":    		
			clickSafely(hcExcess750.get(person));
			break;
			
		case "$1000":    		
			clickSafely(hcExcess1000.get(person));
			break;
			
		case "$2000":    		
			clickSafely(hcExcess2000.get(person));
			break;
			
		case "$4000":    		
			clickSafely(hcExcess4000.get(person));
			break;
		}		
	}
	
	public void selectHealthPlusExcess(String excessValue, int person) throws InterruptedException
	{
		switch (excessValue)
		{
		case "$0":
			scrollIntoView(hpExcess0.get(person));
			clickSafely(hpExcess0.get(person));    	
			break;

		case "$250": 
			scrollIntoView(hpExcess250.get(person));
			clickSafely(hpExcess250.get(person));
			break;			
		
		}		
	}
	
	public void enterHCLoadingPercentage(String percentage, int person) throws InterruptedException
	{
		if(percentage!=null)
		{
			clickSafely(addHCLoading.get(person));
			clickSafely(showHideHCLoading);
			scrollIntoView(healthCoverPercentage.get(person));			
			sendKeysSafely(healthCoverPercentage.get(person),percentage);			
		}
	}
	
	public void enterHPLoadingPercentage(String percentage, int person) throws InterruptedException
	{
		if(percentage!=null)
		{
			scrollIntoView(addHPLoading.get(person));
			clickSafely(addHPLoading.get(person));
			clickSafely(showHideHPLoading);
			scrollIntoView(healthPlusPercentage.get(person));			
			sendKeysSafely(healthPlusPercentage.get(person),percentage);			
		}
	}
	
	public String getHealthCoverValue(int person)
	{
		String value = getTextSafely(healthCoverValue.get(person)).substring(1);    	
		return value;
	}
	
	public String getHealthPlusValue(int person)
	{
		String value = getTextSafely(healthPlusValue.get(person)).substring(1);    	
		return value;
	}
	
	public boolean isHCStatusSuccessful()
	{		  	
		return phCheck.get(0).isDisplayed();
	}
	
	public boolean isHCStatusWarning()
	{		  	
		return phWarning.get(0).isDisplayed();
	}
	
	public boolean isHPStatusSuccessful()
	{		 
		
		return phCheck.get(1).isDisplayed();

	}
	//if multiple person?
	public boolean isHPStatusWarning()
	{		 
		//When only health plus has warning
		if(phWarning.size() == 1)
		{
			return phWarning.get(0).isDisplayed();
		}
		else//When both health cover and health plus have warnings
		{
			return phWarning.get(1).isDisplayed();
		}
	}			
	
	//0 means "8" weeks waiting period
	// 1 means "13" weeks waiting period
	public void selectHealthWaiverWaitingPeriod(String waitingPeriod, int person) throws InterruptedException{
		switch(waitingPeriod)
		{
			case "8":
				clickSafely(hwWaitingPeriod8.get(person));
				break;
			case "13":
				clickSafely(hwWaitingPeriod13.get(person));
				break;
			default:
				clickSafely(hwWaitingPeriod8.get(person));
				break;
		}
		
	}
	
	public String getHealthWaiverValue(int person)
	{
		String value = getTextSafely(healthWaiverValue.get(person)).substring(1);    	
		return value;
	}
	
	public boolean isHWStatusSuccessful()
	{		 
		
		return phCheck.get(phCheck.size() -1).isDisplayed();
	}
	
	public boolean isHWStatusWarning()
	{	
		return phWarning.get(phWarning.size() -1).isDisplayed();
	}
		
	
}
