package pageobjects.SovHub.eApps;

import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

import modules.DriverExtension;
import pageobjects.BaseClass;

public class SH_eAppPersonalDetails extends BaseClass {

	public SH_eAppPersonalDetails(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(how= How.NAME, using="selectedTitleValue")
	public static List <Select> selectedTitleValue;
	
	@FindBy(how= How.NAME, using="firstname")
	public static List <WebElement> firstName;
	
	@FindBy(how= How.NAME, using="middleName")
	public static List <WebElement> middle_Name;
	
	@FindBy(how= How.NAME, using="LastName")
	public static List <WebElement> lastName;
	
	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'Gender')]/following::button[1]")
	public static List <WebElement> genderYes;

	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'Gender')]/following::button[2]")
	public static List <WebElement> genderNo;
	
	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'Smoked')]/following::button[1]")
	public static List <WebElement> smokedYes;

	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'Smoked')]/following::button[2]")
	public static List <WebElement> smokedNo;
	
	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'previously known')]/following::button[1]")
	public static List <WebElement> anotherNameYes;

	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'previously known')]/following::button[2]")
	public static List <WebElement> anotherNameNo;
	
	@FindBy(how= How.NAME, using="PersonalDetailIndustry")
	public static List <Select> industry;
	
	@FindBy(how= How.NAME, using="PersonalDetailLanguage")
	public static List <Select> preferredLanguage;
	
	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'Policy Owner')]/following::button[1]")
	public static List <WebElement> policyOwnerYes;

	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'Policy Owner')]/following::button[2]")
	public static List <WebElement> policyOwnerNo;
	
	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'Self-employed')]/following::button[1]")
	public static List <WebElement> selfEmployedYes;

	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'Self-employed')]/following::button[2]")
	public static List <WebElement> selfEmployedNo;
	
	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'Business Owner')]/following::button[1]")
	public static List <WebElement> businessOwnerYes;

	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'Business Owner')]/following::button[2]")
	public static List <WebElement> businessOwnerNo;
	
	@FindBy(how= How.XPATH, using="//button[@title='Next Section']")
	public static WebElement nextSectionBtn;	
	
	
	public void selectTitle(String title, int person)
	{
		selectedTitleValue.get(person).selectByVisibleText(title);
	}
	
	public void enterFirstNameLastName(String personFirstName, String personLastName, int person) throws InterruptedException
	{	
		skipLoadingAnimation();
		sendKeysSafely(firstName.get(person),personFirstName);
		sendKeysSafely(lastName.get(person),personLastName);
	}
	
	public void selectIndustry(String industryText, int person)
	{
		industry.get(person).selectByVisibleText(industryText);
	}
	
	public void selectPreferredLanguage(String language, int person)
	{
		preferredLanguage.get(person).selectByVisibleText(language);
	}
	
	//Check all disabled elements above
	public Boolean isDisabled(WebElement element)
	{
		return DriverExtension.isAttributePresent(element, "disabled");
	}
	
	public void selectKnownByAnotherName(String anotherName, int person) throws InterruptedException
	{
		switch (anotherName)
		{
		case "Yes":
			clickSafely(anotherNameYes.get(person));			
			break;

		case "No":
			clickSafely(anotherNameNo.get(person));			
			break;
		}
	}
	
	public void selectPolicyOwner(String policyOwner, int person) throws InterruptedException
	{
		switch (policyOwner)
		{
		case "Yes":
			clickSafely(policyOwnerYes.get(person));			
			break;

		case "No":
			clickSafely(policyOwnerNo.get(person));			
			break;
		}
	}
	
	public void clickNextSectionButton()
	{
		nextSectionBtn.click();
	}
	

}
