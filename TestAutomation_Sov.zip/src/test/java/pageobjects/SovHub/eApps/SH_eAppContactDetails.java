package pageobjects.SovHub.eApps;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import modules.DriverExtension;
import pageobjects.BaseClass;

public class SH_eAppContactDetails extends BaseClass{
	
	public SH_eAppContactDetails(WebDriver driver) {
		super(driver);
	}
	
	
	@FindBy(how= How.NAME, using="HomeAddress")
	public static List <WebElement> homeAddress;
	
	@FindBy(how= How.NAME, using="MailingAddress")
	public static List <WebElement> mailingAddress;
	
	@FindBy(how= How.NAME, using="Mobile")
	public static List <WebElement> mobile;
	
	@FindBy(how= How.NAME, using="HomePhone")
	public static List <WebElement> homePhone;
	
	@FindBy(how= How.NAME, using="BusinessPhone")
	public static List <WebElement> businessPhone;

	@FindBy(how= How.NAME, using="EmailAddress")
	public static List <WebElement> emailAddress;
	
	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'contact you directly')]/following::button[1]")
	public static List <WebElement> contactDirectYes;

	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'contact you directly')]/following::button[2]")
	public static List <WebElement> contactDirectNo;
	
	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'Telephone Underwriting ')]/following::button[1]")
	public static List <WebElement> underwritingServiceYes;

	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'Telephone Underwriting ')]/following::button[2]")
	public static List <WebElement> underwritingServiceNo;
	
	@FindBy(how= How.XPATH, using="//button[@title='Next Section']")
	public static WebElement nextSectionBtn;	
	
	@FindBy(how= How.XPATH, using="//span[contains(text(), 'Same as Home Address')]/preceding::span[1]")
	public static List <WebElement> sameAsHomeAddressCheckBox;	
	
	@FindBy(how= How.XPATH, using="//span[contains(text(), 'find my address')]/preceding::span[1]")
	public static List <WebElement> cantfindHomeAddressCheckBox;	
	
	//Cannot find home address section
	@FindBy(how= How.NAME, using="HomeAddressStreet")
	public static List <WebElement> addressLine1;
	
	@FindBy(how= How.NAME, using="HomeAddressCity")
	public static List <WebElement> city;
	
	@FindBy(how= How.NAME, using="HomeAddressPostalCode")
	public static List <WebElement> postCode;
	
	//For now I am just selecting the first li 
	@FindBy(how= How.XPATH, using="(//ul[@role='listbox'])[2]/li[1]")
	public static List <WebElement> addressListBoxFirstItem;
	
	
	public void enterHomeAddress(String HomeAddress, int person) throws Exception
	{
		homeAddress.get(person).sendKeys(HomeAddress);
		DriverExtension.waitforElementThenClick(driver, addressListBoxFirstItem.get(person));
	}
	
	public void enterMailingAddress(String MailingAddress, int person)
	{
		mailingAddress.get(person).sendKeys(MailingAddress);
	}
	
	public void enterMobileNumber(String MobileNumber, int person)
	{
		mobile.get(person).sendKeys(MobileNumber);
	}
	
	public void enterHomeNumber(String HomeNumber, int person)
	{
		homePhone.get(person).sendKeys(HomeNumber);
	}
	
	public void enterBusinessNumber(String BusinessNumber, int person)
	{
		businessPhone.get(person).sendKeys(BusinessNumber);
	}
	
	public void enterEmailAddress(String Email, int person)
	{
		emailAddress.get(person).sendKeys(Email);
	}
	
	public void selectContactDirect(String direct, int person) throws InterruptedException
	{
		switch (direct)
		{
		case "Yes":
			clickSafely(contactDirectYes.get(person));			
			break;

		case "No":
			clickSafely(contactDirectNo.get(person));			
			break;
		}
	}
	
	public void selectTelephoneUnderwritingService(String service, int person) throws InterruptedException
	{
		switch (service)
		{
		case "Yes":
			clickSafely(underwritingServiceYes.get(person));			
			break;

		case "No":
			clickSafely(underwritingServiceNo.get(person));			
			break;
		}
	}
	
	public void selectSameAsHomeAddress(int person)
	{
		sameAsHomeAddressCheckBox.get(person).click();
	}
	
	public void selectCantFindHomeAddress(int person)
	{
		cantfindHomeAddressCheckBox.get(person).click();
	}
	
	public void clickNextSectionButton()
	{
		nextSectionBtn.click();
	}
	
	
	public void enterAddressLine1(String AddressLine1, int person)
	{
		addressLine1.get(person).sendKeys(AddressLine1);
	}
	
	public void enterCity(String City, int person)
	{
		city.get(person).sendKeys(City);
	}
	
	public void enterPostCode(String PostCode, int person)
	{
		postCode.get(person).sendKeys(PostCode);
	}
}
