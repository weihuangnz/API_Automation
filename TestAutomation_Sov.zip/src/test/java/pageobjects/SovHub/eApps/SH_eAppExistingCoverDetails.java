package pageobjects.SovHub.eApps;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

import enums.InsuranceTypeEnum;
import enums.OccupationClassEnum;
import modules.DriverExtension;
import pageobjects.BaseClass;

public class SH_eAppExistingCoverDetails extends BaseClass{

	public SH_eAppExistingCoverDetails(WebDriver driver) {
		super(driver);
		
	}
	
	@FindBy(how=How.XPATH, using="//span[contains(text(),'Existing Cover Details')]")
	public static WebElement existingCoverDetails;
	
	//this list of YesButtons includes "Yes/No" under Existing Cover Details"
	final static String txt="Do you have or are you currently applying for any other Life, Income protection, Trauma or Health Cover with Sovereign or any other company?";
	@FindBy(how=How.XPATH,using="//legend[text()='"+txt+"']/following-sibling::div[1]/div/button[text()='Yes']")
	public static List<WebElement> yesButtons;
	
	@FindBy(how=How.XPATH,using="//legend[text()='"+txt+"']/following-sibling::div[1]/div/button[text()='No']")
	public static List<WebElement> noButtons;
	
	@FindBy(how=How.XPATH,using="//select[@name='ExistingCoverInfomationBenefitName']")
	public static List<WebElement> typesOfInsurance;
	
	@FindBy(how=How.XPATH,using="//input[@name='SumAssured']")
	public static List<WebElement> sumAssureds;
	
	@FindBy(how=How.XPATH,using="//button[contains(text(),'Applied For')]")
	public static List<WebElement> appliedFors;
	
	@FindBy(how=How.XPATH,using="//button[contains(text(),'In Force')]")
	public static List<WebElement> inForces;
	
	//
	final static String text="To be replaced with this application?";
	
	@FindBy(how=How.XPATH,using="//legend[text()='"+text+"']/following-sibling::div/div/button[text()='Yes']")
	public static List<WebElement> yesToBeReplaced;
	
	@FindBy(how=How.XPATH,using="//legend[text()='"+text+"']/following-sibling::div/div/button[text()='No']")
	public static List<WebElement> noToBeRplaced;
	//
	
	
	@FindBy(how=How.XPATH,using="//select[@name='ExistingCoverInfomationCompany']")
	public static List<WebElement> companies;
	
	@FindBy(how=How.XPATH,using="//button[contains(text(),'OK')]")
	public static List<WebElement> oks;
	
	@FindBy(how=How.XPATH,using="//button[contains(text(),'CANCEL')]")
	public static List<WebElement> cancels;
	
	@FindBy(how=How.XPATH,using="//button[contains(text(),'ADD ANOTHER')]")
	public static WebElement addAnother;

	@FindBy(how=How.XPATH,using="//button[@title='Save']")
	public static WebElement saveBtn;
	
	@FindBy(how=How.XPATH,using="//button[text()='EDIT']")
	public static List<WebElement> EDITs;
	
	@FindBy(how=How.XPATH,using="//button[text()='REMOVE']")
	public static List<WebElement> REMOVEs;
	
	@FindBy(how=How.XPATH,using="//button[@title='Previous Section']")
	public static WebElement previousSectionBtn;
	
	@FindBy(how=How.XPATH,using="//button[@title='Next Section']")
	public static WebElement nextSectionBtn;
			
	public void clickAddAnother() throws InterruptedException
	{
		DriverExtension.scrollDown(driver);
		clickSafely(addAnother);
	}
	
	public void clickExistingCoverDetails() throws InterruptedException
	{
		clickSafely(existingCoverDetails);
	}
	
	public boolean selectIfExistingCover(String option) throws InterruptedException
	{
			boolean isEnabled=false;
			switch(option.toLowerCase()) {
			case "yes":
				clickSafely(yesButtons.get(0));
				isEnabled=yesButtons.get(0).isEnabled()&&noButtons.get(0).isEnabled();
				break;
			case "no":
				clickSafely(noButtons.get(0));
				isEnabled=yesButtons.get(0).isEnabled()&&noButtons.get(0).isEnabled();
				break;
			default:
				break;
			 }
			return isEnabled;
	}
	
	//insuranceTypeText:1, 2, 3, 4 ,5
	/*
	 * 	InsuranceType1("Life Cover"),
		InsuranceType2("Income Protection"),
		InsuranceType3("Trauma"),
		InsuranceType4("Total Permanent Disablement"),
		InsuranceType5("Life Cover");
	 */
	public void selectTypeOfInsurance(String insuranceTypeText,int coverIndex) throws InterruptedException
	{
			String insuranceTypeTranslated = null;
			switch(insuranceTypeText)
			{
			case "1":
				insuranceTypeTranslated = InsuranceTypeEnum.InsuranceType1.toString();
				break;

			case "2":
				insuranceTypeTranslated = InsuranceTypeEnum.InsuranceType2.toString();
				break;

			case "3":
				insuranceTypeTranslated = InsuranceTypeEnum.InsuranceType3.toString();
				break;

			case "4":
				insuranceTypeTranslated = InsuranceTypeEnum.InsuranceType4.toString();
				break;

			case "5":
				insuranceTypeTranslated = InsuranceTypeEnum.InsuranceType5.toString();
				break;
			}
			
			skipLoadingAnimation();
//			new Actions(driver).moveToElement(typesOfInsurance.get(coverIndex)).build().perform();
			DriverExtension.moveToElement(typesOfInsurance.get(coverIndex), driver);
			System.out.println("insuranceTypeTranslated: "+insuranceTypeTranslated);
			selectByText(typesOfInsurance.get(coverIndex), insuranceTypeTranslated);
			skipLoadingAnimation();
	}
	
	public void enterSumAssured(String sum, int coverIndex) throws InterruptedException
	{  	
		skipLoadingAnimation();
		clickSafely(sumAssureds.get(coverIndex));
		sendKeysSafely(sumAssureds.get(coverIndex),sum);		
		skipLoadingAnimation();
	}
	
	/*
	 * benefitStatus:1 appliedFors, 2 inForces
	 */
	public void selectBenefitsStatus(int benefitStatus,int coverIndex) throws InterruptedException
	{
		switch(benefitStatus)
		{
		case 1:
			clickSafely(appliedFors.get(coverIndex));
			break;
		case 2:
			clickSafely(inForces.get(coverIndex));
			break;
		}
	}
	
	/*
	 * To be replaced with this application:1 Yes, 2 No
	 */
	public void isReplacedWithThisApplication(int option,int coverIndex) throws InterruptedException
	{
		switch(option)
		{
		case 1:
			clickSafely(yesToBeReplaced.get(coverIndex));
			break;
		case 2:
			clickSafely(noToBeRplaced.get(coverIndex));
			break;
		}
	}
	
	/*
	 * 
	 * 
	 */
	public void selectCompany(String companyName,int coverIndex)
	{
		DriverExtension.moveToElement(companies.get(coverIndex), driver);
		System.out.println("company Name: "+companyName);
		selectByText(companies.get(coverIndex), companyName);
		skipLoadingAnimation();
	}
	
	public void clickOk(int coverIndex) throws InterruptedException
	{
		DriverExtension.moveToElement(oks.get(coverIndex), driver);
		clickSafely(oks.get(coverIndex));
		
	}
	
	public void clickCancel(int coverIndex) throws InterruptedException
	{
		DriverExtension.moveToElement(cancels.get(coverIndex), driver);
		clickSafely(cancels.get(coverIndex));
	}
	
	public void clickSave() throws InterruptedException
	{
		clickSafely(saveBtn);
	}
	
	public void clickEDIT(int coverIndex) throws InterruptedException
	{
		clickSafely(EDITs.get(coverIndex));
	}
	
	public void clickREMOVE(int coverIndex) throws InterruptedException
	{
		clickSafely(REMOVEs.get(coverIndex));
	}
	
	
	public void clickPreviousSection() throws InterruptedException
	{
		clickSafely(previousSectionBtn);
	}
	
	public void clickNextSection() throws InterruptedException
	{
		clickSafely(nextSectionBtn);
	}
	

}
