package pageobjects.SovHub.eApps;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;
import modules.DriverExtension;
import pageobjects.BaseClass;

public class SH_eAppPayerDetails extends BaseClass {
	
	public SH_eAppPayerDetails(WebDriver driver) {
		super(driver);
	}
		
	@FindBy(how= How.XPATH, using="//button[contains(text(), 'Life Assured')]")
	public static List <WebElement> lifeAssuredBtn;
	
	@FindBy(how= How.XPATH, using="//button[contains(text(), 'New Person')]")
	public static List <WebElement> newPersonBtn;
	
	@FindBy(how= How.NAME, using="AccountId")
	public static List <Select> selectPayer;
	
	@FindBy(how= How.NAME, using="PayerName")
	public static List <WebElement> payerName;
	
	@FindBy(how= How.XPATH, using="//label[text()='Select Product']/following::input[1]")
	public static List <WebElement> selectProductCheckBox;
	
	@FindBy(how= How.XPATH, using="//label[contains(text(), 'deduction day')]/following::input[1]")
	public static List <WebElement> firstDeductionDay;
	
	@FindBy(how= How.XPATH, using="//button[contains(text(), 'Direct Debit')]")
	public static List <WebElement> directDebitBtn;
	
	@FindBy(how= How.NAME, using="NameOnAccount")
	public static List <WebElement> nameOnAccount;
	
	@FindBy(how= How.NAME, using="AccountNumber1")
	public static List <WebElement> accountNumber1;
	
	@FindBy(how= How.NAME, using="AccountNumber2")
	public static List <WebElement> accountNumber2;
	
	@FindBy(how= How.NAME, using="AccountNumber3")
	public static List <WebElement> accountNumber3;
	
	@FindBy(how= How.NAME, using="AccountNumber4")
	public static List <WebElement> accountNumber4;
	
	@FindBy(how= How.XPATH, using="//button[contains(text(), 'Debit/Credit Card')]")
	public static List <WebElement> debitCreditCardBtn;
	
	@FindBy(how= How.NAME, using="SkipPayment")
	public static List <WebElement> skipPaymentChkBox;

	@FindBy(how= How.XPATH, using="//button[contains(text(), 'OK')]")
	public static List <WebElement> okBtn;
	
	@FindBy(how= How.XPATH, using="//button[@title='Next Section']")
	public static WebElement nextSectionBtn;	
	
	@FindBy(how= How.XPATH, using="//button[@title='AUTHORISE DIRECT DEBIT']")
	public static List <WebElement> authoriseDirectDebit;	
	
	@FindBy(how= How.NAME, using="accept")
	public static WebElement acceptCheckBox;
	
	@FindBy(how= How.XPATH, using="//h2[contains(text(), 'Disclosure')]")
	public static WebElement disclosureHeading;	
	
	
	public void selectLifeAssured(int person)
	{
		lifeAssuredBtn.get(person).click();
	}
	
	public void selectNewPerson(int person)
	{
		newPersonBtn.get(person).click();
	}
	
	public void selectPayer(String payer, int person)
	{
		selectPayer.get(person).selectByVisibleText(payer);
	}
	
	public void selectProduct(int person)
	{
		//might require more rework later on
		selectProductCheckBox.get(person).click();
	}
	
	public void enterPayerName(String payer, int person)
	{
		payerName.get(person).sendKeys(payer);
	}
	
	public void enterFirstDeductionDay(String date, int person)
	{
		firstDeductionDay.get(person).sendKeys(date);
	}
	
	public void clickDirectDebitPaymentMethod(int person)
	{
		//integration not hooked up yet
		directDebitBtn.get(person).click();
	}
	
	public void enterNameOnAccount(String name, int person)
	{
		nameOnAccount.get(person).sendKeys(name);
	}
	
	public void enterAccountNumber(String acc1, String acc2, String acc3, String acc4, int person)
	{
		accountNumber1.get(person).sendKeys(acc1);
		accountNumber2.get(person).sendKeys(acc2);
		accountNumber3.get(person).sendKeys(acc3);
		accountNumber4.get(person).sendKeys(acc4);
	}
	
	public void clickDebitCreditPaymentMethod(int person)
	{
		debitCreditCardBtn.get(person).click();
	}
	
	public void clickOk(int person)
	{
		okBtn.get(person).click();
	}
	
	public void skipAddingPaymentCheckBox(int person)
	{
		skipPaymentChkBox.get(person).click();
	}
	
	public void authoriseDirectDebit(int person) throws InterruptedException
	{
		authoriseDirectDebit.get(person).click();
		DriverExtension.waitforElement(driver, disclosureHeading);
		clickSafely(acceptCheckBox);
	}
	
}