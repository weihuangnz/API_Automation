package pageobjects.SovHub.eApps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import modules.DriverExtension;
import pageobjects.BaseClass;

public class SH_eAppWelcome extends BaseClass{

	public SH_eAppWelcome(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(how=How.XPATH,using="//span[@class='QBName uiOutputText']")
	public static WebElement QBName;

	@FindBy(how=How.XPATH,using="//div[@class='header cEAppWelcome']")
	public static WebElement headerEAppWelcome;
	
	@FindBy(how=How.XPATH,using="//div[@class='body cEAppWelcome']/p")
	public static WebElement passage;
	
	@FindBy(how=How.XPATH,using="//button[@title='Next']")
	public static WebElement Next;
		
	public String getQuoteBuilderNumber() {
		String message = null;
		DriverExtension.waitForElementToAppear(driver, QBName);
		if(QBName.isDisplayed())
		{
			message = QBName.getText();
		}
		return message;
	}
	
	public String getHeaderEAppWelcome() {
		String message = null;
		DriverExtension.waitForElementToAppear(driver, passage);
		if(passage.isDisplayed())
		{
			message = passage.getText();
		}
		return message;
	}
	
	public String getBodyEAppWelcome() {
		String message = null;
		DriverExtension.waitForElementToAppear(driver, QBName);
		if(QBName.isDisplayed())
		{
			message = QBName.getText();
		}
		return message;
	}
	
	public void clickNext() throws InterruptedException {
		clickSafely(Next);
	}
	
}
