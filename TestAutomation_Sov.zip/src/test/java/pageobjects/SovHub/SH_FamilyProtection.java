package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import pageobjects.BaseClass;

public class SH_FamilyProtection extends BaseClass{

	public SH_FamilyProtection(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(how= How.XPATH, using="//div[text()='Family Protection']/following::input[@name='inputBenefitAmount']")
	public static List <WebElement> sumAssured;
	
	@FindBy(how= How.XPATH, using="//div[text()='Family Protection']/following::input[@name='inputFixedTerm']")
	public static List <WebElement> paymentFixedTerm;
	
	@FindBy(how= How.XPATH, using="//div[text()='Family Protection']/following::input[@name='inputToAge']")
	public static List <WebElement> paymentToAge;
	
	@FindBy(how= How.XPATH, using="//div[text()='Family Protection']/following::legend[contains(text(), 'Indexation')]/following::button[1]")
	public static List <WebElement> indexed;

	@FindBy(how= How.XPATH, using="//div[text()='Family Protection']/following::legend[contains(text(), 'Indexation')]/following::button[2]")
	public static List <WebElement> level;
	
	@FindBy(how= How.XPATH, using="//div[text()='Family Protection']/following::button[text()='Rate for Age']")
	public static List <WebElement> rateForAge;

	@FindBy(how= How.XPATH, using="//div[text()='Family Protection']/following::button[text()='10 Year']")
	public static List <WebElement> tenYear;

	@FindBy(how= How.XPATH, using="//div[text()='Family Protection']/following::button[text()='To Age 65']")
	public static List <WebElement> toAge65;
	
	@FindBy(how= How.XPATH, using="//div[text()='Family Protection']/following::button[text()='Fixed Term']")
	public static List <WebElement> fixedTerm;
	
	@FindBy(how= How.XPATH, using="//div[text()='Family Protection']/following::button[text()='To Age']")
	public static List <WebElement> toAge;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Family Protection')]/following::span[text()='Add More']/parent::button[1]")
	public static List <WebElement> addFPLoading;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Family Protection')]/following::span[text()='Show/Hide Loading']/parent::a")
	public static WebElement showHideFPLoading;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Family Protection')]/following::input[@name='inputLoading']")
	public static List <WebElement> fpLoadingPercentage;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Family Protection')]/following::input[@name='inputLoadingTerm']")
	public static List <WebElement> fpLoadingTerm;

	@FindBy(how= How.XPATH, using="//div[contains(text(),'Family Protection')]/following::input[@name='inputPerMille']")
	public static List <WebElement> fpPerMille;
	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[contains(text(),'Family Protection')]/following::lightning-formatted-number")
	public static List <WebElement> fpValue;
	
	public void enterSumAssured(String amount, int person) throws InterruptedException
	{
		if(amount!=null)
		{			
			sendKeysSafely(sumAssured.get(person),amount);			
		}
	}
	
	public void selectPremiumOption(String PremiumOption, int person) throws InterruptedException
	{
		switch (PremiumOption)
		{
		case "Rate For Age":
			clickSafelyJS(rateForAge.get(person));
			break;

		case "10 Year":
			clickSafelyJS(tenYear.get(person));
			break;

		case "To Age 65":
			clickSafelyJS(toAge65.get(person));
			break;		
		}
	}
	
	public void selectIndexation(String indexation, int person) throws InterruptedException
	{
		switch (indexation)
		{
		case "Indexed":
			clickSafely(indexed.get(person));    	
			break;

		case "Level":    		
			clickSafely(level.get(person));
			break;
		}
	}
	
	public void selectPaymentOption(String option, int person) throws InterruptedException
	{
		switch (option)
		{
		case "Fixed Term":
			clickSafely(fixedTerm.get(person));    	
			break;

		case "To Age":    		
			clickSafely(toAge.get(person));
			break;
		}
	}
	
	public void enterLoadingPercentage(String percentage, int person) throws InterruptedException
	{
		if(percentage!=null)
		{
			clickSafely(addFPLoading.get(person));
			clickSafely(showHideFPLoading);	
			scrollIntoView(fpLoadingPercentage.get(person));	
			sendKeysSafely(fpLoadingPercentage.get(person),percentage);			
		}
	}
	
	public void enterLoadingTerm(String term, int person) throws InterruptedException
	{
		if(term!=null)
		{
			sendKeysSafely(fpLoadingTerm.get(person),term);
		}
		else
		{
			sendKeysSafely(fpLoadingTerm.get(person),"");
		}
	}
	
	public void enterPaymentTerm(String option,String payment, int person) throws InterruptedException
	{		
			switch (option)
			{
			case "Fixed Term":
				sendKeysSafely(paymentFixedTerm.get(person),payment);    	
				break;

			case "To Age":    		
				sendKeysSafely(paymentToAge.get(person),payment);
				break;
			}		
		
	}

	public void enterPerMille(String mille, int person) throws InterruptedException
	{
		if(mille!=null)
		{
			sendKeysSafely(fpPerMille.get(person),mille);
			sendEnterKeysSafely(fpPerMille.get(person));
		}
	}
	
	public String getFPBValue(int person)
	{
		String value = getTextSafely(fpValue.get(person));
		if(value.length()>0)
		{
			value = value.substring(1); 
		}
		return value;
	}


}
