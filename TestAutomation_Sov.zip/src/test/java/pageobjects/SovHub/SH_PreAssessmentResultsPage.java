package pageobjects.SovHub;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import modules.DriverExtension;
import pageobjects.BaseClass;

public class SH_PreAssessmentResultsPage extends BaseClass{
	
    public SH_PreAssessmentResultsPage(WebDriver driver)
    {
        super(driver);
    }
    
    @FindBy(how= How.XPATH, using="//div[contains(text(), 'Total Permanent Disablement')]/following::div[1]")
    public static WebElement totalPermanentDis;
    
    @FindBy(how= How.XPATH, using="//div[contains(text(), 'Disability Income 13 Weeks')]/following::div[1]")
    public static WebElement disabilityIncome13Weeks;
    
    @FindBy(how= How.XPATH, using="//div[contains(text(), 'Disability Income 4-13 Weeks')]/following::div[1]")
    public static WebElement disabilityIncome413Weeks;
    
    @FindBy(how= How.XPATH, using="//div[contains(text(), 'Living Assurance')]/following::div[1]")
    public static WebElement livingAssurance;
    
    @FindBy(how= How.XPATH, using="//div[contains(text(), 'Life')]/following::div[1]")
    public static WebElement lifeResult;
    
    @FindBy(how= How.XPATH, using="//div[contains(text(), 'Health Cover')]/following::div[1]")
    public static WebElement healthCover;
    
    @FindBy(how= How.XPATH, using="//div[contains(text(), 'Disability Income 2 Week')]/following::div[1]")
    public static WebElement disabilityIncome2Week;
    
    public String getTotalPermanentDis() throws InterruptedException
    {
    	DriverExtension.waitforElement(driver, totalPermanentDis);
    	return totalPermanentDis.getText();
    }
    
    public String getDisabilityIncome13Weeks()
    {
    	return disabilityIncome13Weeks.getText();
    }
    
    public String getDisabilityIncome413Weeks()
    {
    	return disabilityIncome413Weeks.getText();
    }
    
    public String getLivingAssurance()
    {
    	return livingAssurance.getText();
    }
    
    public String getLifeResult()
    {
    	return lifeResult.getText();
    }
    
    public String getHealthCover()
    {
    	return healthCover.getText();
    }
    
    public String getDisabilityIncome2Week()
    {
    	return disabilityIncome2Week.getText();
    }
}
