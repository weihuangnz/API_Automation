package pageobjects.SovHub;

import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import modules.DriverExtension;
import pageobjects.BaseClass;

public class SH_Pre_Assessment extends BaseClass{

    public SH_Pre_Assessment(WebDriver driver)
    {
        super(driver);
    }
    
    
    @FindBy(how= How.XPATH, using="//h1")
    public static List<WebElement> header;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'Female')]")
    public static WebElement genderFemale;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'Male')]")
    public static WebElement genderMale;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'Date of Birth?')]/following::input[1]")
    public static WebElement dateOfBirth;
    
    @FindBy(how= How.XPATH, using="//button[text()='PROCEED']")
    public static WebElement proceedButton;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'Yes')]")
    public static WebElement smokerYes;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'No')]")
    public static List<WebElement> smokerNo;
    
    @FindBy(how= How.XPATH, using="//input[@placeholder='Metres']")
    public static WebElement height;
    
    @FindBy(how= How.XPATH, using="//input[@placeholder='Kilograms']")
    public static WebElement weight;
    
    @FindBy(how= How.XPATH, using="//ul[@role='listbox']/div")
    public static List<WebElement> conditionDropDownList;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'name of your condition')]/following::input[1]")
    public static WebElement nameOfCondition;
    
    @FindBy(how= How.XPATH, using="//button[@title='search']")
    public static WebElement searchButton;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'condition still present')]/following::input[1]")
    public static WebElement conditionPresentYes;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'condition still present')]/following::input[2]")
    public static WebElement conditionPresentNo;
    
    @FindBy(how= How.XPATH, using="//button[text()='Assess']")
    public static WebElement assessButton;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'In the last 12 months have you smoked')]")
    public static WebElement smokedInLastYear;
    
    //Smoker Options
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'On average, how many cigarettes')]/following::input[1]")
    public static WebElement howManyCigarettesTextbox;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'On average, how many grams of loose tobacco')]/following::input[1]")
    public static WebElement howManyGramsTextbox;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'On average, how many cigars')]/following::input[1]")
    public static WebElement howManycigarsTextbox;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'Is your client currently undergoing treatment')]/following::input[1]")
    public static WebElement underGoingtreatmentYes;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'Is your client currently undergoing treatment')]/following::input[2]")
    public static WebElement underGoingtreatmentNo;
    
    @FindBy(how= How.XPATH, using="//input[@value='Breast Cancer']")
    public static WebElement breastCancerRadioBtn;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'Was this a relapse/recurrence of')]/following::input[1]")
    public static WebElement relapseYes;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'Was this a relapse/recurrence of')]/following::input[2]")
    public static WebElement relapseNo;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'Was this a relapse/recurrence of')]/following::input[3]")
    public static WebElement relapseDontKNow;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'Has the client had any complications')]/following::input[1]")
    public static WebElement complicationsYes;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'Has the client had any complications')]/following::input[2]")
    public static WebElement complicationsNo;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'Has the client had any complications')]/following::input[3]")
    public static WebElement complicationsDontKnow;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'Did the client have a low grade TNM')]/following::input[1]")
    public static WebElement lowGradeTNMYes;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'Did the client have a low grade TNM')]/following::input[2]")
    public static WebElement lowGradeTNMNo;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'Did the client have a low grade TNM')]/following::input[3]")
    public static WebElement lowGradeTNMDontKnow;
    
    @FindBy(how= How.XPATH, using="//input[@placeholder='Months']")
    public static WebElement remisionTime;
    
    
    
    public void selectGender(String Gender) throws InterruptedException
    {
    	
    	JavascriptExecutor exec = (JavascriptExecutor)driver;
    	
    	switch (Gender)
    	{
    	case "Female":
    		DriverExtension.waitforElement(driver, genderFemale);
    		exec.executeScript("arguments[0].click();", genderFemale);
    		break;
    		
    	case "Male":
    		DriverExtension.waitforElement(driver, genderMale);
    		exec.executeScript("arguments[0].click();", genderMale);
    		break;
    	}
    
    }
    
    public void enterDateOfBirth()
    {
    	dateOfBirth.sendKeys("07/05/1975");
    }
    
    public void clickProceed() throws InterruptedException
    {
    	clickSafely(proceedButton);
    	DriverExtension.skipLoadingNewAnimation(driver);
    }
      
    public void selectCondition(String Condition) throws InterruptedException
    {
    	DriverExtension.scrollIntoView(nameOfCondition, driver);
    	nameOfCondition.sendKeys(Condition);
    	nameOfCondition.sendKeys(Keys.TAB);
    	
    	Thread.sleep(1000);
    	
    	DriverExtension.waitforElementToBeClickable(driver, searchButton);
    	//DriverExtension.waitforElementThenClick(driver, searchButton);
    	
    	JavascriptExecutor exec = (JavascriptExecutor)driver;
    	exec.executeScript("arguments[0].click();", searchButton);
    	
    	 List<WebElement> allElements = conditionDropDownList;

    	 for (WebElement element: allElements) {

    	     try {
    	         if(element.getText().contains(Condition))
    	        {
    	        	 Thread.sleep(500);
    	             element.click();
    	             break;
    	         }
    	     } catch (NoSuchElementException e) {
    	         e.printStackTrace();
    	     }
    	 }
    }
    
    
    public void selectSmoker(String Smoker) throws InterruptedException
    {
    	Thread.sleep(2000);
    	JavascriptExecutor exec = (JavascriptExecutor)driver;
    	DriverExtension.waitforElementToBeClickable(driver, smokerYes);

    	switch (Smoker)
    	{
    	case "Yes":
    		System.out.println("YES");
    		exec.executeScript("arguments[0].click();", smokerYes);
    		
    		DriverExtension.waitforElementToBeClickable(driver, howManyCigarettesTextbox);
    		enterSmokerDetail();
    		break;
    		
    	case "No":
    		System.out.println("NO");
    		exec.executeScript("arguments[0].click();", smokerNo.get(1));
    		break;
    	}
    }
    
    public void enterSmokerDetail()
    {
    	howManyCigarettesTextbox.sendKeys("20");
    	howManyGramsTextbox.sendKeys("12");
    	howManycigarsTextbox.sendKeys("1");
    	
    }
    
    
    public void enterHeight(String Height)
    {
    	height.sendKeys(Height);
    }
    
    public void enterWeight(String Weight)
    {
    	weight.sendKeys(Weight);
    }
    
    public void conditionPresent(String ConditionPresent) throws InterruptedException
    {
    	JavascriptExecutor exec = (JavascriptExecutor)driver;
    	
    	switch (ConditionPresent)
    	{
    	case "Yes":
    		
    		System.out.println("BEFORE **********");
    		
    		DriverExtension.waitforElement(driver, conditionPresentYes);
    		
    		System.out.println("AFTER **********");
    		exec.executeScript("arguments[0].click();", conditionPresentYes);
    		break;
    		
    	case "No":
    		DriverExtension.waitforElement(driver, conditionPresentNo);
    		exec.executeScript("arguments[0].click();", conditionPresentNo);
    		break;
    	}
    }
    
    
    public void clickAssess() throws Exception
    {
    	try {
			DriverExtension.waitforElementThenClick(driver, assessButton);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	Thread.sleep(4000);
    }
    
    public String getHeaderText()
    {
    	String headerResult = header.get(1).getText();
    	return headerResult;
    }
    
    
    
    public void enterUndergoingtreatment(String Treatment) throws InterruptedException
    {
    	JavascriptExecutor exec = (JavascriptExecutor)driver;
    	DriverExtension.scrollToBottom(driver);
    	
    	switch (Treatment)
    	{
    	case "Yes":
    		DriverExtension.waitforElement(driver, underGoingtreatmentYes);
    		exec.executeScript("arguments[0].click();", underGoingtreatmentYes);
    		break;
    		
    	case "No":
    		DriverExtension.waitforElement(driver, underGoingtreatmentNo);
    		exec.executeScript("arguments[0].click();", underGoingtreatmentNo);
    		break;
    	}
    }
    
    public void selectCancerType(String CancerType) throws InterruptedException
    {
    	JavascriptExecutor exec = (JavascriptExecutor)driver;
    	
    	DriverExtension.scrollDown(driver);
    	
    	switch (CancerType)
    	{
    	case "Breast Cancer":
    		DriverExtension.waitforElement(driver, breastCancerRadioBtn);
    		exec.executeScript("arguments[0].click();", breastCancerRadioBtn);
    		break;
    		
    	}  	
    }
    
    public void selectRelapse(String Relapse) throws InterruptedException
    {
    	JavascriptExecutor exec = (JavascriptExecutor)driver;
    	
    	DriverExtension.scrollDown(driver);
    	
    	switch (Relapse)
    	{
    	case "Yes":
    		DriverExtension.waitforElement(driver, relapseYes);
    		exec.executeScript("arguments[0].click();", relapseYes);
    		break;
    		
    	case "No":
    		DriverExtension.waitforElement(driver, relapseNo);
    		exec.executeScript("arguments[0].click();", relapseNo);
    		break;
    		
    	case "Don't Know":
    		DriverExtension.waitforElement(driver, relapseDontKNow);
    		exec.executeScript("arguments[0].click();", relapseDontKNow);
    		break;
    	}
    }
    
    public void selectComplications(String Complications) throws InterruptedException
    {
    	JavascriptExecutor exec = (JavascriptExecutor)driver;
    	
    	DriverExtension.scrollDown(driver);
    	
    	switch (Complications)
    	{
    	case "Yes":
    		DriverExtension.waitforElement(driver, complicationsYes);
    		exec.executeScript("arguments[0].click();", complicationsYes);
    		break;
    		
    	case "No":
    		DriverExtension.waitforElement(driver, complicationsNo);
    		exec.executeScript("arguments[0].click();", complicationsNo);
    		break;
    		
    	case "Don't Know":
    		DriverExtension.waitforElement(driver, complicationsDontKnow);
    		exec.executeScript("arguments[0].click();", complicationsDontKnow);
    		break;
    	}
    }
    
    
    
    public void selectlowGradeTNM(String TNMClassifaction) throws InterruptedException
    {
    	JavascriptExecutor exec = (JavascriptExecutor)driver;
    	
    	DriverExtension.scrollDown(driver);
    	
    	switch (TNMClassifaction)
    	{
    	case "Yes":
    		DriverExtension.waitforElement(driver, lowGradeTNMYes);
    		exec.executeScript("arguments[0].click();", lowGradeTNMYes);
    		break;
    		
    	case "No":
    		DriverExtension.waitforElement(driver, lowGradeTNMNo);
    		exec.executeScript("arguments[0].click();", lowGradeTNMNo);
    		break;
    		
    	case "Don't Know":
    		DriverExtension.waitforElement(driver, lowGradeTNMDontKnow);
    		exec.executeScript("arguments[0].click();", lowGradeTNMDontKnow);
    		break;
    	}
    }
    

    public void enterRemissionTime(String RemissionTime) throws InterruptedException
    {
    	DriverExtension.scrollDown(driver);
    	DriverExtension.waitforElement(driver, remisionTime);
    	remisionTime.sendKeys(RemissionTime);
    	remisionTime.sendKeys(Keys.ENTER);
    }
    
    
    
	
}
