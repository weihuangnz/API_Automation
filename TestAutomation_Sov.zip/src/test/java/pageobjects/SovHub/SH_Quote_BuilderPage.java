package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import enums.OccupationClassEnum;
import modules.DriverExtension;
import pageobjects.BaseClass;

public class SH_Quote_BuilderPage extends BaseClass{

	public SH_Quote_BuilderPage(WebDriver driver)
	{
		super(driver);
	}

	//Person Information

	@FindBy(how= How.NAME, using="firstname")
	public static List <WebElement> firstName;

	@FindBy(how= How.NAME, using="lastname")
	public static List <WebElement> lastName;

	@FindBy(how= How.XPATH, using="//button[text()='Male']")
	public static List <WebElement> genderMale;

	@FindBy(how= How.XPATH, using="//button[text()='Female']")
	public static List <WebElement> genderFemale;

	@FindBy(how= How.NAME, using="Age")
	public static List <WebElement> age;

	@FindBy(how= How.NAME, using="DOB")
	public static List <WebElement> dateOfBirth;
	
	@FindBy(how= How.NAME, using="salary")
	public static List <WebElement> salary;

	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'Smoked in the past year')]/following::button[1]")
	public static List <WebElement> smokedYes;

	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'Smoked in the past year')]/following::button[2]")
	public static List <WebElement> smokedNo;

	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'Self-employed')]/following::button[1]")
	public static List <WebElement> selfEmployedYes;

	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'Self-employed')]/following::button[2]")
	public static List <WebElement> selfEmployedNo;

	@FindBy(how= How.XPATH, using="//input[@type='search']")
	public static List <WebElement> occupation;

	@FindBy(how= How.XPATH, using="//ul[@role='listbox']")
	public static WebElement occupationList;

	@FindBy(how= How.XPATH, using="//div[@class='ScenarioAmount']/following::lightning-primitive-icon[1]")
	public static List <WebElement> scenarioSettingsIcons;

	@FindBy(how= How.XPATH, using="//span[contains(text(), 'SETTINGS')]")
	public static List <WebElement> scenarioSettings;


	//Life

	@FindBy(how= How.NAME, using="inputBenefitAmount")
	public static List <WebElement> sumAssured;

	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'Indexation')]/following::button[1]")
	public static List <WebElement> indexed;

	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'Indexation')]/following::button[2]")
	public static List <WebElement> level;

	@FindBy(how= How.NAME, using="inputLoading")
	public static List <WebElement> loading;

	@FindBy(how= How.NAME, using="inputLoadingTerm")
	public static List <WebElement> loadingTerm;

	@FindBy(how= How.NAME, using="inputPerMille")
	public static List <WebElement> perMille;


	@FindBy(how= How.XPATH, using="//button[text()='Rate for Age']")
	public static List <WebElement> rateForAge;

	@FindBy(how= How.XPATH, using="//button[text()='10 Year']")
	public static List <WebElement> tenYear;

	@FindBy(how= How.XPATH, using="//button[text()='To Age 65']")
	public static List <WebElement> toAge65;

	@FindBy(how= How.XPATH, using="//button[text()='To Age 80']")
	public static List <WebElement> toAge80;

	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'Self-employed 3+')]/following::button[1]")
	public static List <WebElement> selfEmloyedYes;

	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'Self-employed 3+')]/following::button[2]")
	public static List <WebElement> selfEmloyedNo;

	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'Future Insurability')]/following::button[1]")
	public static List <WebElement> fIOptionYes;

	@FindBy(how= How.XPATH, using="//legend[contains(text(), 'Future Insurability')]/following::button[2]")
	public static List <WebElement> fIOptionNo;


	//Other

	@FindBy(how= How.XPATH, using="//button[text()='Calculate']")
	public static WebElement calculateBtn;

	@FindBy(how= How.XPATH, using="//button[text()='Save']")
	public static WebElement saveBtn;
	
	@FindBy(how= How.XPATH, using="//button[text()='SAVE ALL']")
	public static WebElement saveQuote;

	@FindBy(how= How.XPATH, using="//button[text()='ADD PERSON']")
	public static WebElement addPersonBtn;

	@FindBy(how= How.NAME, using="PaymentFrequenceSelect")
	public static WebElement paymentFrequency;	

	@FindBy(how= How.XPATH, using="//div[contains(text(),'Policy fees')]/following::lightning-formatted-number[1]")
	public static WebElement policyFees;

	@FindBy(how= How.XPATH, using="//span[@class='Summary uiOutputText']/following::lightning-formatted-number[1]")
	public static WebElement totalPremium;

	@FindBy(how= How.XPATH, using="//lightning-formatted-text[contains(text(),'Life Cover')]/following::lightning-formatted-number[1]")
	public static WebElement lifeCover;	
	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[text()='Life']/preceding::lightning-icon[contains(@class,'check')]")
	public static WebElement lifeCheck;
	
	@FindBy(how= How.XPATH, using="//div[text()='Life']/preceding::button[contains(@class,'missionControlWarning')]")
	public static WebElement lifeWarning;

	@FindBy(how= How.XPATH, using="//div[contains(text(),'Life')]/following::span[text()='Show/Hide Loading']/parent::a")
	public static WebElement showHideLifeLoading;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Life')]/following::span[text()='Add Accelerated Total Permanent Disablement']/parent::a")
	public static WebElement addATPD;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Life')]/following::span[text()='Add Accelerated Progressive Care']/parent::a")
	public static WebElement addAPC;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Life')]/following::span[text()='Add Accelerated Living Assurance']/parent::a")
	public static List <WebElement> addAccelLivingAssurance;
	
	//@FindBy(how= How.XPATH, using="//div[contains(text(),'Life')]/following::span[text()='Add Accelerated Essential Living Assurance']/parent::a")
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Life')]/following::span[text()='Add Accelerated Essential Living Assurance']/parent::a")
	public static List<WebElement> addAELA;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Life')]/following::span[text()='Add More']/parent::button[1]")
	public static List <WebElement> addLifeLoading;	

	@FindBy(how= How.XPATH, using="//div[@class='slds-float--left ']")
	public static List <WebElement> expandLoading;	

	@FindBy(how= How.XPATH, using="//div[@class='slds-notify_alert slds-theme_warning']")
	public static List <WebElement> messageAlert;
	
	@FindBy(how= How.XPATH, using="//div[@class='message']")
	public static List <WebElement> ineligibleBenefitText;
	
	@FindBy(how= How.XPATH, using="(//div[@class='message'])[2]")
	public static List <WebElement> ineligibleAdditionalBenefitText;	

	@FindBy(how= How.XPATH, using="(//div[@class='message'])[3]")
	public static List <WebElement> ineligibleThirdBenefitText;	
	
	@FindBy(how= How.XPATH, using="(//div[@class='message'])[4]")
	public static List <WebElement> ineligibleFourthBenefitText;	
	
	@FindBy(how= How.XPATH, using="(//div[@class='message'])[5]")
	public static List <WebElement> ineligibleFifthBenefitText;
	
	@FindBy(how= How.XPATH, using="//div[contains(@class,'errorMessage')]")
	public static List <WebElement> messageText; 

	@FindBy(how= How.XPATH, using="(//div[contains(@class,'errorMessage')])[2]")
	public static List <WebElement> additionalMessageText; 
	
	@FindBy(how= How.XPATH, using="(//div[contains(@class,'errorMessage')])[3]")
	public static List <WebElement> thirdMessageText;
	
	@FindBy(how= How.XPATH, using="(//div[contains(@class,'errorMessage')])[4]")
	public static List <WebElement> fourthMessageText;	

	@FindBy(how= How.XPATH, using="(//div[contains(@class,'errorMessage')])[5]")
	public static List <WebElement> fifthMessageText;
	
	@FindBy(how= How.XPATH, using="(//div[contains(@class,'errorMessage')])[6]")
	public static List <WebElement> sixthMessageText;
	
	@FindBy(how= How.XPATH, using="//div[contains(@class,'error-message')]")
	public static List <WebElement> fiErrorMessage; 	
	
	@FindBy(how= How.XPATH, using="//div[contains(@class,'error-message')]")
	public static List <WebElement> buyBackMessageText; 	
	
	@FindBy(how= How.XPATH, using="(//div[contains(@class,'error-message')])[2]")
	public static List <WebElement> secondBuyBackMessageText; 
	
	@FindBy(how= How.XPATH, using="//div[contains(@class,'error-message')]")
	public static List <WebElement> fiMessageText; 
	
	@FindBy(how= How.XPATH, using="//div[contains(@class,'error-message')]")
	public static List <WebElement> stMessageText; 

	//FI Option  
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[text()='Future Insurability']/following::lightning-formatted-number[1]")
	public static WebElement fiValue;
	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[text()='Future Insurability']/preceding::lightning-icon[contains(@class,'check')][1]")
	public static WebElement fiCheck;
	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[text()='Future Insurability']/preceding::button[contains(@class,'missionControlWarning')][1]")
	public static WebElement fiWarning;

	@FindBy(how= How.XPATH, using="//div[contains(text(),'Private Health Cover')]/following::span[contains(@class,'uiOutputText')]" )
	public static List<WebElement> ineligibleErrorMessage;
	//Waiver Of Premium  
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[text()='Waiver of Premium']/following::lightning-formatted-number[1]")
	public static WebElement wopValue;

	@FindBy(how=How.XPATH, using="//div[@class='slds-form-element__help']")
	public static WebElement inputErrorMessage;
	
	@FindBy(how=How.XPATH, using="//div[contains(text(),'Please select a value')]")
	public static List<WebElement> pleaseSelectMessage;
	
	@FindBy(how=How.XPATH, using="//div[contains(text(),'Please enter age')]")
	public static List<WebElement> ageMessage;
	
	@FindBy(how=How.XPATH, using="//button[contains(@class, 'viewPdf')]")
	public static WebElement viewPDF;
	
	@FindBy(how= How.XPATH, using="//div[text()='Life']")
	public static WebElement lifeCoverSection;
	
	@FindBy(how= How.XPATH, using="//button[text()='RENAME']")
	public static WebElement renameQuote;
	
	@FindBy(how= How.XPATH, using="//div[text()='Life']/following::button[contains(@class,'slds-button_icon-more')]")
	public static WebElement lifeMoreDetailsButton;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Life')]/following::span[text()='Remove Benefit']/parent::a")
	public static WebElement removeLifeBenefit;	
	
	//The Publish button from eAPP feature
	@FindBy(how= How.XPATH,using="//button[contains(text(),'PUBLISH')]")
	public static WebElement publishBtn;
			
	//The APPLY button from eApp feature
	@FindBy(how= How.XPATH,using="//button[contains(text(),'APPLY')]")
	public static WebElement applyBtn;	
		
	//The Confirm button of the msg box after clicking PUBLISH button from eApp feature
	@FindBy(how= How.XPATH,using="//button[contains(text(),'Confirm')]")
	public static WebElement confirmBtn;
	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[contains(text(),'Life Cover')]/following::legend[contains(text(),'Business Safeguard')]/following::button[text()='Yes']")
	public static WebElement bsLifeYes;
	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[contains(text(),'Life Cover')]/following::lightning-formatted-text[contains(text(),'Business Safeguard')]/following::lightning-formatted-number")
	public static WebElement bsLifeValue;	
	
	public String getPleaseSelectMessage() throws InterruptedException
	{
		String message = null;			
 		DriverExtension.waitForElementToAppear(driver,pleaseSelectMessage.get(0)); 
		DriverExtension.moveToElement(pleaseSelectMessage.get(0),driver);
		if(!pleaseSelectMessage.isEmpty()){
			message = getTextSafely(pleaseSelectMessage.get(0));
			return message;
		}else{
			return null;
		}
	}
	
	public String getAgeValidationMessage() throws InterruptedException
	{
		String message = null;			
		DriverExtension.waitForElementToAppear(driver,ageMessage.get(0)); 
		DriverExtension.moveToElement(ageMessage.get(0),driver);
		if(!ageMessage.isEmpty()){
			message = getTextSafely(ageMessage.get(0));
			return message;
		}else{
			return null;
		}
	}
	
	public void enterFirstNameLastName(String personFirstName, String personLastName, int person) throws InterruptedException
	{	
		skipLoadingAnimation();
		sendKeysSafely(firstName.get(person),personFirstName);
		sendKeysSafely(lastName.get(person),personLastName);
	}

	public void selectGender(String gender, int person) throws InterruptedException
	{
		switch (gender)
		{
		case "Female":
			clickSafelyJS(genderFemale.get(person));
			break;

		case "Male":
			clickSafelyJS(genderMale.get(person)); 
			break;
		}
	}

	public void enterAge(String personAge, int person) throws InterruptedException
	{
		sendKeysTraditional(age.get(person),personAge);
		//sendKeysSafely(age.get(person),personAge);		
		//clickSafely(dateOfBirth.get(person));
		skipLoadingAnimation();
	}


	public void selectSmoker(String smoker, int person) throws InterruptedException
	{	

		switch (smoker)
		{
		case "Yes":
			clickSafely(smokedYes.get(person));			
			break;

		case "No":
			clickSafely(smokedNo.get(person));			
			break;
		}
		skipLoadingAnimation();
	}

	public void selectSelfEmployed(String selfEmployed, int person) throws InterruptedException
	{

		DriverExtension.scrollToBottom(driver);		

		switch (selfEmployed)
		{
		case "Yes":
			clickSafelyJS(selfEmployedYes.get(person));
			break;

		case "No":
			clickSafelyJS(selfEmployedNo.get(person));
			break;
		}

	}


	public void selectfiOption(String fiOption, int person) throws InterruptedException
	{		
		DriverExtension.scrollToBottom(driver);		

		switch (fiOption)
		{
		case "Yes":
			clickSafelyJS(fIOptionYes.get(person));
			break;

		case "No":
			clickSafelyJS(fIOptionNo.get(person));
			break;
		}
	}


	public void enterSumAssured(String sum, int person) throws InterruptedException
	{  	
		skipLoadingAnimation();
	//	scrollIntoView(sumInsured.get(person));//added by Lina
		clickSafely(sumAssured.get(person));
		sendKeysSafely(sumAssured.get(person),sum);		
		skipLoadingAnimation();
	}


	public void selectIndexation(String indexation, int person) throws InterruptedException
	{
		switch (indexation)
		{
		case "Indexed":
			clickSafely(indexed.get(person));    	
			break;

		case "Level":    		
			clickSafely(level.get(person));
			break;
		}
	}

	public void selectSelfEmploymentTerm(String selfEmploymentTerm, int person) throws InterruptedException
	{		
		switch (selfEmploymentTerm)
		{
		case "Yes":
			clickSafely(selfEmloyedYes.get(person));
			break;

		case "No":
			clickSafely(selfEmloyedNo.get(person));
			break;
		}
	}


	public void enterLoading(String percentage, int person) throws InterruptedException
	{
		if(percentage!=null)
		{
			clickSafely(addLifeLoading.get(person));
			clickSafely(showHideLifeLoading);				
			sendKeysSafely(loading.get(person),percentage);			
		}
	}

	public void enterLoadingTerm(String term, int person) throws InterruptedException
	{
		if(term!=null)
		{
			sendKeysSafely(loadingTerm.get(person),term);
		}
		else
		{
			sendKeysSafely(loadingTerm.get(person),"");
		}
	}

	public void enterPerMille(String mille, int person) throws InterruptedException
	{
		if(mille!=null)
		{
			sendKeysSafely(perMille.get(person),mille);
			sendEnterKeysSafely(perMille.get(person));
		}
	}
	
	public void addATPD(int person) throws InterruptedException
	{		
			clickSafely(addLifeLoading.get(person));
			clickSafely(addATPD);				
	}
	
	public void addAPC(int person) throws InterruptedException
	{		
			clickSafely(addLifeLoading.get(person));
			clickSafely(addAPC);				
	}

	public void clickCalculate() throws InterruptedException
	{
		clickSafely(calculateBtn);		
		skipLoadingAnimation();
	}
	
	public void clickSaveQuote()
	{
		saveQuote.click();
		skipLoadingAnimation();
	}
	
	public void clickRenameQuote()
	{
		renameQuote.click();
	}

	public void clickViewPDF() throws InterruptedException
	{
		clickSafely(viewPDF);		
		skipLoadingAnimation();
	}

	public void clickSave() throws InterruptedException
	{
		clickSafely(saveBtn);
	}

	public void clickAddPerson() throws InterruptedException
	{
		clickSafely(addPersonBtn);
	}


	public void selectPremiumOption(String PremiumOption, int person) throws InterruptedException
	{
		switch (PremiumOption)
		{
		case "Rate For Age":
			clickSafelyJS(rateForAge.get(person));
			break;

		case "10 Year":
			clickSafelyJS(tenYear.get(person));
			break;

		case "To Age 65":
			clickSafelyJS(toAge65.get(person));
			break;

		case "To Age 80":
			clickSafelyJS(toAge80.get(person));
			break;
		}
	}

	public String getPolicyFees()
	{
		String fees = getTextSafely(policyFees).substring(1);    	
		return fees;
	}

	public String getTotalPremium() throws InterruptedException
	{	
		String premium = getTextSafely(totalPremium);  
		if(premium.length()<1)
		{
			clickCalculate();
		}
		if(premium.length()>0)
		{
			premium = premium.substring(1); 
		}
		return premium;
	}

	public String getLifeCover()
	{
		String life = getTextSafely(lifeCover);
		if(life.length()>0)
		{
			life = life.substring(1); 
		}
		return life;
	}
	
	public String getBSLifeValue(int person)
	{
		String value = getTextSafely(bsLifeValue);
		if(value.length()>0)
		{
			value = value.substring(1); 
		}
		return value;
	}

	public String getFIOptionValue()
	{
		String fiOptionValue = getTextSafely(fiValue).substring(1);    	
		return fiOptionValue;
	}		
	
	public boolean isFIStatusSuccessful()
	{		  	
		return fiCheck.isDisplayed();
	}
	
	public boolean isFIStatusWarning()
	{		  	
		return fiWarning.isDisplayed();
	}
	
	public String getIneligibleBenefitText() throws InterruptedException
	{
		String message = null;			
		DriverExtension.waitForElementToAppear(driver,ineligibleBenefitText.get(0)); 
		DriverExtension.moveToElement(ineligibleBenefitText.get(0),driver);
		if(!ineligibleBenefitText.isEmpty()){
			message = getTextSafely(ineligibleBenefitText.get(0));
			return message;
		}else{
			return null;
		}
	}
	
	public String getIneligibleAdditionalBenefitText() throws InterruptedException
	{
		String message = null;			
		DriverExtension.waitForElementToAppear(driver,ineligibleAdditionalBenefitText.get(0)); 
		DriverExtension.moveToElement(ineligibleAdditionalBenefitText.get(0),driver);
		if(!ineligibleAdditionalBenefitText.isEmpty()){
			message = getTextSafely(ineligibleAdditionalBenefitText.get(0));
			return message;
		}else{
			return null;
		}
	}

	public String getIneligibleThirdBenefitText() throws InterruptedException
	{
		String message = null;			
		DriverExtension.waitForElementToAppear(driver,ineligibleThirdBenefitText.get(0)); 
		DriverExtension.moveToElement(ineligibleThirdBenefitText.get(0),driver);
		if(!ineligibleThirdBenefitText.isEmpty()){
			message = getTextSafely(ineligibleThirdBenefitText.get(0));
			return message;
		}else{
			return null;
		}
	}
	
	public String getIneligibleFourthBenefitText() throws InterruptedException
	{
		String message = null;			
		DriverExtension.waitForElementToAppear(driver,ineligibleFourthBenefitText.get(0)); 
		DriverExtension.moveToElement(ineligibleFourthBenefitText.get(0),driver);
		if(!ineligibleFourthBenefitText.isEmpty()){
			message = getTextSafely(ineligibleFourthBenefitText.get(0));
			return message;
		}else{
			return null;
		}
	}
	
	public String getIneligibleFifthBenefitText() throws InterruptedException
	{
		String message = null;			
		DriverExtension.waitForElementToAppear(driver,ineligibleFifthBenefitText.get(0)); 
		DriverExtension.moveToElement(ineligibleFifthBenefitText.get(0),driver);
		if(!ineligibleFifthBenefitText.isEmpty()){
			message = getTextSafely(ineligibleFifthBenefitText.get(0));
			return message;
		}else{
			return null;
		}
		
	}
	public String getValidationMessageText() throws InterruptedException
	{
		String message = null;			
		DriverExtension.waitForElementToAppear(driver,messageText.get(0)); 
		DriverExtension.moveToElement(messageText.get(0),driver);
		if(!messageText.isEmpty()){
			message = getTextSafely(messageText.get(0));
			return message;
		}else{
			return null;
		}
	}
	
	public String getFIIneligibleMessageText() throws InterruptedException
	{
		String message = null;			
		DriverExtension.waitForElementToAppear(driver,fiMessageText.get(0)); 
		DriverExtension.moveToElement(fiMessageText.get(0),driver);
		if(!fiMessageText.isEmpty()){
			message = getTextSafely(fiMessageText.get(0));
			return message;
		}else{
			return null;
		}
	}
	
	public String getSTErrorMessageText() throws InterruptedException
	{
		String message = null;			
		DriverExtension.waitForElementToAppear(driver,stMessageText.get(0)); 
		DriverExtension.moveToElement(stMessageText.get(0),driver);
		if(!stMessageText.isEmpty()){
			message = getTextSafely(stMessageText.get(0));
			return message;
		}else{
			return null;
		}
	}

	public String getAdditionalValidationMessageText() throws InterruptedException
	{
		String message = null;					
		DriverExtension.waitForElementToAppear(driver,additionalMessageText.get(0));  
		DriverExtension.moveToElement(additionalMessageText.get(0),driver);
		if(!additionalMessageText.isEmpty()){
			message = getTextSafely(additionalMessageText.get(0));
			return message;
		}else{
			return null;
		}
		
	}
	
	public String getThirdValidationMessageText() throws InterruptedException
	{
		String message = null;					
		DriverExtension.waitForElementToAppear(driver,thirdMessageText.get(0));  
		DriverExtension.moveToElement(thirdMessageText.get(0),driver);
		if(!thirdMessageText.isEmpty()){
			message = getTextSafely(thirdMessageText.get(0));
			return message;
		}else{
			return null;
		}
		
	}
	
	public String getFourthValidationMessageText() throws InterruptedException
	{		
		String message = null;					
		DriverExtension.waitForElementToAppear(driver,fourthMessageText.get(0));  
		DriverExtension.moveToElement(fourthMessageText.get(0),driver);
		if(!fourthMessageText.isEmpty()){
			message = getTextSafely(fourthMessageText.get(0));
			return message;
		}else{
			return null;
		}
	}
	
	public String getFifthValidationMessageText() throws InterruptedException
	{		
		String message = null;					
		DriverExtension.waitForElementToAppear(driver,fifthMessageText.get(0));  
		DriverExtension.moveToElement(fifthMessageText.get(0),driver);
		if(!fifthMessageText.isEmpty()){
			message = getTextSafely(fifthMessageText.get(0));
			return message;
		}else{
			return null;
		}
	}
	
	public String getSixthValidationMessageText() throws InterruptedException
	{		
		String message = null;					
		DriverExtension.waitForElementToAppear(driver,sixthMessageText.get(0));  
		DriverExtension.moveToElement(sixthMessageText.get(0),driver);
		if(!sixthMessageText.isEmpty()){
			message = getTextSafely(sixthMessageText.get(0));
			return message;
		}else{
			return null;
		}
	}
	public String getBuyBackMessageText() throws InterruptedException
	{
		String message = null;					
		DriverExtension.waitForElementToAppear(driver,buyBackMessageText.get(0));  
		DriverExtension.moveToElement(buyBackMessageText.get(0),driver);
		if(!buyBackMessageText.isEmpty()){
			message = getTextSafely(buyBackMessageText.get(0));
			return message;
		}else{
			return null;
		}
		
	}
	
	public String getSecondBuyBackMessageText() throws InterruptedException
	{
		String message = null;					
		DriverExtension.waitForElementToAppear(driver,secondBuyBackMessageText.get(0));  
		DriverExtension.moveToElement(secondBuyBackMessageText.get(0),driver);
		if(!secondBuyBackMessageText.isEmpty()){
			message = getTextSafely(secondBuyBackMessageText.get(0));
			return message;
		}else{
			return null;
		}
		
	}
	
	public String getFIValidationMessageText() throws InterruptedException
	{
		String message = null;					
		DriverExtension.waitForElementToAppear(driver,fiErrorMessage.get(0));  
		DriverExtension.moveToElement(fiErrorMessage.get(0),driver);
		if(!fiErrorMessage.isEmpty()){
			message = getTextSafely(fiErrorMessage.get(0));
			return message;
		}else{
			return null;
		}
		
	}

	public void selectOccupation(String occupationText, int person) throws InterruptedException
	{
		String occupationTranslated = null;
		DriverExtension.scrollToBottom(driver);

		switch(occupationText)
		{
		case "1":
			occupationTranslated = OccupationClassEnum.OccupationClass1.toString();
			break;

		case "2":
			occupationTranslated = OccupationClassEnum.OccupationClass2.toString();
			break;

		case "3":
			occupationTranslated = OccupationClassEnum.OccupationClass3.toString();
			break;

		case "4":
			occupationTranslated = OccupationClassEnum.OccupationClass4.toString();
			break;

		case "5":
			occupationTranslated = OccupationClassEnum.OccupationClass5.toString();
			break;
			
		case "9":
			occupationTranslated = OccupationClassEnum.OccupationClass9.toString();
			break;
		case "U":
			occupationTranslated = OccupationClassEnum.OccupationClass9.toString();
			break;
		}
		skipLoadingAnimation();
		sendKeysTraditional(occupation.get(person),occupationTranslated);
				
		Thread.sleep(3000);		
		List<WebElement> options = occupationList.findElements(By.xpath("//span[@data-aura-class='uiOutputText']"));
		for (WebElement option : options)
		{
			if (option.getText().equals(occupationTranslated))
			{
				option.click(); 
				break;
			}
		}      
		skipLoadingAnimation();

	}

	public void selectScenarioSettings(int person) throws InterruptedException
	{ 	
		clickSafelyJS(scenarioSettingsIcons.get(person));    	
		clickSafelyJS(scenarioSettings.get(person));    
		skipLoadingAnimation();//sometimes it has spinner
	} 
	
	public boolean isLifeStatusSuccessful()
	{		  	
		return lifeCheck.isDisplayed();
	}
	
	public boolean isLifeStatusWarning()
	{		  	
		return lifeWarning.isDisplayed();
	}

	public String getHCIneligibleErrorMessage()
	{
		skipLoadingAnimation();
		return ineligibleErrorMessage.get(0).getText();
		
	}
	
	public String getHPIneligibleErrorMessage()
	{
		skipLoadingAnimation();
		return ineligibleErrorMessage.get(1).getText();
		
	}

	public String getHWIneligibleErrorMessage()
	{
		skipLoadingAnimation();
		int count = ineligibleErrorMessage.size();
		return ineligibleErrorMessage.get(count-1).getText();
		
	}
	public String getInputErrorMessage() throws InterruptedException
	{
		scrollIntoView(inputErrorMessage);
		return inputErrorMessage.getText();
	}
	
	public void addAccelLivingAssurance(int person) throws InterruptedException
	{
		clickSafely(addLifeLoading.get(person));
		clickSafely(addAccelLivingAssurance.get(person));
		
	}
	
	public void addAELA(int person) throws InterruptedException
	{
		clickSafely(addLifeLoading.get(person));
		clickSafely(addAELA.get(person));
	}
	
	public boolean isAccelLivingAssuranceDisabled(int person) throws InterruptedException
	{
		clickSafely(addLifeLoading.get(person));		
		return Boolean.parseBoolean(addAccelLivingAssurance.get(person).getAttribute("aria-disabled"));	
	}
	
	public boolean isAELADisabled(int person) throws InterruptedException
	{
		clickSafely(addLifeLoading.get(person));		
		return Boolean.parseBoolean(addAELA.get(person).getAttribute("aria-disabled"));
		
	}
	
	public boolean isAPCDisabled(int person) throws InterruptedException
	{
		clickSafely(addLifeLoading.get(person));
		return Boolean.parseBoolean(addAPC.getAttribute("aria-disabled"));	
	}
	
	public void enterSalary(String salaryAmount, int person) throws InterruptedException
	{
		skipLoadingAnimation();
		sendKeysSafely(salary.get(person),salaryAmount);
	} 
	
	public boolean isATPDDisabled() throws InterruptedException
	{
		clickSafely(addLifeLoading.get(0));
		return Boolean.parseBoolean(getAttributeSafely(addATPD,"aria-disabled"));	
	}
	
	public boolean isLifeSectionDisplayed() throws Exception
	{
		return isNotDisplayed(lifeCoverSection);
	}
	
	public boolean isAddPersonDisplayed() throws Exception
	{
		return isNotDisplayed(addPersonBtn);
	}
	
	public void removeLifeBenefit() throws InterruptedException
	{
		clickSafely(lifeMoreDetailsButton);
		clickSafely(removeLifeBenefit);
	}
	
	public void clickPublish() throws InterruptedException
	{
		clickSafely(publishBtn);		
		skipLoadingAnimation();
	}
	
	public void clickApply() throws InterruptedException
	{
		clickSafely(applyBtn);		
		skipLoadingAnimation();
	}
	
	//The Confirm button of the msg box after clicking PUBLISH button from eApp feature
	public void clickConfirm() throws InterruptedException
	{
		clickSafely(confirmBtn);		
		skipLoadingAnimation();
	}
	
	public void addBSLife() throws InterruptedException
	{		
		clickSafelyJS(bsLifeYes);		
	}
}
