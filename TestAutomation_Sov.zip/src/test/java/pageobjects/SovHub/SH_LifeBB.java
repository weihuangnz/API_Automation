package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import pageobjects.BaseClass;

public class SH_LifeBB extends BaseClass{

	public SH_LifeBB(WebDriver driver) {
		super(driver);
	}
	

	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[contains(text(),'Accelerated Living Assurance')]/following::lightning-formatted-text[contains(text(),'Life Buy-Back')]/following::lightning-formatted-number")
	public static List <WebElement> aclaLifeBBValue;
	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[contains(text(),'Accelerated Essential Living Assurance')]/following::lightning-formatted-text[contains(text(),'Life Buy-Back')]/following::lightning-formatted-number")
	public static List <WebElement> aelaLifeBBValue;
		
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Life Buy-Back')]/preceding::lightning-icon[contains(@class,'check')]")
	public static WebElement lifeBBCheck;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Life Buy-Back')]/preceding::button[contains(@class,'missionControlWarning')]")
	public static WebElement lifeBBWarning;	
	
	
	public String getACLALifeBBValue(int person)
	{
		String value = getTextSafely(aclaLifeBBValue.get(person));    
		if(value.length()>0)
		{
			value = value.substring(1); 
		}
		return value;
	}
	
	public String getAELALifeBBValue(int person)
	{
		String value = getTextSafely(aelaLifeBBValue.get(person));    	
		if(value.length()>0)
		{
			value = value.substring(1); 
		}
		return value;
	}
	
	public boolean isLifeBBStatusSuccessful()
	{		  	
		return lifeBBCheck.isDisplayed();
	}
	
	public boolean isLifeBBStatusWarning()
	{		  	
		return lifeBBWarning.isDisplayed();
	}
	
}
