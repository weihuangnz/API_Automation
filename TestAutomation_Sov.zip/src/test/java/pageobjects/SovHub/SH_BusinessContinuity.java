package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import modules.DriverExtension;
import pageobjects.BaseClass;

public class SH_BusinessContinuity extends BaseClass{

	public SH_BusinessContinuity(WebDriver driver) {
		super(driver);
	}
	
	//@FindBy(how= How.NAME, using="inputBenefitAmount")
		@FindBy(how=How.XPATH, using="//div[text()='Business Continuity']/following::button[text()='Annually']")
		public static List<WebElement> annuallyFrequency;
		
		@FindBy(how=How.XPATH, using="//div[text()='Business Continuity']/following::button[text()='Monthly']")
		public static List<WebElement> monthlyFrequency;
		
		@FindBy(how= How.XPATH, using="//div[text()='Business Continuity']/following::input[@name='inputBenefitAmount']")
		public static List <WebElement> sumAssured;
		
		@FindBy(how=How.XPATH, using="//div[text()='Business Continuity']/following::button[text()='Indexed']")
		public static List<WebElement> Indexation_Indexed;
		
		@FindBy(how=How.XPATH, using="//div[text()='Business Continuity']/following::button[text()='Level']")
		public static List<WebElement> Indexation_Level;
		
		@FindBy(how=How.XPATH, using="//div[text()='Business Continuity']/following::button[text()='Agreed Value']")
		public static List<WebElement> BenefitType_AgreedValue;
		
		@FindBy(how=How.XPATH, using="//div[text()='Business Continuity']/following::button[text()='Indemnity']")
		public static List<WebElement> BenefitType_Indemnity;
		
		@FindBy(how= How.XPATH, using="//div[text()='Business Continuity']/following::legend[contains(text(), 'Payment Period')]/following::button[1]")
		public static List <WebElement> sixMonth;

		@FindBy(how= How.XPATH, using="//div[text()='Business Continuity']/following::legend[contains(text(), 'Payment Period')]/following::button[2]")
		public static List <WebElement> oneYear;
		
		@FindBy(how= How.XPATH, using="//div[text()='Business Continuity']/following::legend[contains(text(), 'Payment Period')]/following::button[3]")
		public static List <WebElement> twoYear;
		
		@FindBy(how= How.XPATH, using="//div[text()='Business Continuity']/following::legend[contains(text(), 'Waiting Period in Weeks')]/following::button[1]")
		public static List <WebElement> waitingPeriod4;
		
		@FindBy(how= How.XPATH, using="//div[text()='Business Continuity']/following::legend[contains(text(), 'Waiting Period in Weeks')]/following::button[2]")
		public static List <WebElement> waitingPeriod8;
		
		@FindBy(how= How.XPATH, using="//div[text()='Business Continuity']/following::legend[contains(text(), 'Waiting Period in Weeks')]/following::button[3]")
		public static List <WebElement> waitingPeriod13;
		
		@FindBy(how= How.XPATH, using="//div[text()='Business Continuity']/following::legend[contains(text(), 'Partial Disablement')]/following::button[1]")
		public static List <WebElement> partialDisablementOptionYes;

		@FindBy(how= How.XPATH, using="//div[text()='Business Continuity']/following::legend[contains(text(), 'Partial Disablement')]/following::button[2]")
		public static List <WebElement> partialDisablementOptionNo;
		
		@FindBy(how= How.XPATH, using="(//div[text()='Business Continuity']/following::span[text()='Add More']/parent::button[1])[1]")
		public static List <WebElement> addLoading_BC;
		
		@FindBy(how= How.XPATH, using="(//div[text()='Business Continuity']/following::span[text()='Add More']/parent::button[1])[2]")
		public static List <WebElement> addLoading_WoP;
		
		@FindBy(how= How.XPATH, using="(//div[text()='Business Continuity']/following::span[text()='Show/Hide Loading']/parent::a)[1]")
		public static WebElement showHideLoading_BC;
		
		@FindBy(how= How.XPATH, using="(//div[text()='Business Continuity']/following::span[text()='Show/Hide Loading']/parent::a)[2]")
		public static WebElement showHideLoading_WoP;
		
		@FindBy(how= How.XPATH, using="(//div[text()='Business Continuity']/following::input[@name='inputLoading'])[1]")
		public static List <WebElement> loadingPercentage_BC;
		
		@FindBy(how= How.XPATH, using="(//div[text()='Business Continuity']/following::input[@name='inputLoading'])[2]")
		public static List <WebElement> loadingPercentage_WoP;

		//Waiting Period (Weeks) 
		@FindBy(how= How.XPATH, using="//div[text()='Waiver of Premium']/following::legend[contains(text(), 'Waiting Period')]/following::button[text()='2']")
		public static List <WebElement> wp2;
		
		@FindBy(how= How.XPATH, using="//div[text()='Waiver of Premium']/following::legend[contains(text(), 'Waiting Period')]/following::button[text()='4']")
		public static List <WebElement> wp4;
		
		@FindBy(how= How.XPATH, using="//div[text()='Waiver of Premium']/following::legend[contains(text(), 'Waiting Period')]/following::button[text()='8']")
		public static List <WebElement> wp8;
		
		@FindBy(how= How.XPATH, using="//div[text()='Waiver of Premium']/following::legend[contains(text(), 'Waiting Period')]/following::button[text()='13']")
		public static List <WebElement> wp13;
		
		@FindBy(how= How.XPATH, using="//div[text()='Waiver of Premium']/following::legend[contains(text(), 'Waiting Period')]/following::button[text()='26']")
		public static List <WebElement> wp26;
		
		@FindBy(how= How.XPATH, using="//div[text()='Waiver of Premium']/following::legend[contains(text(), 'Waiting Period')]/following::button[text()='52']")
		public static List <WebElement> wp52;
		
		@FindBy(how= How.XPATH, using="//div[text()='Waiver of Premium']/following::legend[contains(text(), 'Waiting Period')]/following::button[text()='104']")
		public static List <WebElement> wp104;

		//Result
		@FindBy(how= How.XPATH, using="(//div[contains(text(),'Business Continuity')]/following::lightning-formatted-number)[1]")
		public static List <WebElement> premium_BC;
		
		@FindBy(how= How.XPATH, using="(//div[contains(text(),'Business Continuity')]/following::lightning-formatted-number)[2]")
		public static List <WebElement> premium_WoP;

		@FindBy(how= How.XPATH, using="//div[contains(text(),'Business Continuity')]/following::lightning-formatted-number")
		public static List <WebElement> premium;
		//elements definition done!
		
		public void enterSumAssured(String amount, int person) throws InterruptedException
		{
			skipLoadingAnimation();
			if(amount!=null)
			{			
				sendKeysSafely(sumAssured.get(person),amount);			
			}
			skipLoadingAnimation();
		}
		
		public void selectSumAssuredFrequency(String frquency) throws InterruptedException
		{
			selectSumAssuredFrequency(frquency , 0);
		}
		
		public void selectSumAssuredFrequency(String frquency, int person) throws InterruptedException
		{
			switch (frquency)
			{
			case "Annually":
				clickSafely(annuallyFrequency.get(person));    	
				break;

			case "Monthly":    		
				clickSafely(monthlyFrequency.get(person));
				break;
			}
		}
		
		public void selectIndexation(String indexation, int person) throws InterruptedException
		{
			switch (indexation)
			{
			case "Y":
				clickSafely(Indexation_Indexed.get(person));    	
				break;

			case "N":    		
				clickSafely(Indexation_Level.get(person));
				break;
			}
		}
		
		public void selectBenefitType(String type, int person) throws InterruptedException
		{
			switch (type)
			{
			case "Agreed Value":
				clickSafely(BenefitType_AgreedValue.get(person));    	
				break;

			case "Indemnity":    		
				clickSafely(BenefitType_Indemnity.get(person));
				break;
			}
		}
		
		
		public void selectPaymentPeriod(String paymentPeriod, int person) throws InterruptedException
		{
			switch (paymentPeriod)
			{
			case "6":
				clickSafelyJS(sixMonth.get(person));
				break;

			case "12":
				clickSafelyJS(oneYear.get(person));
				break;

			case "24":
				clickSafelyJS(twoYear.get(person));
				break;	
			default:
				clickSafelyJS(sixMonth.get(person));
				break;
			}
		}
		
		public void selectWaitingPeriod(String waitingPeriod, int person) throws InterruptedException
		{
			switch (waitingPeriod)
			{
			case "4":
				clickSafelyJS(waitingPeriod4.get(person));
				break;

			case "8":
				clickSafelyJS(waitingPeriod8.get(person));
				break;

			case "13":
				clickSafelyJS(waitingPeriod13.get(person));
				break;	
			default:
				clickSafelyJS(waitingPeriod4.get(person));
				break;
			}
		}
		
		public void enterBCLoadingPercentage(String percentage, int person) throws InterruptedException
		{
			if(percentage!=null)
			{
				clickSafely(addLoading_BC.get(person));
				clickSafely(showHideLoading_BC);	
				scrollIntoView(loadingPercentage_BC.get(person));	
				sendKeysSafely(loadingPercentage_BC.get(person),percentage);			
			}
		}
		
		public void enterWoPLoadingPercentage(String percentage, int person) throws InterruptedException
		{
			if(percentage!=null)
			{
				clickSafely(addLoading_WoP.get(person));
				clickSafely(showHideLoading_WoP);	
				scrollIntoView(loadingPercentage_WoP.get(person));	
				sendKeysSafely(loadingPercentage_WoP.get(person),percentage);			
			}
		}
		
		public void selectPartialDisablement(String partialDisablement, int person) throws InterruptedException
		{
			switch (partialDisablement)
			{
			case "Y":
				clickSafelyJS(partialDisablementOptionYes.get(person));
				break;

			case "N":
				clickSafelyJS(partialDisablementOptionNo.get(person));
				break;	
			default:
				clickSafelyJS(partialDisablementOptionYes.get(person));
				break;
			}
		}
		
		public void selectWoFWaitingPeriod(String period, int person) throws InterruptedException
		{
			switch (period)
			{
			case "2":
				clickSafely(wp2.get(person));    	
				break;
				
			case "4":
				clickSafely(wp4.get(person));    	
				break;

			case "8":    		
				clickSafely(wp8.get(person));
				break;
				
			case "13":    		
				clickSafely(wp13.get(person));
				break;
				
			case "26":    		
				clickSafely(wp26.get(person));
				break;
				
			case "52":    		
				clickSafely(wp52.get(person));
				break;
				
			case "104":    		
				clickSafely(wp104.get(person));
				break;
			}
		}

		public String getPremium(List<WebElement> element, int person)
		{
			String value = getTextSafely(element.get(person));
			if(value.length()>0)
			{
				value = value.substring(1); 
			} 
			return value;
		}
		
		public String getPremium(int person)
		{
			return getPremium(premium, person);
		}
}
