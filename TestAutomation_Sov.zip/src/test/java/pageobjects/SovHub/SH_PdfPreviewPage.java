package pageobjects.SovHub;

import java.io.File;
import java.io.IOException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import modules.DriverExtension;
import pageobjects.BaseClass;

public class SH_PdfPreviewPage extends BaseClass {
	
    public SH_PdfPreviewPage(WebDriver driver)
    {
        super(driver);
    }


    @FindBy(how= How.XPATH, using="//span[text()='Download']")
    public static WebElement downloadBtn;
    
    @FindBy(how= How.XPATH, using="//img[contains(@class, 'pageImg')]")
    public static WebElement pdfPreviewPage;
    
    
    public void clickDownloadPdf() throws IOException, Throwable
    {
    	clickSafely(pdfPreviewPage);
    	DriverExtension.hoverOverItem(pdfPreviewPage, driver);
    	clickSafely(downloadBtn);

    }
    
    public boolean verifyTextInPdf(String value) throws Throwable, IOException
    {
    	boolean foundInPDF = false;
    	
    	//file name hard coded for POC only.  Will change once solution has been finalized by developers.
    	String home = System.getProperty("user.home");
    	File file = new File(home+"/Downloads/Quote 1.pdf"); 
    	
    	if(file.exists())
   	 {
       	PDDocument document = PDDocument.load(file);
       	PDFTextStripper pdfStripper = new PDFTextStripper();

       	//Retrieving text from PDF document
       	String text = pdfStripper.getText(document);
       	System.out.println(text);
       	
        foundInPDF = text.contains(value);
       	document.close();
       	
       	//cleanup file
       	file.delete();
   	 }
   	else
   	 {
   		Thread.sleep(2000);
   		verifyTextInPdf(value);
   	 }
		return foundInPDF;
    	
    }
}
