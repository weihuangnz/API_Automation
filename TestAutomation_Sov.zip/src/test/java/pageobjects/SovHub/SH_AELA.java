package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import pageobjects.BaseClass;

public class SH_AELA extends BaseClass{

	public SH_AELA(WebDriver driver) {
		super(driver);
	}
	

	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Essential Living Assurance']/following::input[@name='inputBenefitAmount']")
	public static List <WebElement> sumAssured;	
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Essential Living Assurance']/following::button[text()='Rate for Age']")
	public static List <WebElement> rateForAge;

	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Essential Living Assurance']/following::button[text()='10 Year']")
	public static List <WebElement> tenYear;

	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Essential Living Assurance']/following::button[text()='To Age 65']")
	public static List <WebElement> toAge65;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Accelerated Essential Living Assurance')]/following::span[text()='Add More']/parent::button[1]")
	public static List <WebElement> addAELALoading;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Accelerated Essential Living Assurance')]/following::span[text()='Show/Hide Loading']/parent::a")
	public static WebElement showHideAELALoading;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Accelerated Essential Living Assurance')]/following::input[@name='inputLoading']")
	public static List <WebElement> aelaLoadingPercentage;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Accelerated Essential Living Assurance')]/following::input[@name='inputLoadingTerm']")
	public static List <WebElement> aelaLoadingTerm;

	@FindBy(how= How.XPATH, using="//div[contains(text(),'Accelerated Essential Living Assurance')]/following::input[@name='inputPerMille']")
	public static List <WebElement> aelaPerMille;
	
	@FindBy(how= How.XPATH, using="//lightning-formatted-text[contains(text(),'Accelerated Essential Living Assurance')]/following::lightning-formatted-number")
	public static List <WebElement> aelaValue;
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Essential Living Assurance']/following::legend[contains(text(), 'Life Buy-Back')]/following::button[1]")
	public static List <WebElement> lifeBuyBackOptionYes;

	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Essential Living Assurance']/following::legend[contains(text(), 'Life Buy-Back')]/following::button[2]")
	public static List <WebElement> lifeBuyBackOptionNo;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Accelerated Essential Living Assurance')]/preceding::lightning-icon[contains(@class,'check')]")
	public static WebElement aelaCheck;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Accelerated Essential Living Assurance')]/preceding::button[contains(@class,'missionControlWarning')]")
	public static WebElement aelaWarning;	
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Essential Living Assurance']")
	public static WebElement aelaSection;	
	
	@FindBy(how= How.XPATH, using="//div[text()='Accelerated Essential Living Assurance']/following::lightning-primitive-icon")
	public static List<WebElement> aelaAddMore;
	
	@FindBy(how=How.XPATH, using="//div[text()='Accelerated Essential Living Assurance']/following::span[text()='Remove Benefit']")
	public static List<WebElement> aelaRemoveBenefit;
	
	public void enterSumAssured(String amount, int person) throws InterruptedException
	{
		if(amount!=null)
		{			
			sendKeysSafely(sumAssured.get(person),amount);			
		}
	}
	
	public void selectPremiumOption(String PremiumOption, int person) throws InterruptedException
	{
		switch (PremiumOption)
		{
		case "Rate For Age":
			clickSafelyJS(rateForAge.get(person));
			break;

		case "10 Year":
			clickSafelyJS(tenYear.get(person));
			break;

		case "To Age 65":
			clickSafelyJS(toAge65.get(person));
			break;		
		}
	}
	
	
	public void selectLifeBuyBack(String LifeBuyBack, int person) throws InterruptedException
	{
		switch (LifeBuyBack)
		{
		case "Yes":
			clickSafelyJS(lifeBuyBackOptionYes.get(person));
			break;

		case "No":
			clickSafelyJS(lifeBuyBackOptionNo.get(person));
			break;

		default :
			clickSafelyJS(lifeBuyBackOptionNo.get(person));
			break;		
		}
		
	}
	public void enterLoadingPercentage(String percentage, int person) throws InterruptedException
	{
		clickSafely(addAELALoading.get(person));
		clickSafely(showHideAELALoading);	
		if(percentage!=null)
		{			
			scrollIntoView(aelaLoadingPercentage.get(person));	
			sendKeysSafely(aelaLoadingPercentage.get(person),percentage);			
		}
	}
	
	public void enterLoadingTerm(String term, int person) throws InterruptedException
	{
		if(term!=null)
		{
			sendKeysSafely(aelaLoadingTerm.get(person),term);
		}
		else
		{
			sendKeysSafely(aelaLoadingTerm.get(person),"");
		}
	}

	public void enterPerMille(String mille, int person) throws InterruptedException
	{
		if(mille!=null)
		{
			sendKeysSafely(aelaPerMille.get(person),mille);
			sendEnterKeysSafely(aelaPerMille.get(person));
		}
	}
	
	public String getAELAValue(int person)
	{
		String value = getTextSafely(aelaValue.get(person)).substring(1);    	
		return value;
	}
	
	public boolean isAELAStatusSuccessful()
	{		  	
		return aelaCheck.isDisplayed();
	}
	
	public boolean isAELAStatusWarning()
	{		  	
		return aelaWarning.isDisplayed();
	}
	
	public boolean isAELASectionDisplayed()
	{
		return isNotDisplayed(aelaSection);		
	}
	
	public void removeAELA(int person) throws InterruptedException
	{
		clickSafely(aelaAddMore.get(0));
		clickSafely(aelaRemoveBenefit.get(0));
		
	}
}
