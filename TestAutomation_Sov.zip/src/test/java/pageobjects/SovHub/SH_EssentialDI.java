package pageobjects.SovHub;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import pageobjects.BaseClass;

public class SH_EssentialDI extends BaseClass{

	public SH_EssentialDI(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Essential Income Protection')]/following::input[@name='inputBenefitAmount']")
	public static List <WebElement> sumAssured;	
	
	@FindBy(how= How.XPATH, using="//div[text()='Essential Income Protection']/following::legend[contains(text(), 'Indexation')]/following::button[1]")
	public static List <WebElement> indexed;

	@FindBy(how= How.XPATH, using="//div[text()='Essential Income Protection']/following::legend[contains(text(), 'Indexation')]/following::button[2]")
	public static List <WebElement> level;
	
	@FindBy(how= How.XPATH, using="//div[text()='Essential Income Protection']/following::button[text()='Rate for Age']")
	public static List <WebElement> rateForAge;

	@FindBy(how= How.XPATH, using="//div[text()='Essential Income Protection']/following::button[text()='10 Year']")
	public static List <WebElement> tenYear;
	
	@FindBy(how= How.XPATH, using="//div[text()='Essential Income Protection']/following::legend[contains(text(), 'Payment Period')]/following::button[text()='5 years']")
	public static List <WebElement> pp5years;
	
	@FindBy(how= How.XPATH, using="//div[text()='Essential Income Protection']/following::legend[contains(text(), 'Payment Period')]/following::button[text()='To Age 65']")
	public static List <WebElement> ppToAge65;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Essential Income Protection')]/following::span[text()='Add More']/parent::button[1]")
	public static List <WebElement> addEDILoading;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Essential Income Protection')]/following::span[text()='Show/Hide Loading']/parent::a")
	public static WebElement showHideEDILoading;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Essential Income Protection')]/following::input[@name='inputLoading']")
	public static List <WebElement> ediLoadingPercentage;
	
	@FindBy(how= How.XPATH, using="//div[contains(text(),'Essential Income Protection')]/following::lightning-formatted-number")
	public static List <WebElement> ediValue;
	
	public void enterLoadingPercentage(String percentage, int person) throws InterruptedException
	{
		if(percentage!=null)
		{
			clickSafely(addEDILoading.get(person));
			clickSafely(showHideEDILoading);	
			scrollIntoView(ediLoadingPercentage.get(person));	
			sendKeysSafely(ediLoadingPercentage.get(person),percentage);			
		}
	}
	
	public void selectPaymentPeriod(String period, int person) throws InterruptedException
	{
		switch (period)
		{		

		case "5 years":    		
			clickSafely(pp5years.get(person));
			break;
			
		case "To Age 65":    		
			clickSafely(ppToAge65.get(person));
			break;			
		
		}
	}
	
	public void enterSumAssured(String amount, int person) throws InterruptedException
	{
		if(amount!=null)
		{			
			sendKeysSafely(sumAssured.get(person),amount);			
		}
	}
	
	public void selectIndexation(String indexation, int person) throws InterruptedException
	{
		switch (indexation)
		{
		case "Indexed":
			clickSafely(indexed.get(person));    	
			break;

		case "Level":    		
			clickSafely(level.get(person));
			break;
		}
	}
	
	public void selectPremiumOption(String PremiumOption, int person) throws InterruptedException
	{
		switch (PremiumOption)
		{
		case "Rate For Age":
			clickSafelyJS(rateForAge.get(person));
			break;

		case "10 Year":
			clickSafelyJS(tenYear.get(person));
			break;
				
		}
	}
	
	public String getEDIValue(int person)
	{
		String value = getTextSafely(ediValue.get(person));
		if(value.length()>0)
		{
			value = value.substring(1); 
		} 
		return value;
	}
	

}
