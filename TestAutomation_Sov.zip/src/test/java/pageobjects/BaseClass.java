package pageobjects;

import PropertiesFilesStrategy.PropertiesFileUtil;
import modules.DriverExtension;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by AmstelB on 8/03/2017.
 */
public abstract class BaseClass {

    public static WebDriver driver;
    public static boolean bResult;

    public static final String LOADING_PATH="//lightning-spinner[contains(@class,'slds-spinner_container')]";
    public static final String MSG_PATH="//span[@class='message']";

    public BaseClass(WebDriver driver){

        this.driver = driver;
        BaseClass.bResult = true;
        PageFactory.initElements(driver, this);
    }


    public void clickOnAccordionName(String element) {
        String xpath = "//span[text()='"+ element+"']";
        WebElement accordionElement = DriverExtension.findElementSafe(driver, By.xpath(xpath));
        if (DriverExtension.exist(accordionElement)) {
            accordionElement.click();
        }
    }


    public void selectOption(Select select, String optionName){

        if (select != null) {
            List<WebElement> options = select.getOptions().stream()
                    .filter(op -> op.getText().contains(optionName)).collect(Collectors.toList());

            if(!options.isEmpty()){
                   WebElement option = options.get(0);
                       option.click();
            }
        }
    }


    public String getOrganizationName(){
        String environment = DriverExtension.getEnvironment();

        switch (environment) {
            case "Staging":
                return DataFeed().getProperty("XeroAccountStaging");
            case "Alpha":
                return DataFeed().getProperty("XeroAccountAlpha");
            default: return "";
        }
    }
    public void sendKeysTraditional(WebElement element,String input) throws InterruptedException
    {
    	DriverExtension.waitForElementToAppear(driver,element);
    	element.click();
    	element.clear();
    	element.sendKeys(input);   
    }
    public void sendKeysSafely(WebElement element,String input) throws InterruptedException
    {
    	DriverExtension.waitForElementToAppear(driver,element);   
    	    	
    	JavascriptExecutor jse = (JavascriptExecutor)driver;
    	jse.executeScript("arguments[0].click();", element);
    	element.clear(); 
    //	jse.executeScript("arguments[0].value='';", element);    
    //	String command = String.format("arguments[0].value='%s';", input);
    //	jse.executeScript(command, element);    	
    	element.sendKeys(input); 
    }
    
    public void sendEnterKeysSafely(WebElement element)
    {    	
    	element.sendKeys(Keys.ENTER);    	
    }
    
    public void clickSafely(WebElement element) throws InterruptedException
    {   
    	DriverExtension.waitForElementToAppear(driver,element);   
    	DriverExtension.waitforElementThenClick(driver,element); 
    	 		
    }
    
    public void scrollIntoView(WebElement element) throws InterruptedException
    {    	
    	DriverExtension.moveToElement(element,driver);    	 		
    }   
    
    
    public void clickSafelyJS(WebElement element) throws InterruptedException
    {   
    	JavascriptExecutor exec = (JavascriptExecutor)driver;
    	DriverExtension.waitForElementToAppear(driver,element);    	
    	exec.executeScript("arguments[0].click();", element);		
    }
    
    public void selectByText(WebElement element,String text)
    {
    	Select select = new Select(element);
        select.selectByVisibleText(text);  
    }
    public static void skipLoadingAnimation()
    {
    	DriverExtension.waitForElementToDisappear(driver,By.xpath(LOADING_PATH));
    }
    
    public String getTextSafely(WebElement element)
    {
    	DriverExtension.waitForElementToAppear(driver,element);
    	return element.getText();    	
    }

    public PropertiesFileUtil DataFeed(){
        return PropertiesFileUtil.getInstance("DataFeed");
    }

    public PropertiesFileUtil AlphaFeed(){
        return PropertiesFileUtil.getInstance("QA");
    }

    public PropertiesFileUtil StaginFeed(){
        return PropertiesFileUtil.getInstance("FST");
    }
    
    public boolean isElementSelected(WebElement element) throws InterruptedException
    {    	
    	boolean isSelected=false;
    	DriverExtension.waitForElementToAppear(driver,element);
    	if(element.getAttribute("class").contains("is-selected"))
    	{
    		isSelected=true;
    	}
    	return isSelected;
    	 		
    }
    
    public boolean isDisplayed(WebElement element) 
    {
    	return DriverExtension.isVisible(element);    	
    }   
    
    
    public boolean isNotDisplayed(WebElement element)
    {    	
            try
            {
               if(isDisplayed(element))
               {
               return false;
               }
               return false;
            }
            catch(Exception e)
            {                
                return true;
            }
        
    }
    public String getAttributeSafely(WebElement element,String attribute)
    {
    	DriverExtension.waitForElementToAppear(driver,element);
    	return element.getAttribute(attribute);
    }

}
