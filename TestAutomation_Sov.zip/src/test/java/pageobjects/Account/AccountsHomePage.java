package pageobjects.Account;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import pageobjects.BaseClass;

/**
 * Created by AmstelB on 3/05/2017.
 */
public class AccountsHomePage extends BaseClass {


    public AccountsHomePage(WebDriver driver)
    {
        super(driver);
    }

    @FindBy(how= How.XPATH, using="//input[@value=' New ']")
    public static WebElement newAccount;

    @FindBy(how= How.XPATH, using="//a[text()='Accounts']")
    public static WebElement accountTab;


    public void clickNewAccount()
    {
        //AccountsHomePage.accountTab.click();
        this.newAccount.click();
    }

}
