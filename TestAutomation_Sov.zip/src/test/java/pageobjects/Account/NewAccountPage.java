package pageobjects.Account;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import pageobjects.BaseClass;

/**
 * Created by AmstelB on 3/05/2017.
 */
public class NewAccountPage extends BaseClass {


    public NewAccountPage(WebDriver driver)
    {
        super(driver);
    }

    //Account Information

    @FindBy(how= How.XPATH, using="//input[@value=' Save ']")
    public static WebElement btnSave;

    @FindBy(how= How.XPATH, using="//input[@value='Save & New']")
    public static WebElement btnSaveAndNew;

    @FindBy(how= How.XPATH, using="//input[@value='Cancel']")
    public static WebElement btnCancel;

    @FindBy(how= How.ID, using="acc2")
    public static WebElement accountNames;

    @FindBy(how= How.ID, using="acc3")
    public static WebElement parentAccounts;

    @FindBy(how= How.ID, using="acc5")
    public static WebElement accountNumbers;

    @FindBy(how= How.ID, using="acc23")
    public static WebElement accountSites;

    @FindBy(how= How.ID, using="acc6")
    public static WebElement type;

    @FindBy(how= How.ID, using="acc10")
    public static WebElement phone;


    //Address Information

    @FindBy(how= How.ID, using="acc17street")
    public static WebElement billingStreets;

    @FindBy(how= How.ID, using="acc17city")
    public static WebElement billingCities;

    @FindBy(how= How.ID, using="acc17zip")
    public static WebElement billingPostalCodes;

    @FindBy(how= How.XPATH, using="//a[text()='Copy Billing Address to Shipping Address']")
    public static WebElement copyBillingAddressLink;

    //Description Information

    @FindBy(how= How.ID, using="acc20")
    public static WebElement descriptions;
    

    public void clickSave()
    {
        this.btnSave.click();
    }

    public void enterAccountName(String accountName)
    {
        this.accountNames.sendKeys(accountName);
    }

    public void enterParentAccount(String parentAccount)
    {
        this.parentAccounts.sendKeys(parentAccount);
    }

    public void enterAccountNumber(String accountNumber)
    {
        this.accountNumbers.sendKeys(accountNumber);
    }

    public void selectType(String value)
    {
        this.type.sendKeys(value);
    }

    public void enterPhoneNumber(String phoneNumber)
    {
        this.phone.sendKeys(phoneNumber);
    }

    public void enterBillingStreet(String billingStreet)
    {
        this.billingStreets.sendKeys(billingStreet);
    }

    public void enterBillingCity(String billingCity)
    {
        this.billingCities.sendKeys(billingCity);
    }

    public void enterPostalCode(String postalCode)
    {
        this.billingPostalCodes.sendKeys(postalCode);
    }

    public void enterDescription(String description)
    {
        this.descriptions.sendKeys(description);
    }

}
