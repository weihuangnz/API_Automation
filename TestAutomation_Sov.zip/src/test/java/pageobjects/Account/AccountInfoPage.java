package pageobjects.Account;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import pageobjects.BaseClass;

/**
 * Created by AmstelB on 4/05/2017.
 */
public class AccountInfoPage extends BaseClass {

    public AccountInfoPage(WebDriver driver)
    {
        super(driver);
    }

    @FindBy(how= How.XPATH, using="//h2[@class='topName']")
    public static WebElement accountName;

    @FindBy(how= How.ID, using="acc5_ileinner")
    public static WebElement accountNumber;


    public void enterAccountName(String accountNm)
    {
        accountName.sendKeys(accountNm);
    }

    public void enteraccountNumber(String accountNr)
    {
        accountNumber.sendKeys(accountNr);
        //test
        //gvhgchghg
    }

}

