package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * Created by AmstelB on 8/03/2017.
 */
public class LoginPage extends BaseClass{

    public LoginPage(WebDriver driver)
    {
        super(driver);
    }

    @FindBy(how= How.XPATH, using="//input[contains(@id,'user')]")
    public static WebElement userName;

    @FindBy(how= How.XPATH, using="//input[contains(@id,'password')]")
    public static WebElement passWord;

    @FindBy(how= How.XPATH, using="//input[@value='Log in']")
    public static WebElement login;

    public void enterUsernamePassword(String username, String password) throws Exception{
    	sendKeysSafely(userName,username);
    	sendKeysSafely(passWord,password);       
    }

    public void clickLogin() throws Exception{
        clickSafely(login);
    }
}
