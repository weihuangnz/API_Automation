package pageobjects.Sovereign;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import pageobjects.BaseClass;

	public class SOV_HomePage extends BaseClass {

	    public SOV_HomePage(WebDriver driver)
	    {
	        super(driver);
	    }
	    

	    @FindBy(how= How.XPATH, using="//a[contains(text(), 'Find an adviser')]")
	    public static WebElement findAdvisor;
	    
	    public void clickFindAdvisor()
	    {
	    	findAdvisor.click();
	    }
	    
  }
