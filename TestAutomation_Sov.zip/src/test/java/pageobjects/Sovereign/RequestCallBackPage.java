package pageobjects.Sovereign;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import pageobjects.BaseClass;

public class RequestCallBackPage extends BaseClass {

	    public RequestCallBackPage(WebDriver driver)
	    {
	        super(driver);
	    }
	    
	    @FindBy(how= How.NAME, using="first_name")
	    public static WebElement firstName;
	    
	    @FindBy(how= How.NAME, using="last_name")
	    public static WebElement lastName;
	    
	    @FindBy(how= How.ID, using="dob-day")
	    public static WebElement birth_Day;
	    
	    @FindBy(how= How.ID, using="dob-month")
	    public static WebElement birth_Month;
	    
	    @FindBy(how= How.ID, using="dob-year")
	    public static WebElement birth_Year;
	    
	    @FindBy(how= How.NAME, using="street")
	    public static WebElement address;
	    
	    @FindBy(how= How.NAME, using="phone")
	    public static WebElement phoneNumber;
	    
	    @FindBy(how= How.NAME, using="email")
	    public static WebElement emailAddress;
	    
	    @FindBy(how= How.ID, using="description")
	    public static WebElement descriptionText;
	    
	    @FindBy(how= How.XPATH, using="//ul[@class='af_list']/li")
	    public static List<WebElement> addressDropDown;
	    
	    
	    public void enterfirstNamelastName(String FirstName, String LastName)
	    {
	    	firstName.sendKeys(FirstName);
	    	lastName.sendKeys(LastName);
	    }
	    
	    public void enterDateOfBirth()
	    {
	    	String Day = "7";
	    	String Month = "8";
	    	String Year = "1980";
	    	
	    	birth_Day.sendKeys(Day);
	    	birth_Month.sendKeys(Month);
	    	birth_Year.sendKeys(Year);
	    }
	        
	    public void enterAddress(String Address)
	    {
	    	address.sendKeys(Address);
	    	addressDropDown.get(0).click();
	    }
	    
	    public void enterEmailAddress(String Email)
	    {
	    	emailAddress.sendKeys(Email);
	    }
	    
	    public void enterDescription(String Description) throws InterruptedException
	    {
	    	((JavascriptExecutor) driver)
	        .executeScript("window.scrollTo(0, document.body.scrollHeight)");
	    	
	    	descriptionText.sendKeys(Description);
	    }
	    
	    public void enterPhoneNumber(String PhoneNumber)
	    {
	    	phoneNumber.sendKeys(PhoneNumber);
	    }

}


