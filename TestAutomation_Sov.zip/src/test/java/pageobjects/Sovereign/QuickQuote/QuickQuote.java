package pageobjects.Sovereign.QuickQuote;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import modules.DriverExtension;
import pageobjects.BaseClass;

public class QuickQuote extends BaseClass{
	
    public QuickQuote(WebDriver driver)
    {
        super(driver);
    }
    
    String GBenefit;
    
    @FindBy(how= How.XPATH, using="//label[contains(text(), 'Age')]/following::input[1]")
    public static WebElement ageTextbox;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'Male')]")
    public static WebElement genderMale;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'Female')]")
    public static WebElement genderFemale;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'Yes')]")
    public static WebElement smokerYes;
    
    @FindBy(how= How.XPATH, using="//span[contains(text(), 'No')]")
    public static WebElement smokerNo;
        
    
    //Occupation Class
    @FindBy(how= How.XPATH, using="//label[@for='Occupation Class10']")
    public static WebElement occupationClass1;
    
    @FindBy(how= How.ID, using="Occupation Class20")
    public static WebElement occupationClass2;
    
    @FindBy(how= How.ID, using="Occupation Class30")
    public static WebElement occupationClass3;
    
    @FindBy(how= How.ID, using="Occupation Class40")
    public static WebElement occupationClass4;
    

    //Calculate Button
    @FindBy(how= How.XPATH, using="//button[contains(text(), 'CALCULATE')]")
    public static WebElement calculateButton;
    
    
    
    public void selectBenefits(String Benefits) throws InterruptedException {
        DriverExtension.waitforElement(driver, ageTextbox);
        JavascriptExecutor exec = (JavascriptExecutor)driver;
        WebElement benefitOptions = driver.findElement(By.xpath("//span[contains(text(), '"+ Benefits +"')]/preceding::input[1]"));
        exec.executeScript("arguments[0].click();", benefitOptions);
        Thread.sleep(500);
    }
    
    public void enterBenefitAmount(String Benefits, String Amount) throws InterruptedException {
        DriverExtension.waitforElement(driver, ageTextbox);
        WebElement benefitTextbox = driver.findElement(By.xpath("//span[contains(text(), '"+ Benefits +"')]/following::input[1]"));
        benefitTextbox.sendKeys(Amount);
        Thread.sleep(500); 
    }
    
    public void enterAge(String Age) throws InterruptedException
    {
    	DriverExtension.waitForLoadPage(driver);
    	DriverExtension.waitforElement(driver, ageTextbox);
    	ageTextbox.sendKeys(Age);
    }
    
    public void selectGender(String Gender) throws InterruptedException
    {
    	
    	JavascriptExecutor exec = (JavascriptExecutor)driver;
    	
    	switch (Gender)
    	{
    	case "Female":
    		exec.executeScript("arguments[0].click();", genderFemale);
    		break;
    		
    	case "Male":
    		exec.executeScript("arguments[0].click();", genderMale);
    		break;
    	}
    
    }
    
    public void selectSmoker(String Smoker)
    {
    	JavascriptExecutor exec = (JavascriptExecutor)driver;
    	
    	switch (Smoker)
    	{
    	case "Yes":
    		exec.executeScript("arguments[0].click();", smokerYes);
    		break;
    		
    	case "No":
    		exec.executeScript("arguments[0].click();", smokerNo);
    		break;
    	}
    }
    
    public void selectOccupationClass() throws InterruptedException
    {
    	DriverExtension.waitforElementThenClick(driver, occupationClass1);
    }
    
   
    public void clickCalculate() throws InterruptedException
    {	 
    	calculateButton.click();
    }
    

}
