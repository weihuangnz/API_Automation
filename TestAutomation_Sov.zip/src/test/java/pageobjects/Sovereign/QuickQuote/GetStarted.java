package pageobjects.Sovereign.QuickQuote;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import pageobjects.BaseClass;

public class GetStarted extends BaseClass{
	
	
    public GetStarted(WebDriver driver)
    {
        super(driver);
    }
    
    @FindBy(how= How.XPATH, using="//label[contains(text(), 'Your Email')]/following::input[1]")
    public static WebElement emailTextbox;
    
    @FindBy(how= How.XPATH, using="//button[contains(text(), 'GO')]")
    public static WebElement goButton;
    
    
    public void enterEmail(String EmailAddress)
    {
    	emailTextbox.sendKeys(EmailAddress);
    }
    
    public void clickGo()
    {
    	goButton.click();
    }
    

}
