package pageobjects.Sovereign.QuickQuote;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import modules.DriverExtension;
import pageobjects.BaseClass;

public class QuoteSummary extends BaseClass{
	
	
    public QuoteSummary(WebDriver driver)
    {
        super(driver);
    }
    
    
    @FindBy(how= How.XPATH, using="//h2[@class='slds-text-heading--large']")
    public static WebElement premiumHeader;
    
    
    public boolean premiumHeaderDisplayed() throws InterruptedException
    {
    	DriverExtension.waitforElement(driver, premiumHeader);
    	boolean exists = DriverExtension.isVisible(premiumHeader);
    	return exists;
    }
    
    
    

}
