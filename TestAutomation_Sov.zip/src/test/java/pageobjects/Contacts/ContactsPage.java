package pageobjects.Contacts;

import modules.DriverExtension;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageobjects.BaseClass;

import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;

/**
 * Created by AmstelB on 13/03/2017.
 */
public class ContactsPage extends BaseClass {

    public ContactsPage(WebDriver driver)
    {
        super(driver);
    }

    @FindBy(how= How.XPATH, using="//a[@data-original-title='Add']")
    public static WebElement contactsAdd;

    @FindBy(how= How.XPATH, using="//table[@class='style styled no-border table-hover']")
    public static WebElement contactsTable;

    @FindBy(how= How.XPATH, using="//span[@class='subnav-name']")
    public static WebElement subNavName;

    @FindBy(how= How.XPATH, using="//label[contains(text(), 'Account Name')]/following::input[1]")
    public static WebElement accountNames;

    @FindBy(how= How.XPATH, using="//label[contains(text(), 'Supplier')]/following::input[1]")
    public static WebElement supplierCheckbox;

    @FindBy(how= How.XPATH, using="//textarea[contains(@id, 'physicalStreet')]")
    public static WebElement physicalStreet;

    @FindBy(how= How.XPATH, using="//input[contains(@id, 'physicalSuburb')]")
    public static WebElement townCity;

    @FindBy(how= How.XPATH, using="//input[contains(@id, 'physicalCity')]")
    public static WebElement stateRegion;

    @FindBy(how= How.XPATH, using="//input[contains(@id, 'physicalPostalCode')]")
    public static WebElement postalCode;

    @FindBy(how= How.XPATH, using="//input[contains(@id, 'physicalCountry')]")
    public static WebElement physicalCountry;

    @FindBy(how= How.XPATH, using="//textarea[contains(@id, 'postalStreet')]")
    public static WebElement postalStreet;

    @FindBy(how= How.XPATH, using="//a[@class='physicalToPostal']")
    public static WebElement paUsePhysicalAddressLink;

    @FindBy(how= How.XPATH, using="//a[@class='PhysicalToJob']")
    public static WebElement djaUsePhysicalAddressLink;

    @FindBy(how= How.XPATH, using="//a[@data-original-title='Save']")
    public static WebElement saveButton;

    @FindBy(how= How.XPATH, using="//label[contains(text(), 'Customer')]/following::input[1]")
    public static WebElement customerCheckbox;

    //Primary Person
    @FindBy(how= How.XPATH, using="//label[contains(text(), 'First Name')]/following::input[1]")
    public static WebElement firstName;

    @FindBy(how= How.XPATH, using="//label[contains(text(), 'Last Name')]/following::input[1]")
    public static WebElement lastName;

    @FindBy(how= How.XPATH, using="//label[contains(text(), 'Email')]/following::input[1]")
    public static WebElement emailAddress;

    @FindBy(how= How.XPATH, using="//label[contains(text(),'Account Name')]/following::span[1]")
    public static WebElement accountName;

    public void enterPrimaryPersonName(String FirstName)
    {
        this.firstName.sendKeys(FirstName);
    }

    public void enterPrimaryPersonLastName(String LastName)
    {
        this.lastName.sendKeys(LastName);
    }

    public void enterPrimaryPersonEmail(String Email)
    {
        this.emailAddress.sendKeys(Email);
    }

    public void enterAccountName(String accountName)
    {
        this.accountNames.sendKeys(accountName);
    }

    public void clickCustomerCheckBox()
    {
        this.customerCheckbox.click();
    }

    public void clickSupplierCheckbox()
    {
        supplierCheckbox.click();
    }

    public void enterStreet(String Street)
    {
        this.physicalStreet.sendKeys(Street);
    }

    public void enterCity(String TownCity)
    {
        this.townCity.sendKeys(TownCity);
    }

    public void enterRegion(String StateRegion)
    {
        this.stateRegion.sendKeys(StateRegion);
    }

    public void enterPostalCodes(String PostalCode)
    {
        this.postalCode.sendKeys(PostalCode);
    }

    public void enterCountry(String Country)
    {
        this.physicalCountry.clear();
        this.physicalCountry.sendKeys(Country);
    }

    public void clickPhysicalAddressLink()
    {   DriverExtension.scrollDown(driver);
        this.paUsePhysicalAddressLink.click();
    }

    public void clickUsePhysicalAddressLink()
    {   DriverExtension.scrollDown(driver);
        this.djaUsePhysicalAddressLink.click();
    }

    public void clickSave() throws InterruptedException {
        DriverExtension.scrollUp(driver);
        this.saveButton.click();
        Thread.sleep(2000);
    }

    public Boolean isAccountNamePresent(String accountNameS) {
        DriverExtension.waitForLoadPage(driver);
        WebElement accountName = (new WebDriverWait(driver, 10))
                .until(presenceOfElementLocated(By.xpath("//label[contains(text(),'Account Name')]/following::span[1]")));
        return DriverExtension.exist(accountName)&& accountName.getText().contains(accountNameS);
    }
}
