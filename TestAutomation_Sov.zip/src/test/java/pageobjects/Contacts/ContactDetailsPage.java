package pageobjects.Contacts;

import modules.DriverExtension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import pageobjects.BaseClass;

public class ContactDetailsPage extends BaseClass {

    public ContactDetailsPage(WebDriver driver)
    {
        super(driver);
    }

    @FindBy(how= How.XPATH, using="//span[@class='fa fa-pencil']")
    public static WebElement contactsEdit;

    @FindBy(how= How.XPATH, using="//a[@data-original-title='Save']")
    public static WebElement contactsSave;


    public void clickEdit() throws InterruptedException {
        DriverExtension.waitforElement(driver, contactsEdit);
        contactsEdit.click();
    }

    public void clickSave() throws InterruptedException {
        DriverExtension.waitforElement(driver, contactsSave);
        contactsSave.click();
    }




}
