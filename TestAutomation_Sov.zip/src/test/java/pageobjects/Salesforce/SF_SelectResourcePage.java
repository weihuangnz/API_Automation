package pageobjects.Salesforce;

import modules.DriverExtension;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import pageobjects.BaseClass;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by AmstelB on 12/07/2017.
 */
public class SF_SelectResourcePage extends BaseClass {

    public SF_SelectResourcePage(WebDriver driver)
    {
        super(driver);
    }

    @FindBy(how= How.ID, using="addButton")
    public static WebElement addBtn;

    @FindBy(how= How.XPATH, using="//button[text()='Close']")
    public static List<WebElement> closeBtn;

    @FindBy(how= How.XPATH, using="//input[@data-original-title='Start Date']")
    public static WebElement startDate;

    @FindBy(how= How.XPATH, using="//input[@data-original-title='End Date']")
    public static WebElement endDate;

    @FindBy(how= How.XPATH, using="//h3[text()='Select Resource']")
    public static WebElement header;



    public void selectResource(String Resource) throws InterruptedException {
        DriverExtension.waitforElement(driver, addBtn);
        WebElement resourceName = driver.findElement(By.xpath("//label[contains(text(), '"+ Resource +"')]/preceding::input[1]"));
        resourceName.click();
    }


    public void clickAddButton()
    {
        addBtn.click();
        DriverExtension.skipLoadingAnimation(driver);
    }

    public void clickCloseButton()
    {
        closeBtn.get(0).click();
    }

    public void setStartDate()
    {
        startDate.clear();

        DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        String date = df.format(new Date());

        startDate.sendKeys(date);
        header.click();
    }

    public void setEndDate()
    {
        endDate.clear();

        DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        String date = df.format(new Date());

        endDate.sendKeys(date);
        header.click();
    }

}
