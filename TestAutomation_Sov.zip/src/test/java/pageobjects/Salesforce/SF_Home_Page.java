package pageobjects.Salesforce;

import modules.DriverExtension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import pageobjects.BaseClass;

import java.util.List;
import java.util.NoSuchElementException;

/**
 * Created by AmstelB on 7/09/2017.
 */
public class SF_Home_Page extends BaseClass {

    public SF_Home_Page(WebDriver driver)
    {
        super(driver);
    }


    @FindBy(how= How.XPATH, using="//a[text()='Work List']")
    public static WebElement workListTab;

    @FindBy(how= How.ID, using="phSearchInput")
    public static WebElement searchBox;

    @FindBy(how= How.ID, using="phSearchButton")
    public static WebElement searchBtn;

    @FindBy(how= How.XPATH, using="//span[@class='gt-ct-header-text']")
    public static WebElement popup;

    @FindBy(how= How.XPATH, using="//button[text()='No Thanks']")
    public static WebElement closePopPupBtn;

    @FindBy(how= How.XPATH, using="//div[@class='zen-select']")
    public static List <WebElement> userNameDropDown;

    @FindBy(how= How.XPATH, using="//ul[@class='zen-options']/li")
    public static List <WebElement> globalHeaderoptions;

    @FindBy(how= How.ID, using="cruc_notify")
    public static WebElement popupWindow;

    @FindBy(how= How.XPATH, using="//a[@title='Close']")
    public static WebElement popupClose;


    public void clickSalesforceTab(WebElement element) throws InterruptedException {

        DriverExtension.waitforElementThenClick(driver, element);
    }

    public void searchSalesforce(String item) throws InterruptedException {
        DriverExtension.waitforElement(driver, searchBox);
        searchBox.sendKeys(item);
        searchBtn.click();
    }

    public void checkPopupWindow()
    {
        try {
            Boolean popupCheck = DriverExtension.isVisible(popup);

            if(popupCheck == true)
            {
                closePopPupBtn.click();
            }

        } catch (Exception e) {
        }
    }

    public void checkPopup()
    {
        try {
            Boolean popupCheck = DriverExtension.isVisible(popupWindow);

            if(popupCheck == true)
            {
                popupClose.click();
            }

        } catch (Exception e) {
        }
    }

    public void selectGlobalHeaderOption(String item) {
        userNameDropDown.get(1).click();

        List<WebElement> allElements = globalHeaderoptions;

        for (WebElement element : allElements) {

            try {
                if (element.getText().contains(item)) {
                    element.click();
                    DriverExtension.skipLoadingAnimation(driver);
                    break;
                }
            } catch (NoSuchElementException e) {
                e.printStackTrace();
            }
        }

        checkPopup();
    }
}
