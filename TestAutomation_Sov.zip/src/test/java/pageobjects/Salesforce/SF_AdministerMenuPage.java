package pageobjects.Salesforce;

import modules.DriverExtension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import pageobjects.BaseClass;

public class SF_AdministerMenuPage extends BaseClass {

    public SF_AdministerMenuPage(WebDriver driver)
    {
        super(driver);
    }

    @FindBy(how= How.ID, using="Security_font")
    public static WebElement securityControls;

    @FindBy(how= How.ID, using="SecuritySharing_font")
    public static WebElement sharingSettings;

    @FindBy(how= How.ID, using="setupSearch")
    public static WebElement quickFind;

    @FindBy(how= How.ID, using="setupSearchButton")
    public static WebElement quickFindBtn;

    @FindBy(how= How.ID, using="cruc_notify")
    public static WebElement popupWindow;

    @FindBy(how= How.XPATH, using="//a[@title='Close']")
    public static WebElement popupClose;


    public void clickSecurityControls()
    {
        securityControls.click();
        checkPopup();
    }

    public void clickSharingSettings()
    {
        sharingSettings.click();
        checkPopup();
    }

    public void enterQuickSearch(String search)
    {
        quickFind.sendKeys(search);
        quickFindBtn.click();
    }

    public void checkPopup()
    {
        try {
            Boolean popupCheck = DriverExtension.isVisible(popupWindow);

            if(popupCheck == true)
            {
                popupClose.click();
            }

        } catch (Exception e) {
        }
    }


}
