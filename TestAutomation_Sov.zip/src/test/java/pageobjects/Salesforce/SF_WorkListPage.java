package pageobjects.Salesforce;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

import modules.DriverExtension;
import pageobjects.BaseClass;

public class SF_WorkListPage extends BaseClass {
	
    public SF_WorkListPage(WebDriver driver)
    {
        super(driver);
    }
    
    @FindBy(how= How.XPATH, using="//img[@class='pageTitleIcon']/following::select[1]")
    public static WebElement workListSelect;
    
    @FindBy(how= How.XPATH, using="//table[@class='list']")
    public static WebElement workListTable;
    
    @FindBy(how= How.XPATH, using="//img[@class='next']")
    public static WebElement workListTableNext;
    
    String newPA_XPATH = "//a[contains(@class, 'actionLink smallText') and contains(@onclick ,'showPopup_addPolicyApplication')]";
    
    
    public void selectWorkListOption(String option)
    {
        Select dropdown = new Select(workListSelect);
        dropdown.selectByVisibleText(option);
    }
    
    
    
    
    public void findAndClickNewPA()
    {
        if(!driver.findElements(By.xpath(newPA_XPATH)).isEmpty()){
        	
        	List <WebElement> element;
        	element = driver.findElements(By.xpath(newPA_XPATH));
        	element.get(0).click();
        }else{
        	DriverExtension.scrollToBottom(driver);
        	workListTableNext.click();
        	findAndClickNewPA();
        }
    }
    
}
