package pageobjects.Salesforce;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import pageobjects.BaseClass;

import java.util.List;

public class SF_NetworkPage extends BaseClass {

    public SF_NetworkPage(WebDriver driver)
    {
        super(driver);
    }

    @FindBy(how= How.XPATH, using="//table[@class='list']")
    public static WebElement worksTable;

    @FindBy(how= How.XPATH, using="//td[@class='pbButton']/input[@value='Sharing']")
    public static WebElement sharingBtn;

    @FindBy(how= How.XPATH, using="//input[@name='edit']")
    public static List<WebElement> editBtn;


    public void clickSharingBtn()
    {
        sharingBtn.click();
    }

    public void clickEdit()
    {
        editBtn.get(0).click();
    }

}
