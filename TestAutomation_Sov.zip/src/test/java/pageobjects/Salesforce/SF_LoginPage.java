package pageobjects.Salesforce;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import pageobjects.BaseClass;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Created by AmstelB on 3/05/2017.
 */
public class SF_LoginPage extends BaseClass {

    public SF_LoginPage(WebDriver driver)
    {
        super(driver);
    }

    @FindBy(how= How.ID, using="username")
    public static WebElement userName;

    @FindBy(how= How.ID, using="password")
    public static WebElement passWord;

    @FindBy(how= How.ID, using="Login")
    public static WebElement login;

    @FindBy(how= How.ID, using="emc")
    public static WebElement verificationCode;

    @FindBy(how= How.ID, using="save")
    public static WebElement verify;

    public void salesForceLogin() throws IOException {

        Properties properties = new Properties();
        InputStream input = new FileInputStream("src/test/resources/FST.properties");

        // load properties file
        properties.load(input);

        userName.sendKeys(properties.getProperty("s_username"));
        passWord.sendKeys(properties.getProperty("s_password"));
        try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        login.click();
        
        try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }


    public void enterSecurityCode(String code) throws InterruptedException {
        navigateBackToSalesforce();
        verificationCode.sendKeys(code);
        verify.click();
    }

    public void navigateBackToSalesforce() throws InterruptedException {

        for (int i = 0; i < 3; i++) {
            driver.navigate().back();
            Thread.sleep(500);
        }

    }


}
