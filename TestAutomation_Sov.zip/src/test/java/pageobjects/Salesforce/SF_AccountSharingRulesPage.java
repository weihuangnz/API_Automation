package pageobjects.Salesforce;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;
import pageobjects.BaseClass;

public class SF_AccountSharingRulesPage extends BaseClass {

    public SF_AccountSharingRulesPage(WebDriver driver)
    {
        super(driver);
    }

    @FindBy(how= How.XPATH, using="//input[@title='New Account Sharing Rules']")
    public static WebElement newAccountSharingRules;

    @FindBy(how= How.ID, using="ruleName")
    public static WebElement labelField;

    @FindBy(how= How.ID, using="ruleDevName")
    public static WebElement ruleName;

    @FindBy(how= How.ID, using="ownedby")
    public static WebElement ownedBy;

    @FindBy(how= How.ID, using="ownedby_K")
    public static WebElement ownedByR;

    @FindBy(how= How.ID, using="sharedwith")
    public static WebElement sharedWith;

    @FindBy(how= How.ID, using="sharedwith_K")
    public static WebElement sharedwithR;

    @FindBy(how= How.ID, using="p3")
    public static WebElement assetAccess;

    @FindBy(how= How.ID, using="p4")
    public static WebElement oppertunityAccess;

    @FindBy(how= How.ID, using="p7")
    public static WebElement caseAccess;

    @FindBy(how= How.XPATH, using="//input[@name='save']")
    public static WebElement save;



    public void clickNewAccountSharingRulesBtn()
    {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", newAccountSharingRules);
        newAccountSharingRules.click();
    }

    public void enterLabelName(String labelText)
    {
        labelField.sendKeys(labelText);
    }

    public void enterRuleName(String ruleNameText)
    {
        ruleName.sendKeys(ruleNameText);
    }


    public void selectDropDownRecords(WebElement element, String option)
    {
        Select dropdown = new Select(element);
        dropdown.selectByVisibleText(option);
    }

    public void clickSave()
    {
        save.click();
    }


}
