package pageobjects.Salesforce;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import modules.DriverExtension;
import pageobjects.BaseClass;

public class SF_AgentLookupPage extends BaseClass{
	
	
	public SF_AgentLookupPage(WebDriver driver)
	{
		super(driver);
	}
	
    @FindBy(how= How.ID, using="iframe")
    public static WebElement lookupIFrame;
    
    @FindBy(how= How.XPATH, using="//input[@value=' Go! ']")
    public static WebElement goButton;

    
	public void selectAgentFromLookup(String Agent) throws InterruptedException, AWTException
	{
		Thread.sleep(5000);
		
		driver.switchTo().defaultContent();
		
		 Set handles = driver.getWindowHandles();
		 String firstWinHandle = driver.getWindowHandle(); 
		 handles.remove(firstWinHandle);
		 String winHandle=(String) handles.iterator().next();

		 if (winHandle!=firstWinHandle)
		 {
			 String secondWinHandle=winHandle; 
			 driver.switchTo().window(secondWinHandle);
		 }
	        DriverExtension.stepIntoIframe(driver, lookupIFrame);
	
	        List<WebElement> agentName = driver.findElements(By.xpath("//a[contains(.,'"+ Agent +"')]"));
	        agentName.get(0).click();

	        driver.switchTo().window(firstWinHandle);
	   
	}
	
}
