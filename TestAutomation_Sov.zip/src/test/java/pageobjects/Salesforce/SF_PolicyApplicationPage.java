package pageobjects.Salesforce;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import modules.DriverExtension;
import pageobjects.BaseClass;

public class SF_PolicyApplicationPage extends BaseClass{
	
	public SF_PolicyApplicationPage(WebDriver driver)
	{
		super(driver);
	}
	
	
    @FindBy(how= How.XPATH, using="//input[contains(@name, 'agentName') and contains(@type ,'text')]")
    public static WebElement workListSelect;
    
    @FindBy(how= How.XPATH, using="//img[@alt='Agent Lookup (New Window)']")
    public static WebElement agentLookup;
    
    @FindBy(how= How.XPATH, using="//input[@value='Next']")
    public static List <WebElement> nextBtn;
    
    @FindBy(how= How.ID, using="pop-frame-addPolicyApplication")
    public static WebElement policyIFrame;
    
    
    public void enterAgentName(String Agent) throws InterruptedException
    {	

    	DriverExtension.stepIntoIframe(driver, policyIFrame);    	
    	workListSelect.sendKeys(Agent);
    	agentLookup.click();
    	
    }
    
    public void clickNext() throws InterruptedException
    {

    	DriverExtension.stepIntoIframe(driver, policyIFrame);	
    	DriverExtension.scrollToBottom(driver);
    	DriverExtension.waitforElementToBeClickable(driver, nextBtn.get(1));
    	
    	 try {
    		 nextBtn.get(1).click();

         } catch (Exception e) {
             System.out.println(e);
         }
    	
    }  
}
