package pageobjects.Salesforce;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;
import pageobjects.BaseClass;

import java.util.List;

public class SF_NewSharingPage extends BaseClass{

    public SF_NewSharingPage(WebDriver driver)
    {
        super(driver);
    }

    @FindBy(how= How.XPATH, using="//input[@value=' Add ']")
    public static WebElement addBtn;

    @FindBy(how= How.ID, using="sharing_search")
    public static WebElement searchDropDown;

    @FindBy(how= How.ID, using="duel_select_0")
    public static WebElement availableDropDown;

    @FindBy(how= How.ID, using="duel_select_0_right")
    public static WebElement selectRightArrow;

    @FindBy(how= How.ID, using="p1")
    public static WebElement accountAccessDropDown;

    @FindBy(how= How.ID, using="p2")
    public static WebElement workAccessDropDown;

    @FindBy(how= How.ID, using="p5")
    public static WebElement caseAccessDropDown;

    @FindBy(how= How.XPATH, using="//input[@name='save']")
    public static List<WebElement> saveBtn;


    public void clickAdd()
    {
        addBtn.click();
    }

    public void clickRightSelectArrow()
    {
        selectRightArrow.click();
    }

    public void selectDropDownRecords(WebElement element, String option)
    {
        Select dropdown = new Select(element);
        dropdown.selectByVisibleText(option);
    }

    public void clickSave()
    {
        saveBtn.get(0).click();
    }

}
