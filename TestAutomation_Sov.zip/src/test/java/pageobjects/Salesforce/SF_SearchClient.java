package pageobjects.Salesforce;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import modules.DriverExtension;
import pageobjects.BaseClass;

public class SF_SearchClient extends BaseClass{
	
    public SF_SearchClient(WebDriver driver)
    {
        super(driver);
    }
    
    @FindBy(how= How.XPATH, using="//th[text()='First Name']/following::input[1]")
    public static WebElement firstName;
    
    @FindBy(how= How.XPATH, using="//th[text()='Last Name']/following::input[1]")
    public static WebElement lastName;
    
    @FindBy(how= How.XPATH, using="//th[text()='Date of Birth']/following::input[1]")
    public static WebElement dateOfBirth;
    
    @FindBy(how= How.XPATH, using="//input[@value='Finish']")
    public static List <WebElement> finishBtn;
    
    
    public void enterFirstName_LastName(String FirstName, String LastName)
    {
    	try {
			DriverExtension.waitforElement(driver, firstName);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	firstName.sendKeys(FirstName);
    	lastName.sendKeys(LastName);
    }
    
    public void enterDateOfBirth(String DOB)
    {
    	dateOfBirth.sendKeys(DOB);
    }
    
    public void clickFinish()
    {
    	finishBtn.get(1).click();
    }
    
}
