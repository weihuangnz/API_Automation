package pageobjects.Salesforce;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import pageobjects.BaseClass;

import java.util.List;

public class SF_NetworkEditPage extends BaseClass {

    public SF_NetworkEditPage(WebDriver driver)
    {
        super(driver);
    }


    @FindBy(how= How.XPATH, using="//label[contains(text(), 'Sharing Setup Complete')]/following::input[1]")
    public static WebElement sharingCompleteCheckBox;

    @FindBy(how= How.XPATH, using="//input[@name='save']")
    public static List<WebElement> saveBtn;


    public void clickSave()
    {
        saveBtn.get(1).click();
    }

    public void selectSharingCompleteCheckBox()
    {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", sharingCompleteCheckBox);
        sharingCompleteCheckBox.click();
    }

}
