package pageobjects.Mailinator;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import pageobjects.BaseClass;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Created by AmstelB on 6/09/2017.
 */
public class Mail_Login_Page extends BaseClass {

    public Mail_Login_Page(WebDriver driver)
    {
        super(driver);
    }

    @FindBy(how= How.XPATH, using="//input[@class='form-control']")
    public static WebElement emailAddress;

    @FindBy(how= How.XPATH, using="//button[@class='btn btn-dark']")
    public static WebElement goBtn;


    public void enterEmail(String email) throws IOException {

        Properties properties = new Properties();
        InputStream input = new FileInputStream("src/test/resources/Data/IP_Users.properties");

        // load properties file
        properties.load(input);

        emailAddress.sendKeys(properties.getProperty(email));

    }

    public void clickGo()
    {
        goBtn.click();
    }



}
