package pageobjects.Mailinator;

import modules.DriverExtension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import pageobjects.BaseClass;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by AmstelB on 6/09/2017.
 */
public class Mail_Body_Page extends BaseClass {

    public Mail_Body_Page(WebDriver driver)
    {
        super(driver);
    }

    @FindBy(how= How.XPATH, using="//ul[@class='single_mail-body']/li")
    public static List<WebElement> emailReceived;

    @FindBy(how= How.XPATH, using="//body")
    public static WebElement salesForceCode;

    @FindBy(how= How.XPATH, using="//i[@class='fa fa-trash fa-stack-1x fa-inverse']")
    public static WebElement delete;

    @FindBy(how= How.ID, using="msg_body")
    public static WebElement msgIframe;



    public void clickLatestSalesforceEmail() throws InterruptedException {

        List<WebElement> allElements = emailReceived;

        for (WebElement element: allElements) {

            try{

                String test = element.getText();

                if(element.getText().contains("noreply@salesforce.com"))
                {
                    DriverExtension.waitforElement(driver, element);
                    element.click();
                    break;
                }
            } catch (NoSuchElementException e) {
                e.printStackTrace();
            }
        }

    }

    public String getSalesforceCode() throws InterruptedException {

        DriverExtension.stepIntoIframe(driver, msgIframe);
        String code = salesForceCode.getText();

        String newcode = "";

        Matcher matcher = Pattern.compile("(\\d{5})").matcher(code);
        while (matcher.find()) {
            System.out.println(matcher.group(1));

            newcode = matcher.group(1);
        }

        return newcode;
    }

    public void clickDelete()
    {
        delete.click();
    }


}
