package browserStrategy;

import browserStrategy.BrowserStrategy;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.util.HashMap;
import java.util.Map;

public class Jenkins_iPad extends BrowserStrategy{
	
	/**
     * Created by AmstelB 30/08/2017
     */

	//iPad
    @Override
    public void getBrowserConfigurations(String testName) {
        this.loadPropertiesFiles();

        final String urlProperty = this.getPropertiesFile().getProperty("urlBrowserStack");

        this.setCapabilities(new DesiredCapabilities());
        this.getCapabilities().setCapability("name",testName);
        this.getCapabilities().setCapability("platform", "MAC");
        this.getCapabilities().setCapability("os_version", "11.3");
        this.getCapabilities().setCapability("device", "iPad 6th");
        this.getCapabilities().setCapability("real_mobile", "true");
        this.getCapabilities().setCapability("deviceOrientation", "landscape");
        this.getCapabilities().setCapability("browserstack.debug", "true");
        this.getCapabilities().setCapability("unexpectedAlertBehaviour", "accept");
        this.getCapabilities().setCapability("build", "Jenkins iPad");
        this.getCapabilities().setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR,
                UnexpectedAlertBehaviour.ACCEPT);


        this.setDriver(new RemoteWebDriver(this.getUrl(), this.getCapabilities()));
    }
}

