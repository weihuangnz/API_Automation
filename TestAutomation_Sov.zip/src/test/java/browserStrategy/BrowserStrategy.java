package browserStrategy;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Properties;

/**
 * Created by ivann on 14/07/2017.
 */
public abstract class BrowserStrategy {

    private WebDriver driver;
    private DesiredCapabilities capabilities;
    private Properties propertiesFile;
    private URL url;

    public URL getUrl() {
        return url;
    }

    public void setUrl(URL url) {
        this.url = url;
    }

    public DesiredCapabilities getCapabilities() {
        return capabilities;
    }

    public void setCapabilities(DesiredCapabilities capabilities) {
        this.capabilities = capabilities;
    }

    public abstract void getBrowserConfigurations(String testName);

    public WebDriver getDriver() {
        return driver;
    }

    public void setDriver(WebDriver driver) {
        this.driver = driver;
    }

    public void loadPropertiesFiles() {
        this.propertiesFile = new Properties();
        InputStream input = null;
        try {
            input = new FileInputStream("src/test/resources/FST.properties");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        try {
            propertiesFile.load(input);
            this.url = new URL(propertiesFile.getProperty("urlBrowserStack"));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Properties getPropertiesFile() {
        return propertiesFile;
    }

    public void setPropertiesFile(Properties propertiesFile) {
        this.propertiesFile = propertiesFile;
    }
}
