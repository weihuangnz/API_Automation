package browserStrategy;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.File;

/**
 * Created by ivann on 14/07/2017.
 */
public class FirexfoxStrategy extends BrowserStrategy {

    @Override
    public void getBrowserConfigurations(String testName) {
        System.out.println("Called openBrowser******");
        System.out.println("Running "+testName +"**************************");
        System.setProperty("webdriver.gecko.driver","src/test/resources/ChromeDriver/Linux/geckodriver");

        File firefoxPathBinary = new File("/opt/firefox/firefox-bin");
        System.setProperty("webdriver.firefox.bin", firefoxPathBinary.getAbsolutePath());

        this.setCapabilities(DesiredCapabilities.firefox());
        this.getCapabilities().setCapability("marionette", true);
        this.setDriver( new FirefoxDriver( this.getCapabilities()));
    }
}
