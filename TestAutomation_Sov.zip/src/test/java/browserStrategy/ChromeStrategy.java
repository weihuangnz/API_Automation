package browserStrategy;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.io.File;
import java.util.concurrent.TimeUnit;

/**
 * Created by ivann on 14/07/2017.
 */
public class ChromeStrategy extends  BrowserStrategy {


    @Override
    public void getBrowserConfigurations(String testName) {
        System.out.println("Called openBrowser");
        System.out.println("Running......****** "+testName +"*******");
        if (System.getProperty("os.name").contains("Windows")) {
            System.out.println("Called Windows driver");
            System.setProperty("webdriver.chrome.driver","src/test/resources/ChromeDriver/chromedriver.exe");
        }else
        {
            File file = new File("src/test/resources/ChromeDriver/Linux/chromedriver");
            boolean result = file.setExecutable(true);
            // evaluate the result
            if(result){
                System.out.println("Operation succeeded**************************");
            }else{
                System.out.println("Operation failed**************************");
            }

            System.out.println("Called Linux driver");
            System.setProperty("webdriver.chrome.driver","src/test/resources/ChromeDriver/Linux/chromedriver");
        }

        ChromeOptions chromeOptions = new ChromeOptions();
        chromeOptions.addArguments("-no-sandbox");
        this.setDriver(new ChromeDriver(chromeOptions ));
        this.getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        this.getDriver().manage().deleteAllCookies();
        this.getDriver().manage().window().maximize();
    }
}
