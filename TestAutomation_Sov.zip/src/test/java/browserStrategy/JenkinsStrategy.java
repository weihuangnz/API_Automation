package browserStrategy;

import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by ivann on 14/07/2017.
 */
public class JenkinsStrategy extends BrowserStrategy {


    @Override
    public void getBrowserConfigurations(String testName) {
        this.loadPropertiesFiles();

        final String urlProperty = this.getPropertiesFile().getProperty("urlBrowserStack");

        this.setCapabilities(new DesiredCapabilities());
        this.getCapabilities().setCapability("name",testName);
        this.getCapabilities().setCapability("browser", "Chrome");
        this.getCapabilities().setCapability("browser_version", "61.0");
        this.getCapabilities().setCapability("os", "Windows");
        this.getCapabilities().setCapability("os_version", "10");
        this.getCapabilities().setCapability("resolution", "1920x1080");
        this.getCapabilities().setCapability("browserstack.debug", "true");
        this.getCapabilities().setCapability("unexpectedAlertBehaviour", "accept");
        this.getCapabilities().setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR,
                UnexpectedAlertBehaviour.ACCEPT);

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--disable-plugins");
        options.addArguments("--no-sandbox");
        options.addArguments("disable-infobars");
        options.addArguments("--disable-default-apps");
        options.addArguments("--start-maximized");

        Map<String, Object> prefs = new HashMap<String, Object>();
        prefs.put("credentials_enable_service", false);
        prefs.put("profile.password_manager_enabled", false);
        options.setExperimentalOption("prefs", prefs);

        this.getCapabilities().setCapability(ChromeOptions.CAPABILITY, options);

        this.setDriver(new RemoteWebDriver(this.getUrl(), this.getCapabilities()));
    }
}
